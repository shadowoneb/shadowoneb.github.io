# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys,logging,time
from HTMLParser import HTMLParser
__settings__ = xbmcaddon.Addon(id='plugin.video.Ebs_RSS')
__PLUGIN_PATH__ = __settings__.getAddonInfo('path')
AddonID = "plugin.video.Ebs_RSS"
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
Addon = xbmcaddon.Addon(AddonID)
AddonID = "plugin.video.Ebs_RSS"
Addon = xbmcaddon.Addon(AddonID)
user_dataDir = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
rss_sources_file = user_dataDir + 'RSS.txt'
rss_file = user_dataDir + 'rss_file.txt' # define watched as the path to txt file to store data 
def getData(url):

      try:
        #print url
            req = urllib2.Request(url)
            req.add_header('User-Agent', __USERAGENT__)
            response = urllib2.urlopen(req)
            contentType = response.headers['content-type']

            data = response.read().replace("\n", "").replace("\t", "").replace("\r", "")
           
            response.close()            
            

            return contentType, data
      except :
          pass
def update_rss_file(show_message):
    
    time_Show=100
    if (show_message==1):
     dp = xbmcgui.DialogProgress()
     dp.create("Updating RSS", "", '', "[COLOR orange][B]Please wait[/B][/COLOR]")
     dp.update(0, "Updating RSS...",'','')
    rss_file_read = open(rss_file).read() # define watched_read as a way to open and read the file later on

    with open(rss_sources_file) as f:
      all_rss = f.readlines() 
    line_number=0
    names=[]
    names.append([])
    links=[]
    list=''

    links.append([])
    images=[]
    images.append([])
    all_data2=[]
    all_data2.append([])
    for line in all_rss:
      
      try:
       
       pos = line.find('-')
       type=line[:pos]
       if pos>1:
        line = line[pos+1:]
       
       contentType, page = getData(line)
       
       all_data= re.compile('<item>(.+?)</item>').findall(page)
       updated_items=0
       new_item=0
       for items in all_data:
        if (show_message==1):
         dp.update(int((line_number)/float(len(all_data)) * 100), "Updating RSS...",'','')
        #all_data2[line_number].append( re.compile('<title>(.+?)</title><link>(.+?)</link>.+?<img.+?src="(.+?)"',re.DOTALL).findall(items))
       #all_data2.append([])
    
        names[line_number] = re.compile('<title>(.+?)</title>').findall(items)
        
        names.append([])
        
        links[line_number] = re.compile('<link>(.+?)</link>').findall(items)
        links.append([])
       
        if 'https://www.opensubtitles.org/'  in line:
          
          images1= re.compile('"image/jpeg" url="(.+?)"/>').findall(items)
          
          if len(images1)>0:
            
            images[line_number]=(images1)
          
       
        elif 'http://www.subscenter.org/he/feeds/movies/latest/' in line:
          images[line_number]= re.compile('<image>(.+?)</image>',re.DOTALL).findall(items)
          
          images[line_number][0]='http://www.subscenter.org'+images[line_number][0]
        elif  'wizdom' in line:
           images1= re.compile('<image>(.+?)</image>').findall(items)
           if len (images1)>0:
              images[line_number]=images1
           
        else:
          
          images[line_number]= re.compile('<img.+?src="(.+?)".+?/>',re.DOTALL).findall(items)
        images.append([])
       
        
        all_data2[line_number].append((names[line_number],links[line_number], images[line_number],type+ '_'+time.strftime("%x")))
        all_data2.append([])
        
        if len (names[line_number])>0:
          name1=(names[line_number][0])
        
        updated_items=updated_items+1
        line_number=line_number+1
        name1=name1.replace(']', '')
        name1=name1.replace('[', '')
        name1=name1.replace('<', '')
        name1=name1.replace('>', '')
        name1=name1.replace('CDATA', '')
        name1=name1.replace('!', '')
        pos = name1.find('-')
        if pos>1:
          name1 = name1[:pos]
        h = HTMLParser()
   
        if 'wizdom' in line and len(name1)>0:
          try:
            name1=(h.unescape(name1)).encode('utf-8')
          except:
             pass
        if name1 not in rss_file_read:

           new_item=new_item+1
        if 'http://' in line:
         line_new=line.split('http://')
        elif 'https://' in line:
         line_new=line.split('https://')
        else:
          line_new=line


        line_new=line_new[1].split('/')

       list=list+('[COLOR blue]'+line_new[0] + '-' + str(new_item) +'[/COLOR]')+'/'+str(updated_items)+'\n'
       
          
      except Exception as e:
       logging.warning(e)
       list=list+('[COLOR red]'+line+ ' '  +'[/COLOR]')+'\n'
       
       pass
    temp_image2=''

    for item in all_data2:
     for initem in item:
    
      if len(initem[0])>0:
       name1=initem[0][0]
      
       name1=name1.replace(']', '')
       name1=name1.replace('[', '')
       name1=name1.replace('<', '')
       name1=name1.replace('>', '')
       name1=name1.replace('CDATA', '')
       name1=name1.replace('!', '')
       pos = name1.find('-')
       #name1=name1.decode('unicode-escape')
     
       h = HTMLParser()

       
       if pos>1:
        name1 = name1[:pos]
      #name=name.replace('-SKIDROW', '')

       if len(initem)>1:
       
        if len(initem[2])>0:
          pic=initem[2][0]
        else:
          pic=initem[2]
        if len(initem[2])==0:
          pic=''
        if 'wizdom' in pic:
          try:
            name1=(h.unescape(name1)).encode('utf-8')
          except:
            pass
        if 'ktuvit' in pic or 'opensubtitles' in pic:
         temp_image2=pic.replace('thumbnails/', '')
         temp_image2=temp_image2.replace('thumb_', '')
         rss_file_read = open(rss_file).read()
         if name1 not in rss_file_read:
           
           add_line_to_file('name='+name1+'url='+initem[1][0]+'pic='+pic+'temp_image2='+temp_image2+'type='+initem[3]+'"\n') # writes the url in a form easy to regex above 
  
          
        #if name in watched_read:
        #  name='[COLORblue]' + name + '[/COLOR]'
        #addDir3(name,initem[1][0],5,pic,temp_image2,initem[3])
        else:
         rss_file_read = open(rss_file).read() # define watched_read as a way to open and read the file later on

         if name1 not in rss_file_read:
   
    
  
         
          add_line_to_file('name='+name1+'url='+initem[1][0]+'pic='+pic+'temp_image2='+'ZZZ'+'type='+initem[3]+'"\n') # writes the url in a form easy to regex above 
          
          
         #if name in watched_read:
         # name='[COLORblue]' + name + '[/COLOR]'  
         #addDir3(name,initem[1][0],5,pic,pic,initem[3])
       else:
        rss_file_read = open(rss_file).read()
        
        if name1 not in rss_file_read:

          add_line_to_file('name='+name1+'url='+initem[1][0]+'pic='+'ZZZ'+'temp_image2='+'ZZZ'+'type='+initem[3]+'"\n') # writes the url in a form easy to regex above 
 
            
        #if name in watched_read:
        #  name='[COLORblue]' + name + '[/COLOR]'
        #addDir3(name,initem[1][0],5,'','',initem[3])
    if (show_message==1):
      dp.close()

      xbmcgui.Dialog().ok('Report',list)
      
      
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('RSS UPDATE','Updated', time_Show,''))
    xbmc.executebuiltin("XBMC.UpdateLocalAddons()")

def add_line_to_file(name1):
    with open(rss_file, "r+") as f:
       first_line = f.readline()
    
       lines = f.readlines()
       f.seek(0)

       f.write(name1+'"\n')
       f.write(first_line)
       f.writelines(lines) 
    f.close()       