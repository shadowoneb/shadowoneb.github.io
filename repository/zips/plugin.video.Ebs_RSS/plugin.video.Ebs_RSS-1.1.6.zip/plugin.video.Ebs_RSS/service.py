# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys,logging,time
from  Functions import update_rss_file,logging
__settings__ = xbmcaddon.Addon(id='plugin.video.Ebs_RSS')

update_time=int(__settings__.getSetting(id = 'update_time'))*60
sleep_time = 1000
last_run=0
time_Show=100

now = time.time()
last_run = now - (now % update_time)

AddonID = "plugin.video.Ebs_RSS"
Addon = xbmcaddon.Addon(AddonID)
user_dataDir = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
if not os.path.exists(user_dataDir): # check if folder doesnt exist 
     os.makedirs(user_dataDir) # create if it doesnt
watched = user_dataDir + 'watched.txt' # define watched as the path to txt file to store data 


if not os.path.exists(watched): # check if it doesnt exist 
      open(watched,'w+') # create if it doesnt
watched_read = open(watched).read() # define watched_read as a way to open and read the file later on


if not os.path.exists(user_dataDir): # check if folder doesnt exist 
     os.makedirs(user_dataDir) # create if it doesnt
rss_file = user_dataDir + 'rss_file.txt' # define watched as the path to txt file to store data 


if not os.path.exists(rss_file): # check if it doesnt exist 
      open(rss_file,'w+') # create if it doesnt
rss_file_read = open(rss_file).read() # define watched_read as a way to open and read the file later on

rss_sources_file = user_dataDir + 'RSS.txt'

if not os.path.exists(rss_sources_file): 
      open(rss_sources_file,'w+') # create if it doesnt
      rss_sources_read = open(rss_sources_file).read() # define watched_read as a way to open and read the file later on
else:
      rss_sources_read = open(rss_sources_file).read() # define watched_read as a way to open and read the file later on

if 'movies-https://www.opensubtitles.org/en/search/sublanguageid-heb/searchonlymovies-on/hd-on/adult-off/rss_2_00' not in rss_sources_read or 'movies-http://wizdom.xyz/rss.movie.xml' not in rss_sources_read or 'games-http://www.rlslog.net/category/games/pc/feed/' not in rss_sources_read or 'games-https://feeds.feedburner.com/skidrowgamesfeed' not in rss_sources_read  or 'games-http://www.blackboxrepack.com/feed/' not in rss_sources_read  or 'http://www.subscenter.org/he/feeds/movies/latest/' not in rss_sources_read:

  open(rss_sources_file, 'w').close()
  open(rss_sources_file,'w+') # create if it doesnt
  rss_sources_read = open(rss_sources_file).read() # define watched_read as a way to open and read the file later on
if len(rss_sources_read)<10:
      with open(rss_sources_file, "r+") as f:
       first_line = f.readline()
    
       lines = f.readlines()
       f.seek(0)
       f.write('games-http://www.rlslog.net/category/games/pc/feed/'+'\n')
       f.write('games-https://feeds.feedburner.com/skidrowgamesfeed'+'\n')
       #f.write('movies-http://rss.ktuvit.com/lastsubtitles_movies.rss'+'\n')
       f.write('games-http://www.blackboxrepack.com/feed/'+'\n')
       #f.write('movies-http://rss.torec.net/movies'+'\n')
       f.write('movies-http://www.subscenter.org/he/feeds/movies/latest/'+'\n')
       f.write('movies-https://www.opensubtitles.org/en/search/sublanguageid-heb/searchonlymovies-on/hd-on/rss_2_00'+'\n')
       f.write('movies-http://wizdom.xyz/rss.movie.xml')
       f.writelines(lines) 
      f.close()
	
     

	  

logging.warning("Start-ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ")
update_rss_file(0)

while(not xbmc.abortRequested):

            if(time.time() > last_run + update_time):
                      now = time.time()
                      last_run = now - (now % update_time)
                      update_rss_file(0)
                               
                      #xbmc.executebuiltin("XBMC.Notification({0}, ������ ����, {1}, {2})".format('RSS', 50 ,''))
            
            xbmc.sleep(sleep_time)
			

	