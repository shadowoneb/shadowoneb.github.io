# -*- coding: utf-8 -*-

import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys
from collections import namedtuple
import StorageServer,logging
import HTMLParser,YDStreamExtractor,time
from  Functions import update_rss_file
from shutil import copyfile

__debuging__="DEBUG_MODE"
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
__settings__ = xbmcaddon.Addon(id='plugin.video.Ebs_RSS')
addonName = __settings__.getAddonInfo("name")
addonIcon = __settings__.getAddonInfo('icon')
__language__ = __settings__.getLocalizedString
#__cachePeriod__ = __settings__.getSetting("cache")
__PLUGIN_PATH__ = __settings__.getAddonInfo('path')
__DEBUG__ = __settings__.getSetting("DEBUG") == "true"
__addon__ = xbmcaddon.Addon()
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')
sys.modules["__main__"].dbg = True
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
#cacheServer = StorageServer.StorageServer("plugin.video.Ebs_RSS", __cachePeriod__)  # (Your plugin name, Cache time in hours)
AddonID = "plugin.video.Ebs_RSS"
Addon = xbmcaddon.Addon(AddonID)
LIB_PATH = xbmc.translatePath( os.path.join( __PLUGIN_PATH__, 'resources', 'mail' ) )
sys.path.append (LIB_PATH)
import mail_file
user_dataDir = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
if not os.path.exists(user_dataDir):
     os.makedirs(user_dataDir)
images_file = os.path.join(user_dataDir, 'images_file_nickjr.txt')
if not (os.path.isfile(images_file)):
	f = open(images_file, 'w') 
	f.write('{}') 
	f.close() 
	
	
if not os.path.exists(user_dataDir): # check if folder doesnt exist 
     os.makedirs(user_dataDir) # create if it doesnt
watched = user_dataDir + 'watched.txt' # define watched as the path to txt file to store data 



if not os.path.exists(watched): # check if it doesnt exist 
      open(watched,'w+') # create if it doesnt
watched_read = open(watched).read() # define watched_read as a way to open and read the file later on


if not os.path.exists(user_dataDir): # check if folder doesnt exist 
     os.makedirs(user_dataDir) # create if it doesnt
rss_file = user_dataDir + 'rss_file.txt' # define watched as the path to txt file to store data 


if not os.path.exists(rss_file): # check if it doesnt exist 
      open(rss_file,'w+') # create if it doesnt
rss_file_read = open(rss_file).read() # define watched_read as a way to open and read the file later on

if not os.path.exists(user_dataDir): # check if folder doesnt exist 
     os.makedirs(user_dataDir) # create if it doesnt
favorite = user_dataDir + 'favorite.txt' # define watched as the path to txt file to store data

if not os.path.exists(favorite): # check if it doesnt exist 
      open(favorite,'w+') # create if it doesnt
favorite_read = open(favorite).read() # define watched_read as a way to open and read the file later on

  
def CATEGORIES():
    rss_file_read = open(rss_file).read() # define watched_read as a way to open and read the file later on
    lines_all_rss=0
    lines_without_watched=0
    rss_file_data=re.compile('name=(.+?)url=(.+?)pic=(.+?)temp_image2=(.+?)type=(.+?)"\n').findall(str(rss_file_read))
    for name,url,pic,temp_image2,type in rss_file_data:
      if name not in  watched_read:
        lines_without_watched=lines_without_watched+1
      lines_all_rss=lines_all_rss+1


    #addDir('list','lisst',4,'')
    addDir3('[COLORblue]'+str(lines_without_watched)+'[/COLOR]-'+'[COLORred]'+str(lines_all_rss)+'[/COLOR]'+' הצג הכל-','www.nothing.com',2,'','','')
    addDir3('[COLORblue]'+str(lines_without_watched)+'[/COLOR]'+' הצג רק לא נצפה-','www.nothing.com',8,'','','')
    addDir3("[COLORteal]פתח מועדפים[/COLOR]",'www.nothing.com',12,'','','')
    addDir2("[COLORblue]שלח קבצים אלי[/COLOR]",'ME',13,'','','')
    addDir2("[COLORblue]שלח קבצים לכתובת[/COLOR]",'ME',13,'','','')
    addDir2('עדכן כעת','www.nothing.com',1,'','','')
    addDir2('צפיה ברצף','www.nothing.com',4,'','','')
    addDir2('ניקוי היסטוריה','www.nothing.com',6,'','','')
    addDir2('ניקוי נצפה','www.nothing.com',7,'','','')
    addDir2('גיבוי נתונים','www.nothing.com',9,'','','')
    addDir2('שחזור נתונים','www.nothing.com',10,'','','')
    # xbmc.executebuiltin('Container.Refresh')  


   
def getBrowseDialog( default="", heading="", dlg_type=1, shares="files", mask="", use_thumbs=False, treat_as_folder=False ):
    """ shows a browse dialog and returns a value
        - 0 : ShowAndGetDirectory
        - 1 : ShowAndGetFile
        - 2 : ShowAndGetImage
        - 3 : ShowAndGetWriteableDirectory
    """
    dialog = xbmcgui.Dialog()
    value = dialog.browse( dlg_type, heading, shares, mask, use_thumbs, treat_as_folder, default )
    return value
def html_decode(s):
   try:
    """
    Returns the ASCII decoded version of the given HTML string. This does
    NOT remove normal HTML tags like <p>.
    """
    htmlCodes = (
            ("'", '&#39;'),
            ('"', '&quot;'),
            ('>', '&gt;'),
            ('<', '&lt;'),
            ('&', '&amp;')
        )
    for code in htmlCodes:
        s = s.replace(code[1], code[0])
    return s
   except Exception as e:    #xbmc.Player().play(playback_url)
    if __debuging__=="DEBUG_MODE":
     logging.warning("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF4"+ str(e))
    pass
	
	
def YOUTUBE_RESULT(name,description,tv_mode):
  #try:



    if tv_mode==0:
      dp = xbmcgui.DialogProgress()
      dp.create("טוען סרטון", "", '', "[COLOR orange][B]אנא המתן...[/B][/COLOR]")
    original_name=name
    print_text_file = open(watched,"a") # sets it to append to watched.txt
    print_text_file.write(original_name+'"\n') # writes the url in a form easy to regex above 
    print_text_file.close # closes file
    name=name.replace('[COLORblue]','')
    name=name.replace('[/COLOR]','')
    name=name.strip()
    saved_name=name  
    pos = name.find('/')
   
    if pos>1:
     name = name[pos-1:]
    
    
    name=name.replace(' ', '+')
    name=name.replace('\\', '+')
    name=name.replace('//', '+')
    logging.warning(description)
   #tv_mode=__settings__.getSetting(id = 'deviceId')
    if ('movies' in description):
     link_url='https://www.youtube.com/results?search_query=' + urllib2.quote(name)+ '+trailer'
    if ('games' in description):
     link_url='https://www.youtube.com/results?search_query=' + urllib2.quote(name)+ '+gameplay'
    if ('news' in description):
     link_url='https://www.youtube.com/results?search_query=' + urllib2.quote(name)+ '+trailer'
    if __debuging__=="DEBUG_MODE":
     logging.warning(link_url)
    contentType, page = getData(link_url)

    matche = re.compile('yt-lockup yt-lockup-tile yt-lockup-video vve-check clearfix(.+?)</div></div></div>',re.DOTALL).findall(page)
   
    if len(matche)>0:
     link=re.compile('<a href="(.+?)"').findall(matche[0])
     name=re.compile('title="(.+?)"').findall(matche[0])

     link[0]=link[0][9:]
     if len(name)>1:
      name_final=name[0]
      if "Watch Later" in name[0]:
         name_final=name[1]
      if "Queue" in name[1]:
       name_final=name[2]


     image=re.compile('<img.+?"https:(.+?)"',re.DOTALL).findall(matche[0]) 

     video_id = link[0]
     playback_url = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % video_id
     
     if tv_mode==1:
     
      #xbmcgui.Dialog().notification('Tv', 'Adding:'+saved_name, xbmcgui.NOTIFICATION_INFO ,100)
      return playback_url
     else:
     
      dp.close()
      link='https://www.youtube.com/watch?v='+video_id

      OPEN_URL(link,name_final)
    else:
      xbmcgui.Dialog().notification('Tv', 'NOT FOUND:'+saved_name, xbmcgui.NOTIFICATION_INFO ,100)
      return 'ZERO'
    #xbmc.executebuiltin('Container.Refresh') 
    sys.exit()
    #xbmc.executebuiltin("XBMC.ActivateWindow(Home)")
 # except Exception as e:    #xbmc.Player().play(playback_url)
 #   xbmcgui.Dialog().notification('Tv', str(e), xbmcgui.NOTIFICATION_INFO ,100)
 #   if __debuging__=="DEBUG_MODE":
 #    logging.warning("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF4"+ str(e))
 #   pass

     
def OPEN_URL(url,name):
	 
     time.sleep(1)
     YDStreamExtractor.disableDASHVideo(True)
     vid = YDStreamExtractor.getVideoInfo(url,quality=1) #quality is 0=SD, 1=720p, 2=1080p and is a maximum
     stream_url = vid.streamURL() #This is what Kodi (XBMC) will play
     x = 1
     listItem = xbmcgui.ListItem(name, path=stream_url)
     xbmc.Player().play(item=stream_url, listitem=listItem)
     
     return x

	 
def READ_RSS_FILE(watched_mode):

     rss_file_data=re.compile('name=(.+?)url=(.+?)pic=(.+?)temp_image2=(.+?)type=(.+?)"\n').findall(str(rss_file_read))
     for name,url,pic,temp_image2,type in rss_file_data:
      if 'ktuvit' in url:
        type=type+'\n'+'כתובית'  
      elif 'rlslog' in url:
        type=type+'\n'+'rlslog'  
      elif 'skidrow' in url:
        type=type+'\n'+'Skidrow'  
      elif 'blackbox' in url:
        type=type+'\n'+'BlackBox'  
      elif 'torec' in url:
        type=type+'\n'+'טורק'  
      elif 'subscenter' in url:
        type=type+'\n'+'סאבסנטר'  
      elif 'opensubtitles' in url:
        type=type+'\n'+'opensubtitles'  
      elif 'wizdom' in url:
        type=type+'\n'+'wizdom' 
      original_names=name
      if original_names in watched_read:
          name='[COLORblue]' + name + '[/COLOR]'
      if watched_mode==1:
       if original_names not in watched_read:
        if temp_image2!='ZZZ' and pic!='ZZZ':
        
         addDir2(name,url,5,pic,temp_image2,type)
        elif temp_image2=='ZZZ' and pic!='ZZZ':
        
         addDir2(name,url,5,pic,pic,type)
        elif temp_image2=='ZZZ' and pic!='ZZZ':
       
         addDir2(name,url,5,'','',type)

      if watched_mode==0:
      
        if temp_image2!='ZZZ' and pic!='ZZZ':
        
         addDir2(name,url,5,pic,temp_image2,type)
        elif temp_image2=='ZZZ' and pic!='ZZZ':
        
         addDir2(name,url,5,pic,pic,type)
        elif temp_image2=='ZZZ' and pic!='ZZZ':
       
         addDir2(name,url,5,'','',type)
     xbmc.executebuiltin("XBMC.UpdateLocalAddons()")
def CLEAR_RSS():
   open(rss_file, 'w').close()

def CLEAR_WATCHED():
   open(watched, 'w').close()

def getData(url):

 try:
        #print url
            req = urllib2.Request(url)
            req.add_header('User-Agent', __USERAGENT__)
            response = urllib2.urlopen(req)
            contentType = response.headers['content-type']

            data = response.read().replace("\n", "").replace("\t", "").replace("\r", "")
           
            response.close()            
            

            return contentType, data
 except Exception as e:
   if __debuging__=="DEBUG_MODE":
    logging.warning("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF6"+ str(e))
   pass
def TV_MODE():
     remotePlaylist=''
     player = xbmc.Player()
     playerItem = xbmcgui.ListItem(remotePlaylist)
     playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
     playlist.clear()
     x=0
     lines_without_watched=0
     dp = xbmcgui.DialogProgress()
     dp.create("מעדכן רשימת השמעה", "", '', "[COLOR orange][B]אנא המתן...[/B][/COLOR]")
     dp.update(0, "מעדכן...",'','')
     rss_file_data=re.compile('name=(.+?)url=(.+?)pic=(.+?)temp_image2=(.+?)type=(.+?)"\n').findall(str(rss_file_read))
     for name,url,pic,temp_image2,type in rss_file_data:
      if name not in  watched_read:
        lines_without_watched=lines_without_watched+1

     for name,url,pic,temp_image2,type in rss_file_data:
      if name not in watched_read:
          dp.update(int((x)/float(lines_without_watched) * 100), "מעדכן..."+str(x)+'/'+str(lines_without_watched) +'-'+ name,'','')

          if dp.iscanceled(): 
            dp.close()
            
            playlist=''
            break
          link2=YOUTUBE_RESULT(name,type,1)
          if link2!='ZERO':
           listItem=xbmcgui.ListItem(link2)
           listItem.setProperty("PlayPath", link2)
           playlist.add(url=link2, listitem=listItem)
          x=x+1
          #if x==1:
          # xbmc.Player().play(playlist, playerItem, False)
     if playlist!='':
       playlist.shuffle()
       xbmc.Player().play(playlist, playerItem, False)
def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     
		
#################################################################################################################

#                               NEED BELOW CHANGED



def addDir(contentType, name, url, mode, iconimage='DefaultFolder.png', elementId='', summary='', fanart='',isRealFolder=True):
        try:
           
            u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + name + "&module=" + urllib.quote_plus(elementId)
            liz = xbmcgui.ListItem(clean(contentType, name), iconImage=iconimage, thumbnailImage=iconimage)
            liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote(clean(contentType, name)), "Plot": urllib.unquote(summary)})
            if not fanart == '':
                liz.setProperty("Fanart_Image", fanart)
               
            ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isRealFolder)
            if __DEBUG__:
                 
                print "added directory success:" + clean(contentType, name) + " url=" + clean('utf-8',u)
            return ok
        except Exception as e:
            print "WALLA exception in addDir"
            print e
            raise
def addDir2(name,url,mode,iconimage,fanart,description):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
    ok=True
    sysaddon = sys.argv[0]
    cm = []
    cm.append(("שמור", 'RunPlugin(%s?mode=%s&description=%s&name=%s&url=%s&iconimage=%s)' % (sysaddon, 11, description,name,url,iconimage)))

    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    liz.addContextMenuItems(cm, replaceItems=False)
    if not fanart == '':
                liz.setProperty("Fanart_Image", fanart)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok
	
def addDir2_2(name,url,mode,iconimage,fanart,description):

        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        

        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
       # xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL)
        return ok
###############################################################################################################        

def addDir3(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def backup_all():
   folder=getBrowseDialog(default='c:\\', heading="Select backup location", dlg_type=0)
   logging.warning(folder)
   

   copyfile(watched, folder+'watched.txt')
   copyfile(rss_file, folder+'rss_file.txt')
   copyfile(favorite, folder+'rss_file.txt')
   xbmcgui.Dialog().ok("backup","backup Complete")
  
def restore_all():
   folder=getBrowseDialog(default='c:\\', heading="Select backup location", dlg_type=0)
   if not os.path.exists(folder+'watched.txt') or not os.path.exists(folder+'rss_file.txt') or not os.path.exists(folder+ 'favorite.txt'):
     xbmcgui.Dialog().ok("Restore","No backup files found")
   else:
     copyfile( folder+'watched.txt',watched)
     copyfile(folder+'rss_file.txt',rss_file )
     copyfile(folder+'favorite.txt',rss_file )
     xbmcgui.Dialog().ok("Restore","Restore Complete")

def mark_unwatched(name):
    
    f = open(watched,"r+")
    d = f.readlines()
    f.seek(0)
    for i in d:
      if i != "line you want to remove...":
        f.write(i)
    f.truncate()
    f.close()
def add_to_fav(name,description,iconimage):

    line='name='+name+'description='+description+'iconimage='+iconimage
    file_data=re.compile('name=(.+?)description=(.+?)iconimage=(.+?)"\n',re.DOTALL).findall(str(favorite_read))
    found=0
    for name2,description,iconimage in file_data:
      if name2==name:
        found=1
    
    if found==0:
      print_text_file = open(favorite,"a") # sets it to append to watched.txt
      print_text_file.write(line+'"\n') # writes the url in a form easy to regex above 
      print_text_file.close # closes file
      xbmc.executebuiltin("XBMC.Notification({0}, נשמר, {1}, {2})".format(addonName, 5000 ,addonIcon))
    else:
      xbmc.executebuiltin("XBMC.Notification({0}, כבר קיים, {1}, {2})".format(addonName, 5000 ,addonIcon))
def show_fav():
   file_data=re.compile('name=(.+?)description=(.+?)iconimage=(.+?)"\n',re.DOTALL).findall(str(favorite_read))
   
   for name,description,iconimage in file_data:
     addDir2(name,"www.nothing.com",5,iconimage,iconimage,description)
def mail_files(url):

     if Addon.getSetting('email')=='':
        Show_Dialog('','You Need To Enter Your Email Details','')
        Addon.openSettings()
        mail_file.EmailLog(url) 
     else:
        if url=='someone':
          mail_file.EmailLog('')
        else:
          mail_file.EmailLog('ME')
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
   
logging.warning ("Mode: "+str(mode))
logging.warning ("URL: "+str(url))
logging.warning ("Name: "+str(name))

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
       
elif mode==1:
        update_rss_file(1)#NEW_RSS()
elif mode==2:
        READ_RSS_FILE(0)
elif mode==5:
        YOUTUBE_RESULT(name,description,0)
elif mode==6:
        yesnowindow = xbmcgui.Dialog().yesno("ההיסטוריה תמחק","בטוח?","")
        if yesnowindow:
          CLEAR_RSS()
          xbmc.executebuiltin("XBMC.Notification({0}, המטמון נמחק, {1}, {2})".format(addonName, 5000 ,addonIcon))
          
elif mode==7:
        yesnowindow = xbmcgui.Dialog().yesno("סימון הנצפה ימחק בכולם","בטוח?","")
        if yesnowindow:
          CLEAR_WATCHED()
          xbmc.executebuiltin("XBMC.Notification({0}, המטמון נמחק, {1}, {2})".format(addonName, 5000 ,addonIcon))
elif mode==4:
       TV_MODE()
elif mode==8:
       READ_RSS_FILE(1)
elif mode==9:
       backup_all()
elif mode==10:
       restore_all()
elif mode==11:
      add_to_fav(name,description,iconimage)
elif mode==12:
      show_fav()
elif mode==13:
      mail_files(url)

		
		
logging.warning("Start End")
if len(sys.argv)>0:
 xbmcplugin.endOfDirectory(int(sys.argv[1]))
