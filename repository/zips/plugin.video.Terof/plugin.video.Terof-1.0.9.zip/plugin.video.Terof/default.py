# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys,logging
from HTMLParser import HTMLParser
h = HTMLParser()
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'


def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     

###############################################################################################################        
def addNolink( name, url,mode,isFolder, iconimage="DefaultFolder.png"):
 

          
          name='[COLOR aqua][I]'+name+'[/I][/COLOR]'
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name)   })

          liz.setProperty("IsPlayable","false")
          
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)
def addDir3(name,url,mode,iconimage,fanart,description,data=" ",tv_movie=" "):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+(description)+"&data="+(data)+"&tv_movie="+(tv_movie)


        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        
        return ok


def addLink( name, url,mode,isFolder,plot=" ", iconimage="DefaultFolder.png",data=" ",tv_movie=" "):
 

          
         
         
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+(name)+"&data="+(data)+"&tv_movie="+(tv_movie)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name), "Plot": plot   })
          liz.setProperty( "Fanart_Image", iconimage )
          liz.setProperty("IsPlayable","true")
          
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)


def read_site_html(url_link):

    req = urllib2.Request(url_link)
    req.add_header('User-agent',__USERAGENT__)# 'Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30')
    html = urllib2.urlopen(req).read()
    return html

def main_menu():
    html=read_site_html('https://terof.net/סרטים')
    regex='<li class="dropdown">(.+?)</ul>'
    match=re.compile(regex,re.DOTALL).findall(html)
    addDir3('[COLOR khaki][I]'+'חיפוש'+'[/I][/COLOR]' ,'https://terof.net/%D7%A1%D7%93%D7%A8%D7%95%D7%AA',9,'','','חיפוש')
    addDir3('[COLOR aqua][I]'+'סדרות'+'[/I][/COLOR]' ,'https://terof.net/%D7%A1%D7%93%D7%A8%D7%95%D7%AA',6,'','','סדרות')
    for all_data in match:
       
        regex2='<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">(.+?)<span class="caret"></span></a>'
        match2=re.compile(regex2).findall(all_data)
        addNolink( match2[0], 'www',99,False)
        regex3='<a href="(.+?)" title="(.+?)"'
        match3=re.compile(regex3).findall(all_data)
        for link,name in match3:
          if 'ערוץ' in name:
 
            addLink(name.replace("לצפייה ישירה",''),link,8,False,plot=name,data=name)
          else:
            addDir3(name.replace("לצפייה ישירה",''),link,2,'','',name)
def scrape_site(url):
  
  html=read_site_html(url)
  regex3='<ul class="pagination">(.+?)</ul>'
  match3=re.compile(regex3,re.DOTALL).findall(html)

  if len (match3)>0:
    regex2='href="(.+?)" rel="(.+?)">'
    match2=re.compile(regex2).findall(match3[0])

    for link,status in match2:
       
        if status=="next":
      
         
         addDir3('[COLOR khaki][I][B] עמוד הבא [/B][/I][/COLOR]',link[link.rfind('a href="'):].replace('a href="',''),2,'','','[COLOR khaki] עמוד הבא [/COLOR]')
         
  regex='<div class="terof-item-media">.+?<a href="(.+?)" title="(.+?)">.+?<img src="(.+?)"'
  match=re.compile(regex,re.DOTALL).findall(html)
  for link,name,icon in match:
    addDir3((h.unescape(name.decode('utf-8'))),link,3,icon,icon,(h.unescape(name.decode('utf-8'))),data=(h.unescape(name.decode('utf-8'))),tv_movie="movie")
    

    
def my_resolver(pre_link,auto_mode):
    link=False

    if 'vidlox.tv' in pre_link or 'vidzi.tv' in pre_link:

      html=read_site_html(pre_link)
      regex="sources:(.+?)]"
      match2=re.compile(regex).findall(html)

      regex_links='"(.+?)"'
      
      match_links=re.compile(regex_links).findall(match2[0])
      if auto_mode==True:
        link= match_links[0].strip(" \n") +'|User-Agent=%s'%__USERAGENT__
      else:
        ret = xbmcgui.Dialog().select("בחר מקור", match_links)
        link= match_links[ret].strip(" \n") +'|User-Agent=%s'%__USERAGENT__
    elif 'http://vidto.me' in pre_link:
      link=resolve_vidto(pre_link,auto_mode)

    else:
        import urlresolver
       
        videoPlayListpre_link = urlresolver.HostedMediaFile(url=pre_link).resolve()
        if videoPlayListpre_link:
          
          link=videoPlayListpre_link#.replace(match,urllib.quote_plus(match))
    return(link)
def play_link(name,url,icon,data,tv_movie):

  html=read_site_html(url)
  regex2='<h3 style="direction:ltr;font-size: 20px;text-align:right;">(.+?)</h3>'
  match2=re.compile(regex2,re.DOTALL).findall(html)
  regex3='\((.+?)\)'
  match3=re.compile(regex3,re.DOTALL).findall(html)
  year="N"
  
  for res in match3:
  
   if len(res)==4 and len (match2)>0:
      year=res
      
  if len (match2)>0:
    regex_s_e=' S(.+?)E(.+?)$'
    match_s_e=re.compile(regex_s_e,re.DOTALL).findall(match2[0])
    if tv_movie=="tv" and len(match_s_e)>0:
      url_link=year+"*"+match2[0]+"*"+match_s_e[0][0]+"*"+match_s_e[0][1]
    else:
      url_link=year+"*"+match2[0]
    addLink( "[COLOR lightblue][I] חפש מקורות אחרים [/I][/COLOR]", url_link,10,False, iconimage=icon,data=data,tv_movie=tv_movie)
  
  regex='<a class="btn btn-primary btn-noscript" style="font-size:18px;direction:ltr;" href="(.+?)".+?</i>(.+?)\n'
         
  match=re.compile(regex,re.DOTALL).findall(html)
  addLink( "[COLOR aqua][I] ניגון אוטומטי [/I][/COLOR]", url,5,False, iconimage=icon,data=name)
  
  
  
  for link,name1 in match:
    addLink( name1, link,4,False,plot=data, iconimage=icon,data=data)

def resolve_vidto(url,auto_mode):
    
    html=read_site_html(url)

    regex='<input type="hidden" name="(.+?)" value="(.+?)">'
    match=re.compile(regex).findall(html)
    if len(match)>0:
        for val_name,val in match:

          if val_name=='op':
            op=val
          elif val_name=='id':
            id=val
          elif val_name=='fname':
            fname=val
          elif val_name=='hash':
            hash=val
        
        import requests

        

        headers = {
            'Host': 'vidto.me',
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
            'Referer': url,
            'Content-Type': 'application/x-www-form-urlencoded',
            'Proxy-Authorization': 'Basic ZWJzMTExQGdtYWlsLmNvbTpwTnlqM2FNMGFzQXRCbzJaVVBaRU1nS0Zmek9RTGpqbw==',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        }

        data = [
          ('op', op),
          ('usr_login', ''),
          ('id', id),
          ('fname', fname),
          ('referer', ''),
          ('hash', hash),
          ('imhuman', 'Proceed to video'),
        ]

        x=requests.post(url, headers=headers,  data=data).text
    else:
      x=html
    regex="sources:(.+?)]"
    match2=re.compile(regex).findall(x)

    regex_links='file:"(.+?)",label:"(.+?)"'

    match_links=re.compile(regex_links).findall(match2[0])
    all_links=[]
    all_name=[]
    for links,name1 in match_links:
        all_links.append(links)
        all_name.append(name1)
    if auto_mode==True:
      link= all_links[0].strip(" \n") +'|User-Agent=%s'%__USERAGENT__
    else:
      ret = xbmcgui.Dialog().select("בחר איכות", all_name)
      link= all_links[ret].strip(" \n") +'|User-Agent=%s'%__USERAGENT__
    
      
    return link


def direct_link(name,url,data):
    
    html=read_site_html(url)
    regex='<p>or click <a onclick="location.replace.+? href="(.+?)">here</a> to continue</p>'
    match=re.compile(regex).findall(html)
    if len(match)==0:
        regex='<a href="https://slyke.net/\?url=(.+?)"'
        match=re.compile(regex).findall(html)
        match[0]=urllib.unquote(match[0])
    logging.warning(match[0])
    link=my_resolver(match[0],False)
    try:
        listItem = xbmcgui.ListItem(data.decode('utf-8'), path=link) 
       
        listItem.setInfo(type='Video', infoLabels={"Title": data})
        
        listItem.setProperty('IsPlayable', 'true')

        xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
    except Exception as inst:
     dialog = xbmcgui.Dialog()
     ok = dialog.ok('OOOPS', "קישור לא תקין")
def Auto_play(name,url,data):
  html=read_site_html(url)
  regex='<a class="btn btn-primary btn-noscript" style="font-size:18px;direction:ltr;" href="(.+?)".+?</i>(.+?)\n'
         
  match=re.compile(regex,re.DOTALL).findall(html)
  html=read_site_html(url)
  
 
        
  dp = xbmcgui.DialogProgress()
  dp.create('מחפש מקורות','Searching...')
  dp.update(0, 'Searching sources')
  x=0
  for link,name1 in match:
       html=read_site_html(link)
       regex2='<p>or click <a onclick="location.replace.+? href="(.+?)">here</a> to continue</p>'
       match2=re.compile(regex2).findall(html)

       if len(match2)==0:
            regex3='<a href="https://slyke.net/\?url=(.+?)"'
            match2=re.compile(regex3).findall(html)
            match2[0]=urllib.unquote(match2[0])

       if dp.iscanceled(): 
         dp.close()
         break
       dp.update(int((x)/float(len(match)) * 100), 'Trying:' + name1,str(x)+'/'+str(len(match)))
       x=x+1
       try:
       
           link=my_resolver(match2[0],True)
           if link:
              listitem = xbmcgui.ListItem(data.decode('utf-8'),path=link)
              listitem.setInfo(type='Video', infoLabels={"Title": data.decode('utf-8')})
              xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listitem)
              if len(match2[0]) > 1:
                while not xbmc.Player().isPlaying():
                     xbmc.sleep(10) #wait until video is being played
           else:
             dp.update(int((x)/float(len(match)) * 100),'[COLOR red][I]'+"Resolver לא מצא קישור לווידאו"+'[/I][/COLOR]')
           if xbmc.Player().isPlaying():
      
                dp.close()
                return True
       except Exception as inst:
         dp.update(int((x)/float(len(match)) * 100),'[COLOR red][I]'+ str(inst)+'[/I][/COLOR]')
         

  dp.close()
  dialog = xbmcgui.Dialog()
  ok = dialog.ok('OOOPS', 'לא נמצאו מקורות זמינים לניגון')
def scrape_tv(name,url,data):
  html=read_site_html(url)
  regex3='<ul class="pagination">(.+?)</ul>'
  match3=re.compile(regex3,re.DOTALL).findall(html)

  if len (match3)>0:
      regex2='href="(.+?)" rel="(.+?)">'
      match2=re.compile(regex2).findall(match3[0])
      
      for link,status in match2:
           
        if status=="next":
      
         
         addDir3('[COLOR khaki][I][B] עמוד הבא [/B][/I][/COLOR]',link[link.rfind('a href="'):].replace('a href="',''),6,'','','[COLOR khaki] עמוד הבא [/COLOR]')
  regex='<div class="terof-item-media">.+?<a href="(.+?)">.+?<img src="(.+?)".+?<h4>(.+?)</h4>'
  match=re.compile(regex,re.DOTALL).findall(html)
  for link,image,name in match:
    addDir3((h.unescape(name.replace("לצפייה ישירה",'').decode('utf-8'))),link,7,image,image,(h.unescape(name.decode('utf-8'))),data=(h.unescape(name.decode('utf-8'))))


def scrape_season(name,url,data):
  html=read_site_html(url)
  regex='<div class="terof-item-media">.+?<a href="(.+?)">.+?<img src="(.+?)".+?<h4>(.+?)</h4>'
  match=re.compile(regex,re.DOTALL).findall(html)
  for link,image,name in match:
    if 'פרק' in name:
      addDir3((h.unescape(name.replace("לצפייה ישירה",'').decode('utf-8'))),link,3,image,image,(h.unescape(data.decode('utf-8'))),data=(h.unescape(data.decode('utf-8'))),tv_movie="tv")
    else:
      addDir3((h.unescape(name.replace("לצפייה ישירה",'').decode('utf-8'))),link,7,image,image,(h.unescape(data.decode('utf-8'))),data=(h.unescape(data.decode('utf-8'))))
def tv_chan(name,url,data):
  html=read_site_html(url)
  regex='<source src="(.+?)"'
  match=re.compile(regex,re.DOTALL).findall(html)
  link=(h.unescape(match[0]))

  listItem = xbmcgui.ListItem(data.decode('utf-8'), path=link) 

  listItem.setInfo(type='Video', infoLabels={"Title": data})

  listItem.setProperty('IsPlayable', 'true')

  xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
def search(name,url,data):
    search_entered =''
    keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
    keyboard.doModal()
    if keyboard.isConfirmed():
                search_entered = keyboard.getText()
    
    if search_entered !='' :
       html=read_site_html('https://terof.net/search/'+search_entered)
       regex='<div class="terof-item-media">.+?<a href="(.+?)" title="(.+?)">.+?<img src="(.+?)"'
       match=re.compile(regex,re.DOTALL).findall(html)
       for link,name,icon in match:
         
            addDir3((h.unescape(name.decode('utf-8'))),link,3,icon,icon,(h.unescape(name.decode('utf-8'))),data=(h.unescape(name.decode('utf-8'))))
def play_othersources(name,url,data,tv_movie):
  import urlresolver,nanscrapers
  video_info={}
  def sort_function(item):
            quality = item[1][0]["quality"]
            if quality == "1080": quality = "HDa"
            if quality == "720": quality = "HDb"
            if quality == "560": quality = "HDc"
            if quality == "HD": quality = "HDd"
            if quality == "480": quality = "SDa"
            if quality == "360": quality = "SDb"
            if quality == "SD": quality = "SDc"

            return quality
  if 'tv'  in tv_movie:
      year=url.split("*")[0]
      title=url.split("*")[1]
      season=url.split("*")[2]
      episode=url.split("*")[3]
      video_info={"Title": title,
                  'originaltitle':title,
                  'season':season,
                  'episode':episode,
                  'year':year
                     
                     }

      
      if year=="N":
        year=""

      
      
      link = nanscrapers.scrape_episode_with_dialog(title.split(" ")[0], year, year, int(season), int(episode),None,None)
      
  else:
      year=url.split("*")[0]
      title=url.split("*")[1]
      video_info={"Title": title,
              'originaltitle':title,
              'year':year
                 
                 }
      if year=="N":
        year=""
 
      link = nanscrapers.scrape_movie_with_dialog(title, year,None, timeout=600, sort_function=sort_function)
  link=link['url']
  videoPlayListUrl = urlresolver.HostedMediaFile(url=link).resolve()

  if videoPlayListUrl:
    link=videoPlayListUrl
  listItem = xbmcgui.ListItem(name.decode('utf-8'), path=link) 
   
  listItem.setInfo(type='Video', infoLabels=video_info)

  listItem.setProperty('IsPlayable', 'true')

  xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
  
  
  
params=get_params()

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
data=" "

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:        
        data=urllib.unquote_plus(params["data"])
except:
        pass
try:        
        tv_movie=urllib.unquote_plus(params["tv_movie"])
except:
        pass

if mode==None or url==None or len(url)<1:
        main_menu()
elif mode==2:
     scrape_site(url)
elif mode==3:
     play_link(name,url,iconimage,data,tv_movie)
elif mode==4:
     direct_link(name,url,data)
elif mode==5:
     Auto_play(name,url,data)
elif mode==6:
     scrape_tv(name,url,data)
elif mode==7:
     scrape_season(name,url,data)
elif mode==8:
     tv_chan(name,url,data)
elif mode==9:
     search(name,url,data)
elif mode==10:
     play_othersources(name,url,data,tv_movie)
xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
xbmc.executebuiltin("Container.SetViewMode(504)")
if mode!=3:
  xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
xbmcplugin.endOfDirectory(int(sys.argv[1]))

