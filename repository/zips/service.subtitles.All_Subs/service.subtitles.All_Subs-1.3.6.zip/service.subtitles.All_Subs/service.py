# -*- coding: utf-8 -*-
import sys,logging,unicodedata,urllib2,urllib,zlib,json,os,xbmcvfs,zipfile,re,xbmcgui,xbmcaddon,contextlib,xbmc,hashlib,shutil
from os import path
from requests import get
from json import loads, load
from shutil import copyfileobj, rmtree
from time import time
from unicodedata import normalize
from urllib import urlretrieve, unquote_plus, unquote, urlopen, quote
from xbmcaddon import Addon
from xbmcplugin import endOfDirectory, addDirectoryItem
from xbmcgui import ListItem, Dialog
from srt2ass import srt2ass
from xbmcvfs import listdir, exists, mkdirs
from xbmc import translatePath, executebuiltin, getInfoLabel, executeJSONRPC, Player, sleep, log, getCondVisibility
from re import sub
from  Subscene import search_subscene,download_subscene
from opensubtitle import Search_opensubtitle,Download_opensubtitle
from shutil import copyfile
import socket
from yify import search_yify
socket.setdefaulttimeout(10)
action=None
all_setting=[]
location=0
last_sub_download=''
try:
    import StorageServer
except ImportError:
    import storageserverdummy as StorageServer
regexHelper = re.compile('\W+', re.UNICODE)
running=0
'''
f = urllib2.urlopen('https://raw.githubusercontent.com/ebs111/ebs_repo/master/repository/zips/service.subtitles.All_Subs/ignore.txt')
excluded_addons_temp=f.readlines()
excluded_addons=[]
for ext in excluded_addons_temp:

  x=(ext).replace('\n','').replace('\r','').lower()
  excluded_addons.append(x)


current_list_item='פומלה TV'
if any(x in current_list_item.lower() for x in excluded_addons):
  logging.warning('YES')
else:
  logging.warning('NO')
'''
logging.warning('INFo')
logging.warning((xbmc.getInfoLabel("listitem.addonname")))
MyAddon = Addon()
__profile__ = unicode(xbmc.translatePath(MyAddon.getAddonInfo('profile')), 'utf-8')
__addon__ = xbmcaddon.Addon()
MyScriptID = MyAddon.getAddonInfo('id')
MyVersion = MyAddon.getAddonInfo('version')
__scriptid__ = MyAddon.getAddonInfo('id')
__scriptname__ = MyAddon.getAddonInfo('name')
MyTmp = unicode(xbmc.translatePath(os.path.join(__profile__, 'temp_wizdom')), 'utf-8')#translatePath(MyAddon.getAddonInfo('profile')).encode('utf-8')
MySubFolder = translatePath(path.join(MyTmp, 'subs')).encode('utf-8')
MyName = MyAddon.getAddonInfo('name')
MyLang = MyAddon.getLocalizedString
__settings__ = xbmcaddon.Addon(id=MyScriptID)
cache_list_folder=unicode(xbmc.translatePath(os.path.join(__profile__, 'cache_list_folder')), 'utf-8')
addon_font_path= MyAddon.getAddonInfo('path')+'\\fonts'
fonts_folder=xbmc.translatePath("special://home/")+'media\\fonts'

try:
  if not path.exists(cache_list_folder):
    mkdirs(cache_list_folder)
except: pass
try:
  if not path.exists(fonts_folder):
    mkdirs(fonts_folder)
  src=addon_font_path
  dst=fonts_folder
  for item in os.listdir(src):

      if not path.exists(str(dst)+'\\'+str(item)):
        s = os.path.join(src, item)
        d = os.path.join(dst, item)
        shutil.copy2(s, d)
except:
  pass
store = StorageServer.StorageServer(__scriptname__, int(24 * 364 / 2))  # 6 months

subtitle_cache = StorageServer.StorageServer('Subtitle', 4)  #4 hours
subtitle_cache_next = StorageServer.StorageServer('next Subtitle', 4)  #4 hours

__language__ = MyAddon.getLocalizedString
__temp__ = unicode(xbmc.translatePath(os.path.join(__profile__, 'temp')), 'utf-8')
__last__ = unicode(xbmc.translatePath(os.path.join(__profile__, 'last')), 'utf-8')
BASE_URL = "http://www.cinemast.org/he/cinemast/api/"
id_all_collection=[]
'''
class popupBtns(xbmcgui.WindowDialog):
    def __init__(self, title='', btns=[], width=1):
        self.w = width
        self.selected = -1
        self.btns = btns
        self.btnCnts = [0]
        for i in range(len(btns)-1): # There has to be a better way to do this. zeros doesn't work...
            self.btnCnts.append(0)
  
#   def onInit(self):
        w = self.w      
        w = int(self.getWidth()*width)
        pad = self.getHeight()/100
        hCnt = 5*pad
        yo = pad
  
        h = len(self.btns) * (hCnt + 5) + yo
        mediaDir = os.path.join(os.getcwd().replace(";",""),'resources','skins','DefaultSkin','media')
        rw = self.getWidth()
        rh = self.getHeight()
        x = rw/2 - w/2
        y = rh/2 - h/2
  
        # Background
        self.imgBg = xbmcgui.ControlImage(0+x-4*pad,0+y-4*pad,w+8*pad,h+8*pad, os.path.join(mediaDir,'gs-bg-menu.png'))
        self.addControl(self.imgBg)
  
        i = 0
        while i < len(self.btns):
            self.btnCnts[i] = xbmcgui.ControlButton(pad+x, yo+y, w-2*pad, hCnt, str(self.btns[i]), os.path.join(mediaDir,'button_focus.png'), '', font='font12', textColor='0xFFFFFFFF', alignment=2)
            self.addControl(self.btnCnts[i])
            yo += hCnt + 5
            i += 1
  
        self.setFocus(self.btnCnts[0])
  
    def onControl(self, action):
        pass
  
    def onAction(self, action):
        if action == 10:
            self.close()    
        elif (action == 3) or (action == 4) or (action == 7) or (action == 9):
            try:    
                cnt = self.getFocus()
            except:
                self.setFocus(self.btnCnts[0])
                return None
  
            d = 0
            if action == 3: # Up
                d = -1
            elif action == 4: # Down
                d = 1
            l = len(self.btnCnts)
            for i in range(l):
                if self.btnCnts[i] == cnt:
                    if action == 7: # Select
                        self.selected = i
                        self.close()
                    elif action == 9: # Back
                        self.close()
                    elif i+d > l-1:
                        self.setFocus(self.btnCnts[0])
                    elif i+d < 0:
                        self.setFocus(self.btnCnts[l-1])
                    else:
                        self.setFocus(self.btnCnts[i+d])
  
'''
class URLHandler():
    def __init__(self):
        self.opener = urllib2.build_opener()
        self.opener.addheaders = [('Accept-Encoding', 'gzip'),
                                  ('Accept-Language', 'en-us,en;q=0.5'),
                                  ('Pragma', 'no-cache'),
                                  ('Cache-Control', 'no-cache'),
                                  ('User-Agent',
                                   'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 Kodi/17.2 (KHTML, like Gecko) Chrome/49.0.2526.111 Safari/537.36')]

    def request(self, url, data=None, query_string=None, ajax=False, referrer=None, cookie=None):
        if data is not None:
            data = urllib.urlencode(data)
        if query_string is not None:
            url += '?' + urllib.urlencode(query_string)
        if ajax:
            self.opener.addheaders += [('X-Requested-With', 'XMLHttpRequest')]
        if referrer is not None:
            self.opener.addheaders += [('Referrer', referrer)]
        if cookie is not None:
            self.opener.addheaders += [('Cookie', cookie)]

        content = None
        log("Getting url: %s" % (url))
        if data is not None and 'password' not in data:
            log("Post Data: %s" % (data))
        try:
            response = self.opener.open(url, data)
            content = None if response.code != 200 else response.read()

            if response.headers.get('content-encoding', '') == 'gzip':
                try:
                    content = zlib.decompress(content, 16 + zlib.MAX_WBITS)
                except zlib.error:
                    pass

            if response.headers.get('content-type', '') == 'application/json':
                content = json.loads(content, encoding="utf-8")

            response.close()
        except Exception as e:
            log("Failed to get url: %s\n%s" % (url, e))
            # Second parameter is the filename
        return content
urlHandler = URLHandler()
def notify(msg_id):
    xbmc.executebuiltin((u'Notification(%s,%s)' % (__scriptname__, __language__(msg_id))).encode('utf-8'))
def notify2(msg_id):
    xbmc.executebuiltin((u'Notification(%s,%s)' % (__scriptname__, msg_id)).encode('utf-8'))
def login( notify_success=True):
        
  
        email = all_setting["Email"]
        password = all_setting["Password"]
        if email=='' or password=='':
          __settings__.openSettings()
          email = all_setting["Email"]
          password = all_setting["Password"]
        post_data = {'username': email, 'password': password}
        content = urlHandler.request(BASE_URL + "login/", post_data)

        if content['result'] == 'success':
            if notify_success:
                notify(32010)

            del content["result"]
            return content
        else:
            notify(32009)
            return None
		
def get_user_token( force_update=False):
        if force_update:
            store.delete('credentials')

        results = store.get('credentials')
        if results:
            results = json.loads(results)
        else:
            results = login(False)
            if results:
                store.set('credentials', json.dumps(results))
        
        return results
		
def convert_to_utf(file):
	try:
		with codecs.open(file, "r", "cp1255") as f:
			srt_data = f.read()

		with codecs.open(file, 'w', 'utf-8') as output:
			output.write(srt_data)
	except: pass

def lowercase_with_underscores(str):
    
    return normalize('NFKD', unicode(str)).encode('utf-8', 'ignore')

def take_title_from_focused_item():
    labelType = xbmc.getInfoLabel("ListItem.DBTYPE")  # movie/tvshow/season/episode
    labelMovieTitle = xbmc.getInfoLabel("ListItem.OriginalTitle")
    labelYear = xbmc.getInfoLabel("ListItem.Year")
    labelTVShowTitle = xbmc.getInfoLabel("ListItem.TVShowTitle")
    labelSeason = xbmc.getInfoLabel("ListItem.Season")
    labelEpisode = xbmc.getInfoLabel("ListItem.Episode")
    isItMovie = xbmc.getCondVisibility("Container.Content(movies)") or labelType == 'movie'
    isItEpisode = xbmc.getCondVisibility("Container.Content(episodes)") or labelType == 'episode'

    title = 'SearchFor...'
    if isItMovie and labelMovieTitle and labelYear:
        title = labelMovieTitle + " " + labelYear
    elif isItEpisode and labelTVShowTitle and labelSeason and labelEpisode:
        title = ("%s S%.2dE%.2d" % (labelTVShowTitle, int(labelSeason), int(labelEpisode)))

    return title

def download(id,language,key,filename,mode_subtitle):
	try:


     
	 if filename!='':
	
		subtitle_list = []
		exts = [".srt", ".sub"]
   
		zip_filename = os.path.join(__temp__, "subs.zip")

        
		try:
			rmtree(__temp__)
		except: pass
		mkdirs(__temp__)

		query = {"v": filename,"key": key,"sub_id": id}

		user_token = get_user_token()

		url = BASE_URL + "subtitle/download/" + language + "/?" + urllib.urlencode(query)

        
		f = urlHandler.request(url, user_token)

		if f==None:
		  if mode_subtitle>1:
		    return '',False
		  else:
		     return False,'NO'
		if len(f)<100:
			if mode_subtitle==3:
			  xbmcgui.Dialog().ok("Subscenter",str(f))
			else:
			  xbmcgui.Dialog().notification('Subcenter Download', str(f), xbmcgui.NOTIFICATION_INFO,1000 )
			return False,'NO'
		else:
			with open(zip_filename, "wb") as subFile:
				subFile.write(f)
			subFile.close()
			xbmc.sleep(500)

			with contextlib.closing(zipfile.ZipFile(zip_filename , "r")) as z:
				z.extractall(__temp__)
			#with zipfile.ZipFile(zip_filename) as zf:
			#	zf.extractall(__temp__)
		file_list=(os.listdir(__temp__ ))
     
		for file in file_list:
			full_path = os.path.join(__temp__, file)

			if os.path.splitext(full_path)[1] in exts:
			  subtitle_list.append(full_path)

		if mode_subtitle>1:
		  return subtitle_list," "
		else:
		 #xbmc.Player().setSubtitles(subtitle_list[0])

		 if len (subtitle_list)>0:
		   sub_result=subtitle_list[0]
		 else:
		   sub_result='0'
		 return True,sub_result
	 else:
		try:
			rmtree(MyTmp)
		except: pass
		mkdirs(MyTmp)
		try:
			rmtree(MySubFolder)
		except: pass
		mkdirs(MySubFolder)



		subtitle_list = []
		exts = [".srt", ".sub", ".str"]

		if 'yify$$$' in id:
			archive_file = path.join(MyTmp, 'yify.sub.'+id.replace('yify$$$','').replace('/subtitles/','')+'.zip')


			if not path.exists(archive_file):
				urlretrieve("http://www.yifysubtitles.com/subtitle/"+id.replace('yify$$$','').replace('/subtitles/','')+".zip", archive_file)
				
		else:
			archive_file = path.join(MyTmp, 'wizdom.sub.'+id+'.zip')
			
			if not path.exists(archive_file):
				urlretrieve("http://zip.wizdom.xyz/"+id+".zip", archive_file)

		#executebuiltin(('XBMC.Extract("%s","%s")' % (archive_file, MySubFolder)).encode('utf-8'), True)
		with contextlib.closing(zipfile.ZipFile(archive_file , "r")) as z:
			z.extractall(MySubFolder)
		for file_ in listdir(MySubFolder)[1]:
			ufile = file_.decode('utf-8')
			file_ = path.join(MySubFolder, ufile)
			if path.splitext(ufile)[1] in exts:
				convert_to_utf(file_)
				subtitle_list.append(file_)

		if mode_subtitle>1:
		  return subtitle_list," "
		else:
		 if len (subtitle_list)>0:
		   sub_result=subtitle_list[0]
		 else:
		   sub_result='0'
		 #xbmc.Player().setSubtitles(subtitle_list[0])
		 return True,sub_result
	except:
	 notify2('[COLOR red] Error Downloading [\COLOR]')
	if mode_subtitle>1:
	    return '',False
	else:
	    return False,'NO'


def getParams(arg):
	param=[]
	paramstring=arg
	if len(paramstring)>=2:
		params=arg
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:	
				param[splitparams[0]]=splitparams[1]
							
	return param

def getParam(name,params):
	try:
		return unquote_plus(params[name])
	except:	pass

def GetJson(imdb,mode_subtitle,season=0,episode=0,version=0):

	filename = 'wizdom.imdb.%s.%s.%s.json'%(imdb,season,episode)
	url = "http://api.wizdom.xyz/search.id.php?imdb=%s&season=%s&episode=%s&version=%s"%(imdb,season,episode,version)

	MyLog("GetJson:%s"%url)
	json_object = Caching(filename,url)
	MyLog(json_object)
	subs_rate = []
	subtitle=' '
	x=0
	id_all_collection=[]
	subtitle_list=[]
	if json_object<>0:
		for item_data in json_object:
			MyLog(item_data)
			listitem = ListItem(label= "Hebrew",label2= str(x)+'. '+'[Wiz]'+item_data["versioname"],thumbnailImage="he",iconImage="%s"%(item_data["score"]/2))
			if int(item_data["score"])>8:
				listitem.setProperty("sync", "true")
			url = "plugin://%s/?action=download&versioname=%s&id=%s" % (MyScriptID, item_data["versioname"], item_data["id"])
			MyLog(url)
			json_data={'url':url,
			                 'label':"Hebrew",
			                 'label2':str(x)+'. '+'[Wiz]'+item_data["versioname"],
			                 'iconImage':"%s"%(item_data["score"]/2),
			                 'thumbnailImage':"he",
			                 'hearing_imp':'false',
			                 'sync': 'false'}
			if item_data["id"] not in id_all_collection:
				id_all_collection.append(item_data["id"])
				MyLog(item_data["id"])
				if mode_subtitle>1:
				  subtitle_list.append(json_data)
				  #addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=listitem,isFolder=False)
				  x=x+1
				else:
				  subtitle_list.append(json_data)
				  ok,subtitle=download(item_data["id"],'','','',mode_subtitle)
				  if ok==False:
				    return 0,subtitle,json_data
				  else:
				    
				    break
	if (json_object)==0:
	  return 0,' ',subtitle_list
	else:
	  MyLog(len(json_object))
	  return len(json_object),subtitle,subtitle_list

def SearchMovie(query,year):
	
	tmdbKey = '653bb8af90162bd98fc7ee32bcbbfb3d'
	filename = 'wizdom.search.movie.%s.%s.json'%(lowercase_with_underscores(query),year)
	if year>0:
		url = "http://api.tmdb.org/3/search/movie?api_key=%s&query=%s&year=%s&language=he"%(tmdbKey,quote(query),year)
	else:
		url = "http://api.tmdb.org/3/search/movie?api_key=%s&query=%s&language=he"%(tmdbKey,quote(query))
	json = Caching(filename,url)
	try:	tmdb_id = int(json["results"][0]["id"])
	except:	return 0

	filename = 'wizdom.tmdb.%s.json'%(tmdb_id)
	url = "http://api.tmdb.org/3/movie/%s?api_key=%s&language=en"%(tmdb_id,tmdbKey)
	json = Caching(filename,url)
	
	try:	imdb_id = json["imdb_id"]
	except:	return 0

	return imdb_id

def Caching(filename,url):
	try:
		json_file = path.join(MyTmp, filename)
		if not path.exists(json_file) or not path.getsize(json_file)>20 or (time()-path.getmtime(json_file)>30*60):
			urlretrieve(url, json_file)

		if path.exists(json_file) and path.getsize(json_file)>20:

			with open(json_file) as json_data:
				json_object = load(json_data)
			return json_object
		else:
			return 0
	except:
	     try:
	       rmtree(MyTmp)
	     except: pass
	     mkdirs(MyTmp)
	     return 0
      

def ManualSearch(title,option,mode_subtitle):
	title=title.replace("&"," and ")
	filename = 'wizdom.search.filename.%s.json'%(quote(title))

	url = "http://api.wizdom.xyz/search.manual.php?filename=%s"%(lowercase_with_underscores(title))
	subtitle_list=[]
	try:

		json = Caching(filename,url)

		if "season" not in json:
		  json['season']=0

		if "episode" not in json:
		  json['episode']=0
		if json["type"]=="episode":
			json['year']=0
			imdb_id = urlopen("http://api.wizdom.xyz/search.tv.php?name="+quote(json['title'])).read()
			if imdb_id<>'' and imdb_id<>0 and option==1:
				num_of_subs,subtitle,subtitle_list=GetJson(str(imdb_id),mode_subtitle,json['season'],json['episode'],lowercase_with_underscores(title))

		elif json["type"]=="movie":
			if "year" in json:
				imdb_id = SearchMovie(str(json['title']),json['year'])
			else:
				json['year']=0

				imdb_id = SearchMovie(str(json['title']),0)
			if imdb_id and option==1:
				logging.warning("Mode Manual")
				num_of_subs,subtitle,subtitle_list=GetJson(str(imdb_id),mode_subtitle,0,0,lowercase_with_underscores(title))

		return(json['title'],json['year'],imdb_id,json['season'],json['episode'],subtitle_list,num_of_subs,subtitle)
	except:	pass
#///////////////////////////////////////Subcenter////////////////////////////////////////////////
def subcenter_search(item,mode_subtitle):
        results = []
        
        id_collection=[]
        search_string = re.split(r'\s\(\w+\)$', item["tvshow"])[0] if item["tvshow"] else item["title"]
        user_token =  get_user_token()

        if user_token:
            query = {"q": search_string.encode("utf-8"), "user": user_token["user"], "token": user_token["token"]}
            if item["tvshow"]:
                query["type"] = "series"
                query["season"] = item["season"]
                query["episode"] = item["episode"]
            else:
                query["type"] = "movies"
                if item["year"]:
                    query["year_start"] = int(item["year"]) 
                    query["year_end"] = int(item["year"])

            search_result =  urlHandler.request( BASE_URL + "search/", query)
   
            if search_result is not None and search_result["result"] == "failed":
                # Update cached token
                user_token =  get_user_token(True)
                query["token"] = user_token["token"]
                search_result =  urlHandler.request( BASE_URL + "search/", query)

            if search_result is not None and search_result["result"] == "failed":
                notify(32009)
                if mode_subtitle>1:
                   return results," "," "
                else:
                   return len(results)," "," "

            log("Results: %s" % search_result)

            if search_result is None or search_result["result"] != "success" or search_result["count"] < 1:
                if mode_subtitle>1:
                   return results," "," "
                else:
                    return len(results)," "," "

            results = search_result# _filter_results(search_result["data"], search_string, item)

            log("Filtered: %s" % results)

        else:
            notify(32009)
        ret = []
        ok=True
        lang=[]
        lang.append('he')
        if all_setting["English"]== 'true':
          lang.append('eng')
        for result in results['data']:
            total_downloads = 0
            counter = 0
            
            subs_list = result
     
            if subs_list is not None:
               

                for language in subs_list['subtitles']:
                        
                        
                       if language in lang:
                    #if xbmc.convertLanguage(language, xbmc.ISO_639_2) in item["3let_language"]:
                        for current in subs_list['subtitles'][language]:
                            

                            counter += 1
                            title = current["version"]
                            subtitle_rate = 0
                            total_downloads += int(current["downloads"])
                            ret.append(
                                {   'lang_index':'0',# item["3let_language"].index('heb'),
                                    'filename': title,
                                    'link': current["key"],
                                    'language_name': xbmc.convertLanguage(language, xbmc.ENGLISH_NAME),
                                    'language_flag': language,
                                    'id': current["id"],
                                    'rating': current["downloads"],
                                    'sync': subtitle_rate >= 3.8,
                                    'hearing_imp': False,
                                    'is_preferred':
                                        xbmc.convertLanguage(language, xbmc.ISO_639_2) == item[
                                            'preferredlanguage']
                                })
            # Fix the rating
            if total_downloads:
                for it in ret[-1 * counter:]:
                    it["rating"] = str(min(int(round(float(it["rating"]) / float(total_downloads), 1) * 8), 5))

        number_of_subs=0
        x=1
        saved_data=[]
        results2= sorted(ret, key=lambda x: (x['is_preferred'], x['lang_index'], x['sync'], x['rating']), reverse=True)
        subtitle=" "
        json_data=[]
        db=[]
        if results2:
         for it in results2:

            number_of_subs=number_of_subs+1
            listitem = ListItem(label=it["language_name"],
                                        label2='[COLOR lightskyblue]'+str(x)+'. '+' [SC]' +it["filename"]+'[/COLOR]',
                                        iconImage=it["rating"],
                                        thumbnailImage=it["language_flag"]
                                        )
            if it["sync"]:
                listitem.setProperty("sync", "true")
                sync='true'
            else:
                listitem.setProperty("sync", "false")
                sync='false'

            if it.get("hearing_imp", False):
                listitem.setProperty("hearing_imp", "true")
                hearing_imp='true'
            else:
                listitem.setProperty("hearing_imp", "false")
                hearing_imp="false"

            url = "plugin://%s/?action=download&link=%s&id=%s&filename=%s&language=%s" % (
                __scriptid__, it["link"], it["id"], it["filename"], it["language_flag"])
            if it["id"] not in id_collection:
              id_collection.append(it["id"])
              if mode_subtitle>1:
                json_data={'url':url,
                             'label':it["language_name"],
                             'label2':'[COLOR lightskyblue]'+str(x)+'. '+' [SC]' +it["filename"]+'[/COLOR]',
                             'iconImage':it["rating"],
                             'thumbnailImage':it["language_flag"],
                             'hearing_imp':hearing_imp,
                             'sync':sync}
                db.append(json_data)
                #addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=listitem, isFolder=False)
                x=x+1
              else:
                json_data={'url':url,
                             'label':it["language_name"],
                             'label2':'[COLOR lightskyblue]'+str(x)+'. '+' [SC]' +it["filename"]+'[/COLOR]',
                             'iconImage':it["rating"],
                             'thumbnailImage':it["language_flag"],
                             'hearing_imp':hearing_imp,
                             'sync':sync}
                db.append(json_data)
                ok,subtitle=download(it["id"],it["language_flag"],it["link"],it["filename"],mode_subtitle)
                if ok==True:
                 return len(results2),subtitle,db
                else:
                 return 0

        if mode_subtitle>1:
          return results2,subtitle,db
        else:
          return len(results2),subtitle,db
		
def wizdom_search(item,mode_subtitle):

	 
	  try:
		imdb_id = "0"
		if Player().isPlaying():	# Enable using subtitles search dialog when kodi is not playing
			playerid_query = '{"jsonrpc": "2.0", "method": "Player.GetActivePlayers", "id": 1}'
			playerid = loads(executeJSONRPC(playerid_query))['result'][0]['playerid']
			imdb_id_query = '{"jsonrpc": "2.0", "method": "Player.GetItem", "params": {"playerid": ' + str(playerid) + ', "properties": ["imdbnumber"]}, "id": 1}'
			imdb_id = loads(executeJSONRPC (imdb_id_query))['result']['item']['imdbnumber']
			MyLog("imdb JSONPC:%s"%imdb_id)
		else:
			if labelIMDB:
				imdb_id = labelIMDB
			else:
				if isItMovie:
					imdb_id = "ThisIsMovie" #Search the movie by item['title'] for imdb_id 
				elif isItEpisode:
					imdb_id = "ThisIsEpisode" #Search by item['title'] for tvdb_id 
				else:
					imdb_id = "tt0"	# In order to show "No Subtitles Found" result => Doesn't recognize movie/episode
	  except:	pass

	  if imdb_id[:2]=="tt":	#Simple IMDB_ID

		num_of_subs,subtitle,subtitle_list=GetJson(imdb_id,mode_subtitle,item['season'],item['episode'],item['file_original_path'])

	  else:
		# Search TV Show by Title
		if item['season'] or item['episode']:
			#try:
				imdb_id = urlopen("http://api.wizdom.xyz/search.tv.php?name="+quote(item['title'])).read()


				if imdb_id<>'' and imdb_id<>"0":
					num_of_subs,subtitle,subtitle_list=GetJson(str(imdb_id),mode_subtitle,item['season'],item['episode'],item['file_original_path'])

			#except:	pass
		# Search Movie by Title+Year
		else:
			#try:
	
				imdb_id = SearchMovie(query=item['title'],year=item['year'])

				MyLog("Search IMDB:%s"%imdb_id)
				if not str(imdb_id)[:2]=="tt" and len(str(item['year']))>3:
					imdb_id = SearchMovie(query=item['title'],year=(int(item['year'])-1))

					MyLog("Search IMDB(2):%s"%imdb_id)
				if str(imdb_id)[:2]=="tt":
		
					num_of_subs,subtitle,subtitle_list=GetJson(imdb_id,mode_subtitle,0,0,item['file_original_path'])

			#except:	pass
	  if not imdb_id:

		title,year,imdb_id,season,episode,subtitle_list,num_of_subs,subtitle=ManualSearch(item['title'],1,mode_subtitle)
	  return num_of_subs,subtitle,subtitle_list
##########################################Subscene###############################
def clean_title(item):
    
    temp=re.sub("([\(\[]).*?([\)\]])", "\g<1>\g<2>", item["title"])


    temp=temp.replace("(","")
    temp=temp.replace(")","")
    temp=temp.replace("[","")
    temp=temp.replace("]","")
    temp=temp.replace("1080 HD","")
    temp=temp.replace("720 HD","")
   
 
    if "  - " in temp:
      temp=temp.split("  - ")[0]
    
    temp2=re.sub("([\(\[]).*?([\)\]])", "\g<1>\g<2>", item["tvshow"])
    temp2=temp2.replace("(","")
    temp2=temp2.replace(")","")
    temp2=temp2.replace("[","")
    temp2=temp2.replace("]","")
    if "  - " in temp2:
      temp2=temp2.split("  - ")[0]

    title = os.path.splitext(temp)
    tvshow = os.path.splitext(temp2)

    if len(title) > 1:
        if re.match(r'^\.[a-z]{2,4}$', title[1], re.IGNORECASE):
            item["title"] = title[0]
        else:
            item["title"] = ''.join(title)
    else:
        item["title"] = title[0]

    if len(tvshow) > 1:
        if re.match(r'^\.[a-z]{2,4}$', tvshow[1], re.IGNORECASE):
            item["tvshow"] = tvshow[0]
        else:
            item["tvshow"] = ''.join(tvshow)
    else:
        item["tvshow"] = tvshow[0]

	
    item["title"] = unicode(item["title"], "utf-8")
    item["tvshow"] = unicode(item["tvshow"], "utf-8")
    # Removes country identifier at the end
    item["title"] = re.sub(r'\([^\)]+\)\W*$', '', item["title"]).strip()
    item["tvshow"] = re.sub(r'\([^\)]+\)\W*$', '', item["tvshow"]).strip()


def parse_rls_title(item):
    title = regexHelper.sub(' ', item["title"])
    tvshow = regexHelper.sub(' ', item["tvshow"])

    groups = re.findall(r"(.*?) (\d{4})? ?(?:s|season|)(\d{1,2})(?:e|episode|x|\n)(\d{1,2})", title, re.I)

    if len(groups) == 0:
        groups = re.findall(r"(.*?) (\d{4})? ?(?:s|season|)(\d{1,2})(?:e|episode|x|\n)(\d{1,2})", tvshow, re.I)

    if len(groups) > 0 and len(groups[0]) >= 3:
        title, year, season, episode = groups[0]
        item["year"] = str(int(year)) if len(year) == 4 else year

        item["tvshow"] = regexHelper.sub(' ', title).strip()
        item["season"] = str(int(season))
        item["episode"] = str(int(episode))
        log("TV Parsed Item: %s" % (item,))
def get_more_data(filename):
    title, year = xbmc.getCleanMovieTitle(filename)
    tvshow=' '
    season=0
    episode=0
    try:
        yearval = int(year)
    except ValueError:
        yearval = 0
    match = re.search(r'\WS(?P<season>\d\d)E(?P<episode>\d\d)', filename, flags=re.IGNORECASE)
    if match is not None:
        title = string.strip(title[:match.start('season') - 1])
        season = string.lstrip(match.group('season'), '0')
        episode = string.lstrip(match.group('episode'), '0')

    return title,yearval,season,episode
class HeadRequest(urllib2.Request):
    def get_method(self):
        return "HEAD"
        
def normalizeString(str):
    return unicodedata.normalize(
        'NFKD', unicode(unicode(str, 'utf-8'))
    ).encode('utf-8', 'ignore')
def MyLog(msg):
	log((u"##**## [%s] %s" % ("Wizdom Subs", msg,)).encode('utf-8'), level=xbmc.LOGDEBUG)
	#logging.warning(msg)             
def download_next(location,all_setting,last_sub_download,save_all_data,max_sub):

     x=0

     __last__ = unicode(xbmc.translatePath(os.path.join(__profile__, 'last')), 'utf-8')

    
     value_for_subs=location
    


     
     enable_count=0
     total_count=0
     break_now=0

     for save_data_value in save_all_data:
       if break_now>0:
         break
       json_value2=json.loads(json.dumps(save_data_value))


       for json_value in json_value2:

        if 'label' in json_value and 'label2' in json_value and 'iconImage' in json_value and 'thumbnailImage' in json_value and 'sync' in json_value and 'hearing_imp' in json_value:
         
            
         
         params=getParams('?'+json_value['url'].split('?')[1])
         
         id = getParam("id", params)
         try:
              language=params["language"]
         except:
              language=''
         try:
              key=params["link"]
         except:
              key=''
         try:
              filename=params["filename"]
         except:
              filename=''
         try:
              source=params["source"]
         except:
              source=''
         

         if x==value_for_subs :
               notify2('Downloading')
      
               if source=='subscence':
               
                 if 'episode' in params:
                   subs = download_subscene(params["link"],1, params["episode"])
                 else:
                   subs = download_subscene(params["link"],1)
               elif source=='opensubtitle':
                   subs = Download_opensubtitle(params["ID"], params["link"],params["format"],1)
               else:
                 temp,subs = download(id,language,key,filename,1)
               try:
                 rmtree(__last__)
               except: pass
               mkdirs(__last__)
               last_sub_download=hashlib.sha256(str(json.dumps(params)).encode('utf-8','ignore')).hexdigest()
               subtitle_cache_next.set('last_sub', last_sub_download)
               if subs!='0' and subs!='NO':
                 sub=subs
                 dst=os.path.join(__last__, "last.srt")
                 copyfile(sub, dst)
                 if all_setting["enable_font"]=='true':
                   subs = srt2ass(sub,all_setting)
                 notify2('Setting sub [COLOR skyblue]'+str(total_count) +'/'+str(max_sub-1)+'[/COLOR]: ' +json_value['label2'])

                 xbmc.Player().setSubtitles(subs)
                 break_now=1
                 break
               else:
                 notify2('[COLOR red]Cannot download [/COLOR][COLOR skyblue]'+str(total_count) +'/'+str(max_sub-1)+'[/COLOR]: ' +json_value['label2'])
           

        x=x+1
        total_count=total_count+1
     return location
   

def refresh_setting():
   global __settings__,__addon__,MyAddon,MyScriptID,all_setting
   MyAddon = xbmcaddon.Addon()
   MyScriptID = MyAddon.getAddonInfo('id')
   __settings__ = xbmcaddon.Addon(id=MyScriptID)
   __addon__ = xbmcaddon.Addon()
   all_setting={}
   all_setting=({"Email":MyAddon.getSetting("Email"),
                "Password":MyAddon.getSetting("Password"),
                "action":MyAddon.getSetting("action"),
                "OSuser":MyAddon.getSetting("OSuser"),
                "OSpass":MyAddon.getSetting("OSpass"),
                "subscenter":MyAddon.getSetting("subscenter"),
                "wizrad":MyAddon.getSetting("wizrad"),
                "subscene":MyAddon.getSetting("subscene"),
                "opensubtitle":MyAddon.getSetting("opensubtitle"),
                "English":MyAddon.getSetting("English"),
                "autosub":MyAddon.getSetting("autosub"),
                "ExcludeTime":MyAddon.getSetting("ExcludeTime"),
                "ExcludeAddosOption":MyAddon.getSetting("ExcludeAddosOption"),
                "ExcludeAddos":MyAddon.getSetting("ExcludeAddos"),
                "ExcludeAddosOption2":MyAddon.getSetting("ExcludeAddosOption"),
                "ExcludeAddos2":MyAddon.getSetting("ExcludeAddos"),
                "ExcludeAddosOption3":MyAddon.getSetting("ExcludeAddosOption"),
                "ExcludeAddos3":MyAddon.getSetting("ExcludeAddos"),
                "ExcludeAddosOption4":MyAddon.getSetting("ExcludeAddosOption"),
                "ExcludeAddos4":MyAddon.getSetting("ExcludeAddos"),
                "ExcludeAddosOption5":MyAddon.getSetting("ExcludeAddosOption"),
                "ExcludeAddos5":MyAddon.getSetting("ExcludeAddos"),
                "enable_font":MyAddon.getSetting("enable_font"),
                "background":MyAddon.getSetting("background"), 
                "bold":MyAddon.getSetting("bold"),
                "size":MyAddon.getSetting("size"),
                "color":MyAddon.getSetting("color"), 
                "background_level":MyAddon.getSetting("background_level"),
                "yify":MyAddon.getSetting("yify"),
                "force":MyAddon.getSetting("force"),
                "Debug":MyAddon.getSetting("Debug")})
   temp=json.dumps(all_setting)
   return  json.loads(temp)
if not exists(MyTmp):
	mkdirs(MyTmp)



if len(sys.argv) >= 2:   
	params = getParams(sys.argv[2])

	action = getParam("action", params)

MyLog("Version:%s"%MyVersion)
MyLog("Action:%s"%action)
try:
  language=params["language"]
except:
  language=''
try:
  key=params["link"]
except:
  key=''
try:
  filename=params["filename"]
except:
  filename=''
try:
  source=params["source"]
except:
  source=''
all_setting=refresh_setting()

def search_all(mode_subtitle,all_setting):

	running=1
	if mode_subtitle==3:
	   dp = xbmcgui.DialogProgress()
	   dp.create('מקבל מידע...','Getting item info...')
	else:
	   notify2('Getting item info')
	if mode_subtitle==1:
		try:
			rmtree(cache_list_folder)
		except: pass
		mkdirs(cache_list_folder)
	item = {}
	subs=" "
	MyLog("isPlaying:%s"%Player().isPlaying())
	########################################## Get Item Data ###############################################
	if Player().isPlaying():

		item['year'] = getInfoLabel("VideoPlayer.Year")  # Year

		item['season'] = str(getInfoLabel("VideoPlayer.Season"))  # Season
		if item['season']=='' or item['season']<1:
			item['season'] = 0
		item['episode'] = str(getInfoLabel("VideoPlayer.Episode"))  # Episode

		if item['episode']=='' or item['episode']<1:
			item['episode'] = 0
		item['tvshow'] = normalizeString(xbmc.getInfoLabel("VideoPlayer.TVshowtitle"))  # Show
		if item['episode']==0:
			item['title'] = normalizeString(xbmc.getInfoLabel("VideoPlayer.OriginalTitle"))  # no original title, get just Title
		else:	
			item['title'] = normalizeString(xbmc.getInfoLabel("VideoPlayer.TVshowtitle"))  # Show
		if item['title'] == "":
			item['title'] = normalizeString(xbmc.getInfoLabel("VideoPlayer.OriginalTitle"))  # try to get original title
		item['file_original_path'] = unquote(unicode(Player().getPlayingFile(), 'utf-8'))  # Full path of a playing file
		item['file_original_path'] = item['file_original_path'].split("?")
		item['file_original_path'] = path.basename(item['file_original_path'][0])[:-4]
		#item['preferredlanguage'] = unicode(urllib.unquote(params.get('preferredlanguage', '')), 'utf-8')
		#item['preferredlanguage'] = xbmc.convertLanguage(item['preferredlanguage'], xbmc.ISO_639_2)
		item['preferredlanguage'] = 'heb'
		item['rar'] = True

	else:	# Take item params from window when kodi is not playing
		labelIMDB = getInfoLabel("ListItem.IMDBNumber")
		item['year'] = getInfoLabel("ListItem.Year")
		item['season'] = getInfoLabel("ListItem.Season")
		item['episode'] = getInfoLabel("ListItem.Episode")
		item['file_original_path'] = ""
		item['temp'] = False
		item['rar'] = False


		if item['season']=='' or item['season']<1:
			item['season'] = 0


		if item['episode']=='' or item['episode']<1:
			item['episode'] = 0
		if item['season'] == 0 or item['episode'] == 0:
		  item['tvshow'] =''
		else:
		  item['tvshow'] =take_title_from_focused_item()
		item['title'] = take_title_from_focused_item()

		item['3let_language'] = []
		#item['preferredlanguage'] = unicode(urllib.unquote(params.get('preferredlanguage', '')), 'utf-8')
		#item['preferredlanguage'] = xbmc.convertLanguage(item['preferredlanguage'], xbmc.ISO_639_2)
		item['preferredlanguage'] = 'heb'
		labelType = getInfoLabel("ListItem.DBTYPE")  #movie/tvshow/season/episode	
		isItMovie = labelType == 'movie' or getCondVisibility("Container.Content(movies)")
		isItEpisode = labelType == 'episode' or getCondVisibility("Container.Content(episodes)")

		if isItMovie:
			item['title'] = getInfoLabel("ListItem.OriginalTitle")
		elif isItEpisode:
			item['title'] = getInfoLabel("ListItem.TVShowTitle")							
		else:
			item['title'] = "SearchFor..." # In order to show "No Subtitles Found" result.
	if item['title'] == "":
	  log("VideoPlayer.OriginalTitle not found")
	  item['title'] = normalizeString(xbmc.getInfoLabel("VideoPlayer.Title"))  # no original title, get just Title

	
	clean_title(item)

	parse_rls_title(item)

 
	########################################## Get IMDB ID ###############################################
	imdb_id = 0
	try:
		if Player().isPlaying():	# Enable using subtitles search dialog when kodi is not playing
			playerid_query = '{"jsonrpc": "2.0", "method": "Player.GetActivePlayers", "id": 1}'
			playerid = loads(executeJSONRPC(playerid_query))['result'][0]['playerid']
			imdb_id_query = '{"jsonrpc": "2.0", "method": "Player.GetItem", "params": {"playerid": ' + str(playerid) + ', "properties": ["imdbnumber"]}, "id": 1}'
			imdb_id = loads(executeJSONRPC (imdb_id_query))['result']['item']['imdbnumber']

			MyLog("imdb JSONPC:%s"%imdb_id)
		else:
			if labelIMDB:
				imdb_id = labelIMDB
			else:
				if isItMovie:
					imdb_id = "ThisIsMovie" #Search the movie by item['title'] for imdb_id 
				elif isItEpisode:
					imdb_id = "ThisIsEpisode" #Search by item['title'] for tvdb_id 
				else:
					imdb_id = "tt0"	# In order to show "No Subtitles Found" result => Doesn't recognize movie/episode
	except:	pass
	if not imdb_id[:2]=="tt":	#Simple IMDB_ID

		# Search TV Show by Title
		if item['season'] or item['episode']:
			try:
				imdb_id = urlopen("http://api.wizdom.xyz/search.tv.php?name="+quote(item['title'])).read()
			except:	pass
		# Search Movie by Title+Year
		else:
			try:
				imdb_id = SearchMovie(query=item['title'],year=item['year'])
				if not imdb_id[:2]=="tt":
					imdb_id = SearchMovie(query=item['title'],year=(int(item['year'])-1))
					
					
			except:	pass
	if mode_subtitle==3:
	  dp.create('מקבל מידע...','Trying manual...')
	else:
	   notify2('Trying manual')
	if not imdb_id:
		try:
		  item['title'],item['year'],imdb_id,item['season'],item['episode'],subtitle_list,num_of_subs,subtitle=ManualSearch(item['title'],0,mode_subtitle)
		
		
		  item['year']=int(item['year'])
		  item['season']=int(item['season'])
		  item['episode']=int(item['episode'])
		
		  if item['season'] == 0 or item['episode'] == 0:
		   item['tvshow'] =''
		  else:
		   item['tvshow'] =item['title']
		except:
		   imdb_id=''

	logging.warning(imdb_id)
	if not item['tvshow'] and not (item['title'] and item['year']) :
	   item['title'],item['year'],item['season'],item['episode']=get_more_data(item['title'])
	logging.warning(item)

	
	num_of_subs=0
	save_all_data=[]
	list_hash = hashlib.sha256(str(item).encode('utf-8','ignore')).hexdigest()
	last_sub=os.path.join(cache_list_folder, list_hash)
	timed_cache=subtitle_cache.get('save')
	#num_of_subs,subtitle,saved_data=search_yify(item,imdb_id,mode_subtitle)
	if timed_cache!='save':
		try:
			rmtree(cache_list_folder)
		except: pass
		mkdirs(cache_list_folder)
	########################################## Subcenter Search ###############################################
	#popupMenu = popupBtns(title='next', btns=[1,2,3], width=0.5)
	#popupMenu.doModal()

	if path.exists(last_sub) and mode_subtitle>1:
	   file = open(last_sub, 'r') 
	   save_all_data=json.loads(file.read())

	else:
	 try:
	  try:
	     rmtree(cache_list_folder)
	  except: pass
	  mkdirs(cache_list_folder)
	  if all_setting["subscenter"]== 'true':
	    if mode_subtitle==3:
	      dp.update(0, 'Searching Subscenter')
	    else:
	      notify2('Searching Subscenter')

	    num_of_subs,subtitle,saved_data=subcenter_search(item,mode_subtitle)
	    

	    if mode_subtitle>1 and num_of_subs>0 :

	      save_all_data.append(saved_data)

	    if num_of_subs>0 and mode_subtitle==1 :

	       subs=subtitle
	       try:
	          rmtree(__last__)
	       except: pass
	       mkdirs(__last__)
	       dst=os.path.join(__last__, "last.srt")
	       copyfile(subs, dst)
	       if all_setting["enable_font"]=='true':
	         subs=srt2ass(subtitle,all_setting)
	       save_all_data.append(saved_data)
	       json_value2=json.loads(json.dumps(save_all_data))
	       params=getParams('?'+json_value2[0][0]['url'].split('?')[1])
	       last_sub_download=hashlib.sha256(str(json.dumps(params)).encode('utf-8','ignore')).hexdigest()
	       subtitle_cache_next.set('last_sub', last_sub_download)

	       xbmc.Player().setSubtitles(subs)
	       return 0
	 except:
	  if mode_subtitle>1:
	    dp.update(int((25)/100.0 * 100), '[COLOR red] Subcenter Failed [/COLOR]')
	  else:
	    notify2('[COLOR red] Subcenter Failed [/COLOR]')
	    xbmc.sleep(1000)
	########################################## Subscene Search ###############################################
	 try:

	  if all_setting["subscene"]== 'true':
	    if mode_subtitle==3:
	      dp.update(int((25)/100.0 * 100), 'Searching Subscene ')
	    else:
	      notify2('Searching Subscene ')
	    num_of_subs,subtitle,saved_data=search_subscene(item,mode_subtitle)

	    if mode_subtitle>1  and int(num_of_subs)>0:
	      save_all_data.append(saved_data)
	      #for saved_data_item in saved_data:
	      #  addDirectoryItem(handle=int(sys.argv[1]), url=saved_data_item[0], listitem=saved_data_item[1], isFolder=False)
            
	    if num_of_subs>0 and mode_subtitle==1:
	       subs=subtitle
	       try:
	          rmtree(__last__)
	       except: pass
	       mkdirs(__last__)
	       dst=os.path.join(__last__, "last.srt")
	       copyfile(subs, dst)
	       if all_setting["enable_font"]=='true':
	         subs=srt2ass(subtitle,all_setting)
	       save_all_data.append(saved_data)
	       json_value2=json.loads(json.dumps(save_all_data))
	       params=getParams('?'+json_value2[0][0]['url'].split('?')[1])
	       last_sub_download=hashlib.sha256(str(json.dumps(params)).encode('utf-8','ignore')).hexdigest()
	       subtitle_cache_next.set('last_sub', last_sub_download)


	       xbmc.Player().setSubtitles(subs)
	       return 0
	 except:
	  if mode_subtitle==3:
	    dp.update(int((25)/100.0 * 100), '[COLOR red] Subscene Failed [/COLOR]')
	  else:
	    notify2( '[COLOR red] Subscene Failed [/COLOR]')
	    xbmc.sleep(1000)
	########################################## WizDom Search ###############################################
	 MyLog("item:%s"%item)

	 try:
	  if all_setting["wizrad"]== 'true':
	  
	   if mode_subtitle==3:
	      dp.update(int((50)/100.0 * 100), 'Searching Wizdom')
	   else:
	     notify2 ( 'Searching Wizdom')
	   num_of_subs,subtitle,saved_data=wizdom_search(item,mode_subtitle)
	   if mode_subtitle>1 and num_of_subs>0:
	      save_all_data.append(saved_data)
	      #for saved_data_item in saved_data:
	      #  addDirectoryItem(handle=int(sys.argv[1]), url=saved_data_item[0], listitem=saved_data_item[1], isFolder=False)

	  if num_of_subs>0 and mode_subtitle==1:
	   subs=subtitle
	   try:
	     rmtree(__last__)
	   except: pass
	   mkdirs(__last__)
	   dst=os.path.join(__last__, "last.srt")
	   copyfile(subs, dst)
	   if all_setting["enable_font"]=='true':
	         subs=srt2ass(subtitle,all_setting)
             
	   save_all_data.append(saved_data)
	   json_value2=json.loads(json.dumps(save_all_data))

	   params=getParams('?'+json_value2[0][0]['url'].split('?')[1])

	   last_sub_download=hashlib.sha256(str(json.dumps(params)).encode('utf-8','ignore')).hexdigest()
	   subtitle_cache_next.set('last_sub', last_sub_download)


	   xbmc.Player().setSubtitles(subs)
	   return 0
	 except:
	  if mode_subtitle==3:
	    dp.update(int((50)/100.0 * 100), '[COLOR red] Wizdom Failed [/COLOR]')
	  else:
	    notify2 ( '[COLOR red] Wizdom Failed [/COLOR]')
      
	########################################## YIFY Search ###############################################
	 MyLog("item:%s"%item)


	 try:
	  if all_setting["yify"]== 'true':
	  
		 if mode_subtitle==3:
			  dp.update(int((50)/100.0 * 100), 'Searching YIFY')
		 else:
			 notify2 ( 'Searching YIFY')

		 num_of_subs,subtitle,saved_data=search_yify(item,imdb_id,mode_subtitle)

		 if mode_subtitle>1 and num_of_subs>0:
			  save_all_data.append(saved_data)

		 if num_of_subs>0 and mode_subtitle==1:
		  subs=subtitle
		  try:
			rmtree(__last__)
		  except: pass
		  mkdirs(__last__)
		  dst=os.path.join(__last__, "last.srt")
		  copyfile(subs, dst)
		  if all_setting["enable_font"]=='true':
				 subs=srt2ass(subtitle,all_setting)
				 
		  save_all_data.append(saved_data)
		  json_value2=json.loads(json.dumps(save_all_data))

		  params=getParams('?'+json_value2[0][0]['url'].split('?')[1])

		  last_sub_download=hashlib.sha256(str(json.dumps(params)).encode('utf-8','ignore')).hexdigest()
		  subtitle_cache_next.set('last_sub', last_sub_download)

		  xbmc.Player().setSubtitles(subs)
		  return 0
	 except:
	  if mode_subtitle==3:
	    dp.update(int((50)/100.0 * 100), '[COLOR red] Yify Failed [/COLOR]')
	  else:
	    notify2 ( '[COLOR red] Yify Failed [/COLOR]')
	########################################## Opensubtitle Search ###############################################
	 try:
	  if all_setting["opensubtitle"]== 'true':
	    if mode_subtitle==3:
	      dp.update(int((75)/100.0 * 100), 'Searching Opensubtitle')
	     
	    else:
	      notify2('Searching Opensubtitle')


	    subtitle,saved_data=Search_opensubtitle(item,imdb_id,mode_subtitle)
	    if mode_subtitle>1 :
	      save_all_data.append(saved_data)
	      #for saved_data_item in saved_data:
	      #  addDirectoryItem(handle=int(sys.argv[1]), url=saved_data_item[0], listitem=saved_data_item[1], isFolder=False)
	    if mode_subtitle==1:
	      subs=subtitle
	   
	      
	      try:
	        rmtree(__last__)
	        
	      except: pass
	      mkdirs(__last__)
	      dst=os.path.join(__last__, "last.srt")
	      copyfile(subs, dst)
	      if all_setting["enable_font"]=='true':
	         subs=srt2ass(subtitle,all_setting)
	      save_all_data.append(saved_data)
	      json_value2=json.loads(json.dumps(save_all_data))
	      params=getParams('?'+json_value2[0][0]['url'].split('?')[1])

	      last_sub_download=hashlib.sha256(str(json.dumps(params)).encode('utf-8','ignore')).hexdigest()
	      subtitle_cache_next.set('last_sub', last_sub_download)


	      xbmc.Player().setSubtitles(subs)
	 except:
	  if mode_subtitle==3:
	    dp.update(int((75)/100.0 * 100), '[COLOR red] Opensubtitle Failed [/COLOR]')
	  else:
	    notify2( '[COLOR red] Opensubtitle Failed [/COLOR]')
	    xbmc.sleep(1000)
	 if mode_subtitle>1:
	   f = open(last_sub, 'w') 
	
	   f.write(json.dumps(save_all_data)) 
	   f.close()
	   subtitle_cache.set('save','save')

	
	if mode_subtitle==3:
	  for save_data_value in save_all_data:
	     json_value2=json.loads(json.dumps(save_data_value))

	     for json_value in json_value2:
	   
	      if 'label' in json_value and 'label2' in json_value and 'iconImage' in json_value and 'thumbnailImage' in json_value and 'sync' in json_value and 'hearing_imp' in json_value:

	       if item['file_original_path'].replace("."," ") in json_value['label2'].replace("."," "):
	         json_value['label2']='[COLOR gold] GOLD [B]'+json_value['label2']+'[/B][/COLOR]'


	       listitem = xbmcgui.ListItem(label          = json_value['label'],
	                                label2         = json_value['label2'],
	                                iconImage      = json_value['iconImage'],
	                                thumbnailImage = json_value['thumbnailImage']
	                                )
        
	       listitem.setProperty( "sync", json_value['sync'] )
	       listitem.setProperty( "hearing_imp",json_value['hearing_imp'] )
	    
	       addDirectoryItem(handle=int(sys.argv[1]), url=json_value['url'], listitem=listitem, isFolder=False)
	if mode_subtitle==3:
	  dp.close()
	# Search Local File
	if mode_subtitle==3:
	      
	      listitem = ListItem(label=xbmcaddon.Addon().getLocalizedString(32030),label2='[COLOR plum][I]'+ xbmcaddon.Addon().getLocalizedString(32029)+'[/I][/COLOR]')
	      url = "plugin://%s/?action=download&versioname=%s&id=%s" % (MyScriptID, "1", "open_setting")
	      addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=listitem,isFolder=True)
          
	      listitem = ListItem(label=xbmcaddon.Addon().getLocalizedString(32031),label2='[COLOR khaki][I]'+ xbmcaddon.Addon().getLocalizedString(32003)+'[/I][/COLOR]')
	      url = "plugin://%s/?action=download&versioname=%s&id=%s" % (MyScriptID, "1", "clean")
	      addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=listitem,isFolder=True)

	      listitem = ListItem(label=xbmcaddon.Addon().getLocalizedString(32032),label2='[COLOR olive][I]'+ xbmcaddon.Addon().getLocalizedString(32033)+'[/I][/COLOR]')
	      url = "plugin://%s/?action=download&versioname=%s&id=%s" % (MyScriptID, "1", "keys")
	      addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=listitem,isFolder=True)


	if mode_subtitle==3:
	 endOfDirectory(int(sys.argv[1]))
	if all_setting["Debug"] == "true":
		if imdb_id[:2]=="tt":
			Dialog().ok("Debug "+MyVersion,str(item),"imdb: "+str(imdb_id))
		else:
			Dialog().ok("Debug "+MyVersion,str(item),"NO IDS")
	running=0
logging.warning('started plugin')

logging.warning(action)
if action=='search':
  search_all(3,(all_setting))
elif action == 'manualsearch':
	searchstring = getParam("searchstring", params)
	ManualSearch(searchstring,1,0)
	endOfDirectory(int(sys.argv[1]))

elif action == 'download':
	
	id = getParam("id", params)
	logging.warning(id)
	if id=='open_setting' or id=='clean' or id=='keys':
	   if id=='open_setting':
	     __settings__.openSettings()
	   elif id=='clean':
	     try:
	       rmtree(MyTmp)
	     except: pass
	     mkdirs(MyTmp)
	     try:
	       rmtree(cache_list_folder)
	     except: pass
	     mkdirs(cache_list_folder)
	     store.delete("%")
	     subtitle_cache.delete("%")
	     notify(32004)
	   
	     
	     executebuiltin((u'Notification(%s,%s)' % (MyName, MyLang(32004))).encode('utf-8'))

	   elif id=='keys':

	     xbmc.executebuiltin('RunScript(special://home/addons/script.subskeys/default.py)')

	   try:
	    
	     refresh_setting()
	     sublist=os.listdir(__last__)
	     sub=os.path.join(__last__, 'last.srt')

	     if all_setting["enable_font"]=='true':
	       sub = srt2ass(sub,all_setting)
	     listitem = ListItem(label=sub)
	     addDirectoryItem(handle=int(sys.argv[1]), url=sub, listitem=listitem,isFolder=False)
	   except:
	    pass
	    

       
	else:
	  temp=' '
	  MyLog("Download ID:%s"%id)

	  if source=='subscence':
	  
	    if 'episode' in params:
	      subs = download_subscene(params["link"],3, params["episode"])
	    else:
	      subs = download_subscene(params["link"],3)
	  elif source=='opensubtitle':
	    subs = Download_opensubtitle(params["ID"], params["link"],params["format"],3)
	  else:

	    subs,temp = download(id,language,key,filename,3)
	  try:
	    rmtree(__last__)
	  except: pass
	  mkdirs(__last__)

	  last_sub_download=hashlib.sha256(str(json.dumps(params)).encode('utf-8','ignore')).hexdigest()
	  subtitle_cache_next.set('last_sub', last_sub_download)

	  for sub in subs:
		
		listitem = ListItem(label=sub)
		dst=os.path.join(__last__, "last.srt")
		copyfile(sub, dst)
		if all_setting["enable_font"]=='true':
		  sub = srt2ass(sub,all_setting)
		

		addDirectoryItem(handle=int(sys.argv[1]), url=sub, listitem=listitem,isFolder=False)
	endOfDirectory(int(sys.argv[1]))
elif action=='clean':
	try:
		rmtree(MyTmp)
		try:
		   rmtree(cache_list_folder)
		except: pass
		store.delete("%")
		notify(32004)
	except: pass
	executebuiltin((u'Notification(%s,%s)' % (MyName, MyLang(32004))).encode('utf-8'))
elif action=='login':
	login(True)


