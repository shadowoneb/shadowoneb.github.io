# -*- coding: utf-8 -*-
import os, urllib, re, random, json, datetime, threading
import xbmcaddon, xbmc, xbmcplugin, xbmcgui,logging,urllib2

Addon = xbmcaddon.Addon(id='plugin.video.movixNS')
addonPath = xbmc.translatePath(Addon.getAddonInfo("path")).decode("utf-8")
libDir = os.path.join(addonPath, 'resources', 'lib')
sys.path.insert(0, libDir)
import   cache, ua 
addon_id     = 'plugin.video.movixNS'
AddonName = Addon.getAddonInfo("name")
icon = Addon.getAddonInfo('icon')
FANART = os.path.join(addonPath, 'fanart.jpg')
resorce_path=os.path.join(addonPath,'resources')




	
	
movies_art = os.path.join(resorce_path, 'movies.jpg')
series_art = os.path.join(resorce_path, 'series.jpg')
search_art = os.path.join(resorce_path, 'search.jpg')
Dubbed_art= os.path.join(resorce_path, 'Dubbed.jpg')
Animation_art= os.path.join(resorce_path, 'Animation.jpg')
Fantasy_art= os.path.join(resorce_path, 'Fantasy.jpg')
Israeli_art= os.path.join(resorce_path, 'Israeli.jpg')
Comedy_art= os.path.join(resorce_path, 'Comedy.jpg')
Drama_art= os.path.join(resorce_path, 'Drama.jpg')
Documentary_art= os.path.join(resorce_path, 'Documentary.jpg')
Action_art= os.path.join(resorce_path, 'Action.jpg')
Crime_art= os.path.join(resorce_path, 'Crime.jpg')
Thriller_art= os.path.join(resorce_path, 'Thriller.jpg')
War_art= os.path.join(resorce_path, 'War.jpg')
Mystery_art= os.path.join(resorce_path, 'Mystery.jpg')
Horror_art= os.path.join(resorce_path, 'Horror.jpg')
scifi_art= os.path.join(resorce_path, 'scifi.jpg')
Kids_art=os.path.join(resorce_path, 'kids.jpg')
family_art=os.path.join(resorce_path, 'family.jpg')
clean_art=os.path.join(resorce_path, 'clean.jpg')
Domain = Addon.getSetting("domain")

baseUrl = Domain[:-1] if Domain.endswith('/') else Domain
handle = int(sys.argv[1])
userAgent = Addon.getSetting("userAgent")
if userAgent == '':
	userAgent = ua.GetRandomUA()
	Addon.setSetting("userAgent", userAgent)

user_dataDir = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
if not os.path.exists(user_dataDir):
	os.makedirs(user_dataDir)
logosDir = os.path.join(user_dataDir, "logos")
if not os.path.exists(logosDir):
	os.makedirs(logosDir)
userAgents = [
	'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36',
	'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36',
	'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/600.8.9 (KHTML, like Gecko) Version/8.0.8 Safari/600.8.9',
	'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36',
	'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:40.0) Gecko/20100101 Firefox/40.0',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
	'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko',
	'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36',
	'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/600.7.12 (KHTML, like Gecko) Version/8.0.7 Safari/600.7.12',
	'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
	'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:40.0) Gecko/20100101 Firefox/40.0',
	'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0',
	'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0',
	'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36',
	'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36',
	'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36',
	'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36',
	'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36',
	'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:39.0) Gecko/20100101 Firefox/39.0',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36',
	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.10240',
	'Mozilla/5.0 (Windows NT 6.1; rv:40.0) Gecko/20100101 Firefox/40.0',
	'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
	'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36',
	'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36',
	'Mozilla/5.0 (Windows NT 5.1; rv:40.0) Gecko/20100101 Firefox/40.0',
	'Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; rv:11.0) like Gecko',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.9; rv:40.0) Gecko/20100101 Firefox/40.0',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.8.9 (KHTML, like Gecko) Version/7.1.8 Safari/537.85.17',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.5.17 (KHTML, like Gecko) Version/8.0.5 Safari/600.5.17',
	'Mozilla/5.0 (X11; Linux x86_64; rv:40.0) Gecko/20100101 Firefox/40.0',
	'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:38.0) Gecko/20100101 Firefox/38.0',
	'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.130 Safari/537.36',
	'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:39.0) Gecko/20100101 Firefox/39.0',
	'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3',
	'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/44.0.2403.89 Chrome/44.0.2403.89 Safari/537.36',
	'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36',
	'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; WOW64; Trident/6.0)',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11) AppleWebKit/601.1.56 (KHTML, like Gecko) Version/9.0 Safari/601.1.56',
	'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11) AppleWebKit/601.1.50 (KHTML, like Gecko) Version/9.0 Safari/601.1.50',
	'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.125 Safari/537.36',
	'Mozilla/5.0 (X11; Fedora; Linux x86_64; rv:40.0) Gecko/20100101 Firefox/40.0',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_2) AppleWebKit/600.3.18 (KHTML, like Gecko) Version/8.0.3 Safari/600.3.18',
	'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/43.0.2357.130 Chrome/43.0.2357.130 Safari/537.36',
	'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0; Trident/5.0;  Trident/5.0)',
	'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0;  Trident/5.0)',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36',
	'Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko',
	'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.134 Safari/537.36',
	'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36 OPR/31.0.1889.174',
	'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:40.0) Gecko/20100101 Firefox/40.0',
	'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:39.0) Gecko/20100101 Firefox/39.0',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.7; rv:40.0) Gecko/20100101 Firefox/40.0',
	'Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; Touch; rv:11.0) like Gecko',
	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
	'Mozilla/5.0 (Windows NT 6.1; rv:38.0) Gecko/20100101 Firefox/38.0',
	'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:39.0) Gecko/20100101 Firefox/39.0',
	'Mozilla/5.0 (X11; Linux x86_64; rv:38.0) Gecko/20100101 Firefox/38.0',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_5) AppleWebKit/537.78.2 (KHTML, like Gecko) Version/6.1.6 Safari/537.78.2',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.7.12 (KHTML, like Gecko) Version/7.1.7 Safari/537.85.16',
	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.130 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:38.0) Gecko/20100101 Firefox/38.0',
	'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
	'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36',
	'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.130 Safari/537.36'
]
UA = random.choice(userAgents)
def searchWs():
	search_entered = ''
	isText = False
	keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
	keyboard.doModal()
	if keyboard.isConfirmed():
		search_entered = urllib.quote_plus(keyboard.getText())
	isText = False if search_entered.strip() == '' else True
	dialog = xbmcgui.Dialog()
	filter = dialog.select("בחר סוג חיפוש", ["הכל", "סרטים", "סדרות"])
	if filter == 1:
		search_entered += "&submit=&st=Film"
	elif filter == 2:
		search_entered += "&submit=&st=Series"
	else:
		search_entered += "&submit=&st=Film"
	isYear = False
	yearsRange = list((range(datetime.datetime.now().year, 1933, -1)))
	years = [str(year) for year in yearsRange]
	years.insert(0, "הכל")
	year = dialog.select("הצג תוצאות לפי שנה", years)
	if year != 0:
		search_entered += "&yr={0}".format(years[year])
		isYear = True
	else:
		search_entered += "&yr="
	if isText or isYear:

		return IndexPage('{0}/custom-search/?keyword={1}'.format(baseUrl, search_entered))
	else:
		return False

def searchWsP(typ):
	search_entered = ''
	isText = False
	keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
	keyboard.doModal()
	if keyboard.isConfirmed():
		search_entered = urllib.quote_plus(keyboard.getText())
	isText = False if search_entered.strip() == '' else True
	if typ == '1':
		search_entered += "&sortby=movie"
	elif typ == '2':
		search_entered += "&sortby=tv-show"
	
	if isText :
		return IndexPageP('{0}/custom-search/?keyword={1}'.format(baseUrl, search_entered))
	else:
		return False


def yearWs():
	search_entered = ''
	dialog = xbmcgui.Dialog()
	isYear = False
	yearsRange = list((range(datetime.datetime.now().year, 1933, -1)))
	years = [str(year) for year in yearsRange]
	year = dialog.select("הצג תוצאות לפי שנה", years)
	if year != '':
		search_entered += "&year={0}".format(years[year])
		xbmc.log(search_entered +"<test year<"*5)
		isYear = True
	if isYear:
		return IndexPageP('{0}/search_movies?q={1}'.format(baseUrl, search_entered))
	else:
		return False


def IndexPagePremium(url):

	if baseUrl+'/movies' == url:
		addDir('[COLOR orange][B] חיפוש [/B][/COLOR]','1',13,'https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcQlAUVuxDFwhHYzmwfhcUEBgQXkkWi5XnM4ZyKxGecol952w-Rp',FANART,True)
		addDir('[COLOR orange] מיון סרטים לפי שנה [/COLOR]',' ',11,'http://i.imgur.com/jIw6Zzh.png?1',FANART ,True)
		addDir('[COLOR orange] כל הסרטים שבאתר [/COLOR]',"{0}/movies".format(baseUrl),12,'http://noobsandnerds.com/addons/cache/Addons/plugin.video.moviereleases/icon.png',FANART,True)
		addDir('[COLOR orange] הסרטים הנצפים ביותר [/COLOR]','הסרטים הנצפים ביותר|עזרו לנו להמשיך להתקיים',9,'http://i.imgur.com/9jowwKu.png',FANART,True)
		addDir('[COLOR orange] סרטים שנוספו לאחרונה [/COLOR]','id="recent-movies"|<!--recent movies tab-->',9,'http://i.imgur.com/y9T5Peo.png',FANART,True)
		addDir('[COLOR orange] הסרטים המדורגים ביותר [/COLOR]','id="top-rated-movies"|<!--top tab-->',9,'http://i.imgur.com/7y1EqNG.png',FANART,True)
		addDir('[COLOR orange] סרטים עם הכי הרבה תגובות [/COLOR]','id="most-links-movies"|<!--most linked tab-->',9,'http://i.imgur.com/87uYwaK.png',FANART,True)
   		
        
		

	if baseUrl+'/series' == url:
		addDir('[COLOR orange][B] חיפוש [/B][/COLOR]','2',13,'https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcQlAUVuxDFwhHYzmwfhcUEBgQXkkWi5XnM4ZyKxGecol952w-Rp',FANART,True)
		addDir('[COLOR orange] כל הסדרות שבאתר [/COLOR]',"{0}/series".format(baseUrl),12,'https://farm6.staticflickr.com/5602/15700070751_88d83d38fd_o_d.png',FANART,True)
		addDir('[COLOR orange] הסדרות הנצפות ביותר [/COLOR]','id="most-views-tv-shows"|<!--most commented tab-->',9,'http://i.imgur.com/9jowwKu.png',FANART,True)
		addDir('[COLOR orange] סדרות שנוספו לאחרונה [/COLOR]','id="recent-tv-shows"|<!--recent tv shows-->',9,'http://i.imgur.com/y9T5Peo.png',FANART,True)
		addDir('[COLOR orange] הסדרות המדורגות ביותר [/COLOR]','id="top-rated-tv-shows"|<!--top tab-->',9,'http://i.imgur.com/7y1EqNG.png',FANART,True)
		addDir('[COLOR orange] סדרות עם הכי הרבה תגובות [/COLOR]','id="most-links-tv-shows"|<!--most linked tab-->',9,'http://i.imgur.com/87uYwaK.png',FANART,True)


def IndexPage_dub(url):

	if not 'page' in url:
		if 'search' in url:
			url = url
			current_page = 0
		else:
			url = url + '/page/0'

			current_page = int(url.split('/')[-1])
	else:
	  current_page = int(url.split('/')[-1])
	#for pageIndex in range(10):
		#try:
	matches, last_page, step =cache.get(IndexPage_regex, 72, url, table='pages')
	for item in matches:
				name = item[3]

				#if item[0].strip() != '':
					#name = '[COLOR red] למנויים[/COLOR] ' + name
				#	continue
				if "מדובב" in name:
				  addDir(name, item[2], 4, item[1],FANART, True, item[4])
		#except Exception as ex:
		#	xbmc.log(str(ex), 3)
	if current_page >= last_page:
			return True
	current_page += step
	url = url[:url.rfind('/')+1]
	url += str(current_page)

	if current_page <= last_page:
		addDir('[COLOR blue]תוצאות נוספות[/COLOR]', url, 2, '','')
	return True


def IndexPage(url):

	if not 'page' in url:
		if 'search' in url:
			url = url
			current_page = 0
		else:
			url = url + '/page/0'

			current_page = int(url.split('/')[-1])
	else:
	  current_page = int(url.split('/')[-1])
	#for pageIndex in range(10):
		#try:
	matches, last_page, step =cache.get(IndexPage_regex, 72, url, table='pages')
	for item in matches:
				name = item[3]

				#if item[0].strip() != '':
					#name = '[COLOR red] למנויים[/COLOR] ' + name
				#	continue
			
				addDir(name, item[2], 4, item[1],FANART, True, item[4])
		#except Exception as ex:
		#	xbmc.log(str(ex), 3)
	if current_page >= last_page:
			return True
	current_page += step
	url = url[:url.rfind('/')+1]
	url += str(current_page)

	if current_page <= last_page:
		addDir('[COLOR blue]תוצאות נוספות[/COLOR]', url, 2, '','')
	return True


def IndexPage_regex(url):
	import cloudflare
	
	result, cookie = cloudflare.request(url)

	if 'search' not in url:
	 last_page, step = GetPagegSteps(result, int(url.split('/')[-1]))
	else:
	  last_page=0
	  step=0

	matches = re.compile('<div class="item">.+?<img src="(.+?)".+?<h4(.+?)</h4>.+?<p>(.+?)</p>.+?<a href="(.+?)".+?</div>',re.DOTALL).findall(result)

	showImages = Addon.getSetting('showImages') == 'true'
	list=[]
	for match in matches:

		#if match[0].strip() != '':
		#	continue

		if showImages:
			try:
				logoUrl = match[0]
				logoFile = os.path.join(logosDir, logoUrl[logoUrl.rfind('/')+1:])
				if not os.path.isfile(logoFile):
					threading.Thread(target=getImageLinkBackground, args=(logoUrl, logoFile, cookie, )).start()
			except Exception as ex:
				logoFile = ''
				xbmc.log("{0}".format(ex), 3)
		else:
			logoFile = ''


		list.append(('NOT RELEVENT', logoFile,match[3] ,match[1].replace(' class="hew-title">','') , match[2]))
	return list, last_page, step

def IndexPageP(url):
	url = url + '&page=/0'
	current_page = int(url.split('/')[-1])       
	for pageIndex in range(10):
		try:
			matches, last_page, step = cache.get(IndexPagePs_regex, 72, url, table='pages')
			for item in matches:
				name = item[2]
				addDir(name, '{0}{1}'.format(baseUrl, item[1]), 4, item[0],FANART, True, item[3],isPrem=True)# m5
		except Exception as ex:
			xbmc.log(str(ex), 3)
		if current_page >= last_page:
			return True
		current_page += step
		url = url[:url.rfind('/')+1]
		url += str(current_page)

	if current_page <= last_page:
		addDir('[COLOR cyan]תוצאות נוספות[/COLOR]', url, 2, '','')
	return True

def IndexPageP_regex(url):
	import cloudflare

	result, cookie = cloudflare.request(url)
	last_page, step = GetPagegSteps(result, int(url.split('/')[-1]))
	matches = re.compile('<div id="movie\d+" class="ic_container">\s+(.*?)<img src="(.*?)".*?<h3><a href="(.*?)">(.*?)<.*?<p class="ic_text">\s+(.*?)\s+<\/p>',re.S).findall(result)
	showImages = Addon.getSetting('showImages') == 'true'
	list=[]
	for match in matches:
		if match[0].strip() == '':
			continue
		if showImages:
			try:
				logoUrl = match[1]
				logoFile = os.path.join(logosDir, logoUrl[logoUrl.rfind('/')+1:])
				if not os.path.isfile(logoFile):
					threading.Thread(target=getImageLinkBackground, args=(logoUrl, logoFile, cookie, )).start()
			except Exception as ex:
				logoFile = ''
				xbmc.log("{0}".format(ex), 3)
		else:
			logoFile = ''
		list.append((logoFile, match[2], match[3], match[4]))
	return list, last_page, step

def IndexPagePs(url):
	url = url + '/page/0'
	current_page = int(url.split('/')[-1])       

	for pageIndex in range(10):
		#try:
		matches, last_page, step = cache.get(IndexPagePs_regex, 72, url, table='pages')
		for item in matches:
			name = item[2]
			addDir(name, '{0}{1}'.format(baseUrl, item[1]), 4, item[0],FANART, True, item[3],isPrem=True)# m5
		#except Exception as ex:
		#	xbmc.log(str(ex), 3)
		if current_page >= last_page:
			return True
		current_page += step
		url = url[:url.rfind('/')+1]
		url += str(current_page)

	if current_page <= last_page:
		addDir('[COLOR cyan]תוצאות נוספות[/COLOR]', url, 2, '','')
	return True

def IndexPagePs_regex(url):
	import cloudflare

	result, cookie = cloudflare.request(url)
	last_page, step = GetPagegSteps(result, int(url.split('/')[-1]))
	#patr ='(?s)<div id="movie\d+".*?div class="sub">.*?Movix.*?<img src="(.*?)".*?<h3><a href="(.*?)">(.*?)<.*?<p class="ic_text">\s+(.*?)\s+<\/p>'
	patr ='(?s)<div id="movie\d+".*?<img src="(.*?)".*?<h3><a href="(.*?)">(.*?)<.*?<p class="ic_text">\s+(.*?)\s+<\/p>'
	matches = re.compile(patr,re.S).findall(result)
 	showImages = Addon.getSetting('showImages') == 'true'
	list=[]
	for match in matches:
		if showImages:
			try:
				logoUrl = match[0]
				logoFile = os.path.join(logosDir, logoUrl[logoUrl.rfind('/')+1:])
				if not os.path.isfile(logoFile):
					threading.Thread(target=getImageLinkBackground, args=(logoUrl, logoFile, cookie, )).start()
			except Exception as ex:
				logoFile = ''
				xbmc.log("{0}".format(ex), 3)
		else:
			logoFile = ''
		list.append((logoFile, match[1], match[2], match[3]))
	return list, last_page, step

def getImageLinkBackground(logoUrl, logoFile, cookie):
	import cloudflare
	data = cloudflare.request(logoUrl)#common.OPEN_URL(logoUrl, headers={'Cookie': cookie})
	if data[0]==None:
	  data = cloudflare.request(logoUrl)
	with open(logoFile, 'wb') as f:
		f.write(data[0])

def GetPagegSteps(result, current_page):
	'''
	block = re.compile("<span class='pages'>(.*?)>Last &raquo;</a>",re.I+re.M+re.U+re.S).findall(result)

	pages = "" if len(block) == 0 else re.compile('href=".*?[\/&]page[=]?\/(.*?)\/">(.*?)</a>',re.I+re.M+re.U+re.S).findall(block[0])

	last_page =re.compile('<a class="last" href=".*?[\/&]page[=]?\/(.*?)\/"',re.I+re.M+re.U+re.S).findall(block[0])[0]
	'''

	block = re.compile("<span class='page(.+?)</div>",re.I+re.M+re.U+re.S).findall(result)
	pages = "" if len(block) == 0 else re.compile('href=".*?[\/&]page[=]?\/(.*?)\/">(.*?)</a>',re.I+re.M+re.U+re.S).findall(block[0])
	nextPagesCount = len(pages)
	step = 10000 if nextPagesCount == 0 else int(pages[0][0]) - current_page

	
	
	last_page = current_page if nextPagesCount == 0 else int(pages[-1][0])
	for i in range(nextPagesCount-1, -1, -1):
		if pages[i][1] == '':
			continue
		if int(pages[i][0]) > last_page:
			last_page = int(pages[i][0])
		break

	return last_page, step


def addDir(name, url, mode, iconimage,fanart, isFolder=True, description='', isPrem=False):
	#u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)+"&isprem="+str(isPrem)
	fanart=iconimage
	xbmc.log("-"*40+str(url)+str(mode))
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+"&isprem="+str(isPrem)
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name , "Plot": str(description)} )
	liz.setProperty("fanart_Image", fanart)
	if not isFolder:
		liz.setProperty("IsPlayable","true")
	xbmcplugin.addDirectoryItem(handle=handle,url=u,listitem=liz,isFolder=isFolder)

def GetSeasons(series_num, iconimage, description, color):
	seasons = cache.get(GetSeasons_regex, 168, series_num,table="pages")
	for link,season in seasons:
		if params.get("isprem") == "True":
			addDir('[COLOR blue]{0} - {1}[/COLOR]'.format(name, season, color), url+'$$'+season, 3, iconimage,FANART, True, description,isPrem=True)
		else :
			addDir('[COLOR blue]{0} - {1}[/COLOR]'.format(name, season, color), url+'$$'+season, 3, iconimage,FANART, True, description)

def GetSeasons_regex(series_num):
	import cloudflare

	result,type = cloudflare.source(series_num)
	matches = re.compile('<a href="#profile(.+?)"+?>(.+?)</a>',re.DOTALL).findall(result)

	return matches

def GetEpisodes(url2, iconimage, description):

	

	wanted_season=url2.split('$$')[1].replace("עונה ",'')
	season_num=url2.split('$$')[0]
	episodes = cache.get(GetEpisodes_regex, 24, season_num, table="pages")
	#url = season_num.replace('get_episodes', 'get_episode')
	for value,season,episode in episodes:
		season_n=season.replace("עונה ",'')
		episode_n=episode.replace("פרק ",'')

		if wanted_season==season_n:
		 if params.get("isprem") == "True" :
		 	addDir('[COLOR blue]{0} - {1}[/COLOR]'.format(name, episode), "url={0}&mid={1}&sesion={2}&episode={3}&end".format(url,value,  season_n,episode_n), 4, iconimage,FANART, True, description,isPrem=True)
		 else :
		 	addDir('[COLOR blue]{0} - {1}[/COLOR]'.format(name, episode), "url={0}&mid={1}&sesion={2}&episode={3}&end".format(url,value,  season_n,episode_n), 4, iconimage,FANART, True, description)

def GetEpisodes_regex(season_num):
	import cloudflare
	
	result,type = cloudflare.source(season_num)

	matches = re.compile('class="listep" data-value="(.+?)" data-value2="(.+?)" data-value3="(.+?)"',re.DOTALL).findall(result)

	return matches

def SortByQuality(links):
	qualitiesList = ["1080p", "720p", "BDRip", "BRRip", "DVDRip", "HDTV", "HDRip", "R5", "DVDSCR", "WEBRip", "PDTV", "TVRip", "TC", "HDTS", "TS", "CAM"]
	sortedLinks = []
	random.seed()
	random.shuffle(links)
	for quality in qualitiesList:
		qualityLinks = [link for link in links if link[1].lower() == quality.lower()]
		for qualityLink in qualityLinks:
			sortedLinks.append(qualityLink)
	for link in links:
		if link[1] not in qualitiesList:
			sortedLinks.append(link)
	return sortedLinks
def _callback(matches):
    id = matches.group(1)
    try:
        return unichr(int(id))
    except:
        return id

def decode_unicode_references(data):
    return re.sub("&#(\d+)(;|(?=\s))", _callback, data)
def LinksPage(url, iconimage, description):

	reload(sys)
	sys.setdefaultencoding("utf-8")


	import login,logg
	color = ''
	xbmc.log("-"*50+str(params))
	username = Addon.getSetting('username')
	movieid = url.split('-')[-1]
	if params.get("isprem") == "True":
		data = login.login(movieid)
		logg.logGA(username,url.split('/')[-1])
		xbmc.log("-"*50+str(data))
	else:
		data = False		
		if username == '' : 
                        logg.logGA('Free user',url.split('/')[-1])
	descriptions, links, seasons =cache.get(Links_regex, 72, url, table="pages")

	if data:
		color = "blue"
		links = []
		for key in data.keys():
			links.append((data.get(key).get('Server name'), data.get(key).get('Quality'), data.get(key).get('Direct link')))
		if data.get(key).get('Episode') == '':
			seasons = False
		else:
			seasons = True
		xbmc.executebuiltin("Notification(Movix.me, Showing premium response.,5000)")
	else:
		xbmc.executebuiltin("Notification(Movix.me, Showing normal response.,5000)")
	description = decode_unicode_references(descriptions)
	try:
		if len(descriptions) == 1:
			description = descriptions[0]
	except:
		xbmc.log("descriptions issue : "+"+++"*10)

	if seasons is None:
		addDir('[COLOR red] לא נמצאו מקורות ניגון [/COLOR]','99',99,'','',False, description)
		if not data:
			return
	elif seasons:
		if data:
			color = "blue"
		series_num = url.split('-')[-1]
		GetSeasons(url, iconimage, description, color)
	else:
		try:
			if len(links) < 1:
				addDir('[COLOR red] לא נמצאו מקורות ניגון [/COLOR]','99',99,'','',False, description)
				xbmc.log("&&&"*30)
				return
			elif len(links) > 1:
				links = SortByQuality(links)
				playingUrlsList = []
				for link in links:
					xbmc.log(str(link))
					playingUrlsList.append(link[2])
				addDir('[COLOR red] בחר בניגון אוטומטי [/COLOR]','99',99,'','',False, description)
				addDir('[COLOR white] - ניגון אוטומטי[/COLOR][COLOR blue]{0}[/COLOR]'.format(name, color), json.dumps(playingUrlsList), 7, iconimage,FANART, False, description)
				addDir('[COLOR red]  או בחר מקור לניגון, אם לא עובד נסה אחר [/COLOR]','99',99,'','',False, description)
			for link in links:
				addDir("[COLOR white]{2} - איכות - {0} - [/COLOR][COLOR blue]{1}[/COLOR]".format(link[0], name, link[1], color),link[2],5,iconimage,FANART,False, description)
			return
		except Exception, e:
			xbmc.log(str(e)+"+++"*50)

	if seasons is None:
		try:
			if len(links) < 1:
				addDir('[COLOR red] לא נמצאו מקורות ניגון [/COLOR]','99',99,'',False, description)
				return
			elif len(links) > 1:
				links = SortByQuality(links)
				playingUrlsList = []
				for link in links:
					xbmc.log(str(link))
					playingUrlsList.append(link[2])
				addDir('[COLOR red] בחר בניגון אוטומטי [/COLOR]','99',99,'','',False, description)
				addDir('[COLOR {1}]{0} - ניגון אוטומטי[/COLOR]'.format(name), json.dumps(playingUrlsList), 7, iconimage,FANART, False, description)
				addDir('[COLOR red]  או בחר מקור לניגון, אם לא עובד נסה אחר [/COLOR]','99',99,'','',False, description)
			for link in links:
				addDir("[COLOR {3}]{0} - {1} - איכות {2}[/COLOR]".format(name, link[0], link[1], color),link[2],5,iconimage,FANART,False, description)
		except Exception, e:
			xbmc.log(str(e)+"+++"*50)

def Links_regex(url):
	import resolver
	import cloudflare,gzip,zlib
	from StringIO import StringIO

	result,type=cloudflare.source(url)
	if type==1:
	 result=(zlib.decompress(result, 16+zlib.MAX_WBITS))
	if result is None:
		xbmc.log('Cannot load Links Page. ({0})'.format(url), 2)
		return None
	matches = re.compile('Direct Watch</a>(.+?)</table>',re.I+re.M+re.U+re.S).findall(result)
	matches2 = re.compile('<div class="col-md-12">(.+?)</button>',re.I+re.M+re.U+re.S).findall(result)
	desc=re.compile('</div><p>(.+?)</p>',re.DOTALL).findall(result)
	if len (desc)==0:
	  desc.append(" ")


	links=None
	if 'תוכן זה זמין כעת למנויי Movix בלבד!' in result:
		seasons = None
	elif 'episode' in result and 'onclick="hoowzat' not in result:

		seasons = True
	else:
		if type==1:
		  links = resolver.GetLinks(result)
		else:
		  links = resolver.GetLinks(matches+matches2)
		seasons = False
		
	return [desc[0],links,seasons]

def PlayWs(url, autoPlay=False):

	import urlresolver,resolver
	#url = resolver.CheckAdFlyLink(url)
	try:
		item = urlresolver.HostedMediaFile(url)

		url2 = urlresolver.resolve(item.get_url())

		'''
		if url and baseUrl in url:
					#xbmc.log(str(url)+"+"*40)
			url = resolver.ResolveUrl(url)
		elif "vidlockers" in url:
			item = urlresolver.HostedMediaFile(url)
			url = urlresolver.resolve(item.get_url())
		'''

		#link = url.split(';;')
		#xbmc.log(str(url)+"="*40)
		#xbmc.executebuiltin("PlayMedia(https://ph2dw5.oloadcdn.net/dl/l/BIdFVvXpzQRZ5UVW/lZ33PBNNqoY/Angry.Birds.2016.1080p.BluRay.x264-GECKOS-HebDub.mkv.mp4)")
		listitem = xbmcgui.ListItem(path=url2)
		xbmcplugin.setResolvedUrl(handle, True, listitem)
		
		while not xbmc.Player().isPlaying():
				xbmc.sleep(10) #wait until video is being played
		#xbmc.Player().setSubtitles(link[1])
		return True
	except:
	    return False


def AutoPlayUrl(urls):
	
	playingUrlsList = json.loads(urls)
	dp = xbmcgui.DialogProgress()
	dp.create('מחפש מקורות','Searching...')
	dp.update(0, 'Searching sources')
	x=0
	for playingUrl in playingUrlsList:

		if dp.iscanceled(): 
		  dp.close()
		  break
		dp.update(int((x)/float(len(playingUrlsList)) * 100), 'Trying:' + playingUrl,str(x)+'/'+str(len(playingUrlsList)))
		x=x+1
		if PlayWs(playingUrl, autoPlay=True):
			dp.close()
			return
	dp.close()
	dialog = xbmcgui.Dialog()
	ok = dialog.ok('OOOPS', 'לא נמצאו מקורות זמינים לניגון')

def PlayTrailer(url):
	matches = cache.get(Trailer_regex, 24, url, table="pages")
	if len(matches) > 0:
		url = matches[0]
		PlayWs(url)

def Trailer_regex(url):
	import cloudflare
	result,type = cloudflare.source(url)
	matches = re.compile('"videoUrl":"(.+?)"',re.I+re.M+re.U+re.S).findall(result)
	return matches

def Categories():
	#import cloudflare
	#page = cloudflare.request("http://rads.stackoverflow.com/amzn/click/0415376327")
	


	logging.warning(family_art)

	#addDir("[COLOR orange][B]Premium Movies - סרטים פרימיום[/B][/COLOR]","{0}/all-movies/".format(baseUrl),202,'http://noobsandnerds.com/addons/cache/Addons/plugin.video.moviereleases/icon.png',FANART)
	#addDir("[COLOR orange][B]Premium Series - סדרות פרימיום[/B][/COLOR]","{0}/series".format(baseUrl),202,'https://farm6.staticflickr.com/5602/15700070751_88d83d38fd_o_d.png',FANART)
	addDir("Free Movies - כל הסרטים","{0}/all-movies".format(baseUrl),2,movies_art,movies_art)
	addDir("Free Series - כל הסדרות","{0}/all-series/".format(baseUrl),2,series_art,series_art)
	addDir("[COLOR skyblue]Clear data - ניקוי נתונים[/COLOR]","fullClean",22,clean_art,clean_art)
	addDir("[COLOR bisque][I]Search - חיפוש[/I][/COLOR]"," ",6,search_art,search_art)
	addDir("Dubbed - מדובבים","{0}/category/kids".format(baseUrl),23,Dubbed_art,Dubbed_art)
	addDir("Kids - ילדים","{0}/category/kids".format(baseUrl),2,Kids_art,Kids_art)
	addDir("Animation - אנימציה","{0}/category/animation".format(baseUrl),2,Animation_art,Animation_art)
	addDir("Fantasy - פנטזיה","{0}/category/fantasy".format(baseUrl),2,Fantasy_art,Fantasy_art)
	addDir("Family - משפחה","{0}/category/family".format(baseUrl),2,family_art,family_art)
	addDir("Israeli - ישראלי","{0}/category/israeli".format(baseUrl),2,Israeli_art,Israeli_art)
	#addDir("Live Shows - הופעות חיות","{0}/category/LiveShow".format(baseUrl),2,'https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcR1kNugU_x7YQtz7Crjr1UmwOJRyxFC25zDwIkXc5jNQszermsw',FANART)
	addDir("Comedy - קומדיה","{0}/category/comedy".format(baseUrl),2,Comedy_art,Comedy_art)
	addDir("Drama - דרמה","{0}/category/drama".format(baseUrl),2,Drama_art,Drama_art)
	addDir("Documentary - דוקומנטרי","{0}/category/Documentary".format(baseUrl),2,Documentary_art,Documentary_art)
	addDir("Action - פעולה","{0}/category/action".format(baseUrl),2,Action_art,Action_art)
	addDir("Crime - פשע","{0}/category/crime".format(baseUrl),2,Crime_art,Crime_art)
	addDir("Thriller - מתח","{0}/category/thriller".format(baseUrl),2,Thriller_art,Thriller_art)
	addDir("War - מלחמה","{0}/category/war".format(baseUrl),2,War_art,War_art)
	addDir("Mystery - מיסתורין","{0}/category/mystery".format(baseUrl),2,Mystery_art,Mystery_art)
	addDir("Horror - אימה","{0}/category/horror".format(baseUrl),2,Horror_art,Horror_art)
	addDir("Sci-Fi - מ.בדיוני","{0}/category/sci-Fi".format(baseUrl),2,scifi_art,scifi_art)
	xbmc.executebuiltin('Container.SetViewMode(500)')

def MostInCategory(category):
	matches = cache.get(MostInCategory_regex, 0, baseUrl,category , table="pages") if 'recent' in category else cache.get(MostInCategory_regex, 24, baseUrl, category ,table="pages")
	for match in matches:
		addDir(match[2], match[1], 4, match[0],FANART, True, ' ', isPrem=True)

def MostInCategory_regex(url ,category):
	import cloudflare
	html , cookie = cloudflare.request(url)
	
	if category != '':
		delim = category.split('|')
		startBlock = html.find(delim[0])
		endBlock = html.find(delim[1], startBlock)
		if delim[0] == 'הסרטים הנצפים ביותר':
			rej = '<div style="float.*?src="(.*?)".*?<a href="(.*?)"><span.*?>(.*?)</span>'
		else:
			rej = '<div class="small-item".*?src="(.*?)".*?<a href="(.*?)">(.*?)</a>'
		block = html[startBlock:endBlock]
		matches = re.compile(rej, re.I+re.M+re.U+re.S).findall(block)
		items = []
		showImages = Addon.getSetting('showImages') == 'true'
                for match in matches:
                        if showImages:
                                try:
                                        logoUrl = match[0]
                                        if not logoUrl.startswith('/') :
                                                logoUrl = '/' + logoUrl
                                        if  baseUrl not in logoUrl :
                                                logoUrl = "{0}{1}".format(baseUrl, logoUrl)
                                        logoFile = os.path.join(logosDir, logoUrl[logoUrl.rfind('/')+1:])
                                        if not os.path.isfile(logoFile):
                                                threading.Thread(target=getImageLinkBackground, args=(logoUrl, logoFile, cookie, )).start()
                                except Exception as ex:
                                        logoFile = ''
                                        xbmc.log("{0}".format(ex), 3)
                        else:
                                logoFile = ''
		
			items.append((logoFile,'{0}{1}'.format(baseUrl, match[1]), match[2]))
		
	return items

def ClearCache():
	cache.clear(['cookies', 'pages'])

def DeleteImages():
	for the_file in os.listdir(logosDir):
		file_path = os.path.join(logosDir, the_file)
		try:
			if os.path.isfile(file_path):
				os.unlink(file_path)
		except Exception as ex:
			xbmc.log("{0}".format(ex), 3)

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]

	return param


params=get_params()

try:
	url=urllib.unquote_plus(params["url"])
except:
	url=None
try:
	name=urllib.unquote_plus(params["name"])
except:
	name=None
try:
	mode=int(params["mode"])
except:
	mode=None
try:
	iconimage=urllib.unquote_plus(params["iconimage"])
except:
	iconimage=""
try:
	description=urllib.unquote_plus(params["description"])
except:
	description=""

updateView = True

if mode==None or url==None or len(url)<1:
	Categories()
elif mode==2:
	IndexPage(url)
elif mode==202:
	IndexPagePremium(url)
elif mode==3:
	GetEpisodes(url, iconimage, description)
elif mode==4:
	LinksPage(url, iconimage, description)
elif mode==5:
	PlayWs(url)
elif mode==6:
	updateView = searchWs()
elif mode==7:
	AutoPlayUrl(url)
elif mode==8:
	PlayTrailer(url)
elif mode==9:
	MostInCategory(url)
elif mode==11:
	updateView = yearWs()
elif mode==10:
	IndexPageP(url)
elif mode==12:
	IndexPagePs(url)

elif mode==13:
	updateView = searchWsP(url)
elif mode==20:
	xbmc.executebuiltin("XBMC.Notification({0}, ניקוי מטמון.., {1}, {2})".format(AddonName, 5000 ,icon))
	ClearCache()
	xbmc.executebuiltin("XBMC.Notification({0}, ניקוי מטמון הסתיים., {1}, {2})".format(AddonName, 5000 ,icon))
	updateView = False
elif mode==21:
	xbmc.executebuiltin("XBMC.Notification({0}, ניקוי תמונות..., {1}, {2})".format(AddonName, 300000 ,icon))
	DeleteImages()
	xbmc.executebuiltin("XBMC.Notification({0}, ניקוי תמונות הסתיים., {1}, {2})".format(AddonName, 5000 ,icon))
	updateView = False
elif mode==22:
	xbmc.executebuiltin("XBMC.Notification({0}, ניקוי נתונים..., {1}, {2})".format(AddonName, 300000 ,icon))
	ClearCache()
	DeleteImages()
	xbmc.executebuiltin("XBMC.Notification({0}, ניקוי נתונים הסתיים., {1}, {2})".format(AddonName, 5000 ,icon))
	updateView = False
elif mode==23:
	IndexPage_dub(url)
	
if updateView:
	xbmcplugin.setContent(handle, 'episodes')
	if mode==None or url==None or len(url)<1:
		xbmc.executebuiltin("Container.SetViewMode(500)")
	else:
		xbmc.executebuiltin('Container.SetViewMode(515)')
	xbmcplugin.endOfDirectory(handle)
