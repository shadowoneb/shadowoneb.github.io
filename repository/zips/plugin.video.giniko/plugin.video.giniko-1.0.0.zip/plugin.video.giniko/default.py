# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys,logging

__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
__plugin__ = 'plugin.video.giniko'
__settings__ = xbmcaddon.Addon(id=__plugin__)
Addon = xbmcaddon.Addon(id=__plugin__)



def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     

###############################################################################################################        
def addNolink( name, url,mode,isFolder, iconimage="DefaultFolder.png"):
 

          
          name='[COLOR aqua][I]'+name+'[/I][/COLOR]'
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name)   })

          liz.setProperty("IsPlayable","false")
          
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)
def addDir3(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
      
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        
        return ok


def addLink( name, url,mode,isFolder, iconimage="DefaultFolder.png",fanart="DefaultFolder.png",description=''):
 

          
         
         
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+str(description)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name), "Plot": description   })

          liz.setProperty("IsPlayable","true")
          liz.setProperty( "Fanart_Image", fanart )
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)

def read_site_html(url):
    import cookielib
    import urllib2
    value=''
    cookies = cookielib.LWPCookieJar()
    handlers = [
        urllib2.HTTPHandler(),
        urllib2.HTTPSHandler(),
        urllib2.HTTPCookieProcessor(cookies)
        ]
    opener = urllib2.build_opener(*handlers)
    req = urllib2.Request(url)
    req.add_header('User-agent',__USERAGENT__)
    result= opener.open(req)
    for cookie in cookies:
        if cookie.name=='DRIVE_STREAM':
          value=cookie.value

    return result.read(),value
def main_menu():
  '''
  html,cookie=read_site_html('http://www.giniko.com/watch-all-channels.php')
  regex='<div class="img" data-preview.+?img src="(.+?)".+?original-title="(.+?)"><strong>(.+?)</strong>.+?<a href="(.+?)">'
  match=re.compile(regex,re.DOTALL).findall(html)
  for image,plot,name,url in match:
    addDir3(name,'http://www.giniko.com/'+url,mode,'http://www.giniko.com/'+image,'http://www.giniko.com/'+image,plot)
  '''
  html,cookie=read_site_html('http://www.giniko.com/watch-all-channels.php')
  regex='class="pglink">(.+?)</a>'
  match=re.compile(regex).findall(html)
  for pages in match:
    html,cookie=read_site_html('http://www.giniko.com/watch-all-channels.php?&list=%s&asc=1'% pages)
    regex='<div class="img" data-preview.+?img src="(.+?)".+?<a href="(.+?)".+?original-title="(.+?)".+?strong>(.+?)</strong>'
    match=re.compile(regex,re.DOTALL).findall(html)
    for image,url,plot,name, in match:
      addLink( name, 'http://www.giniko.com/'+url,2,False, 'http://www.giniko.com/'+image,'http://www.giniko.com/'+image,plot)
      
def play_link(name,url):
    logging.warning(url)
    html,cookie=read_site_html(url)
    regex='<video data-title.+?src="(.+?)"'
    match=re.compile(regex,re.DOTALL).findall(html)
    final_link=match[0]
    listItem = xbmcgui.ListItem(name, path=final_link) # + '|' + 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    listItem.setInfo(type='Video', infoLabels={ "Title": name})
    listItem.setInfo( type="Music", infoLabels={ "Title": name } )
    listItem.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
params=get_params()

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
   


if mode==None or url==None or len(url)<1:
        main_menu()
elif mode==2:
     play_link(name,url)
xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
xbmc.executebuiltin("Container.SetViewMode(504)")

xbmcplugin.endOfDirectory(int(sys.argv[1]))

