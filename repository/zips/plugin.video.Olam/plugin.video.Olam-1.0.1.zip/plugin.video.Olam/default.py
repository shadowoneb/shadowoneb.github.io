# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys,logging,urlresolver,socket,httplib,dns.resolver
from HTMLParser import HTMLParser


__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
__settings__ = xbmcaddon.Addon(id='plugin.video.Olam')
class MyHTTPConnection (httplib.HTTPConnection):
    def connect (self):
        
            resolver = dns.resolver.Resolver()
            resolver.nameservers = ['8.8.4.4']
            answer = resolver.query(self.host,'A')
            self.host = answer.rrset.items[0].address
            self.sock = socket.create_connection ((self.host, self.port))

class MyHTTPHandler (urllib2.HTTPHandler):
    def http_open (self, req):
        return self.do_open (MyHTTPConnection, req)
def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     


###############################################################################################################        

def addDir3(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        
        return ok


def addLink( name, url,mode,isFolder,original_name, iconimage="DefaultFolder.png"):
 

          
         
         
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&original_name="+urllib.quote_plus(original_name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name)   })

          liz.setProperty("IsPlayable","true")
          
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)
def play_direct_link(url,original_name):
   try:
    videoPlayListUrl = urlresolver.HostedMediaFile(url=url).resolve()
    logging.warning(videoPlayListUrl)
    if not videoPlayListUrl:
      logging.warning( "URL " + url + " could not have been resolved to a movie.\n")
      xbmcgui.Dialog().notification('Tv', "URL could not have been resolved to a movie.\n", xbmcgui.NOTIFICATION_INFO,1000 )
      videoPlayListUrl=url
    #addon.resolve_url(stream_url)
    #videoPlayListUrl = urllib.unquote(videoUrl[0])
    
    listItem = xbmcgui.ListItem(original_name, path=videoPlayListUrl) # + '|' + 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    listItem.setInfo(type='Video', infoLabels={ "Title": original_name})
    listItem.setProperty('IsPlayable', 'true')
    print "video url " + videoPlayListUrl
    #xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(videoPlayListUrl)
    xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
   except:
    xbmcgui.Dialog().notification('Tv', "Fail to play.\n", xbmcgui.NOTIFICATION_INFO,1000 )
  
  
def play_link(url,name,iconimage):
    html=read_site_html(url)
    match=re.compile('<strong><a href="(.+?)">').findall(html)
    x=1
    
    for links in match:
      logging.warning(links)
      names=links.split('/')[2]
      logging.warning(links.split('/'))
      addLink(names,links,3,False,name,iconimage=iconimage)
      x=x+1
    match=re.compile('<iframe src="(.+?)"',re.DOTALL).findall(html)
    for links in match:
      if 'cbox' not in links:
        names=links.split('/')[2]
        addLink(names,links,3,False,name,iconimage=iconimage)
      x=x+1
def read_site_html(url_link):
    socket.setdefaulttimeout(15)
    opener = urllib2.build_opener(MyHTTPHandler)
    urllib2.install_opener(opener)
    req = urllib2.Request(url_link)
    req.add_header('User-agent',__USERAGENT__)# 'Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30')
    html = urllib2.urlopen(req).read()
    return html

def main_menu(url):
    if url==None:
     url='http://olamha-media.com/'
    html=read_site_html(url)
    match=re.compile('screen-reader-text">(.+?)</span>.+?<div class="post-thumbnail">.+?<a href="(.+?)">.+?src="(.+?)".+?<div class="entry">.+?<p>(.+?)</p>',re.DOTALL).findall(html)
    for name,link,image,plot in match:
      h = HTMLParser()
      plot=(h.unescape(plot))
      logging.warning('plot')
      logging.warning(plot)
      addDir3(name,link,2,image,image,plot)
    match=re.compile('<span class="pages">Page(.+?)of(.+?)</span>').findall(html)
    next=re.compile('<link rel="next" href="(.+?)" />').findall(html)[0]
    for page,last in match:
      addDir3(' עמוד'+str(int(page)+1)+' מתוך'+last,next,1,'','','')
      


   
params=get_params()

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
original_name=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:        
        original_name=urllib.unquote_plus(params["original_name"])
except:
        pass
   
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        main_menu(url)
elif mode==1:
        main_menu(url)
elif mode==2:
        play_link(url,name,iconimage)
elif mode==3:
        play_direct_link(url,original_name)
logging.warning('mode')
xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
xbmc.executebuiltin("Container.SetViewMode(504)")
xbmcplugin.endOfDirectory(int(sys.argv[1]))

