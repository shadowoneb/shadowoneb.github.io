# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys,logging,socket,httplib,dns.resolver
from HTMLParser import HTMLParser
from HTMLParser import HTMLParser
h = HTMLParser()

__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
__settings__ = xbmcaddon.Addon(id='plugin.video.Olam')
class MyHTTPConnection (httplib.HTTPConnection):
    def connect (self):
        
            resolver = dns.resolver.Resolver()
            resolver.nameservers = ['8.8.4.4']
            answer = resolver.query(self.host,'A')
            self.host = answer.rrset.items[0].address
            self.sock = socket.create_connection ((self.host, self.port))

class MyHTTPHandler (urllib2.HTTPHandler):
    def http_open (self, req):
        return self.do_open (MyHTTPConnection, req)
def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     


###############################################################################################################        

def addDir3(name,url,mode,iconimage,fanart,description,original_name=''):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+(description)+"&original_name="+urllib.quote_plus(original_name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        
        return ok

def addNolink( name, url,mode,isFolder, iconimage="DefaultFolder.png"):
 

          
          name='[COLOR aqua][I]'+name+'[/I][/COLOR]'
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name)   })

          liz.setProperty("IsPlayable","false")
          
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)
          
def addLink( name, url,mode,isFolder,original_name, iconimage="DefaultFolder.png",description=''):
 

          
         
         
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&original_name="+urllib.quote_plus(original_name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name) , "Plot": description  })
          liz.setProperty( "Fanart_Image", iconimage )
          liz.setProperty("IsPlayable","true")
          
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)
def play_direct_link(url,original_name):
    import urlresolver
    try:
        videoPlayListUrl = urlresolver.HostedMediaFile(url=url).resolve()
        logging.warning(videoPlayListUrl)
        if not videoPlayListUrl:
          logging.warning( "URL " + url + " could not have been resolved to a movie.\n")
        
          videoPlayListUrl=url
    except:
      videoPlayListUrl=url
      pass
    #addon.resolve_url(stream_url)
    #videoPlayListUrl = urllib.unquote(videoUrl[0])
   #else:

    if 'myfile' in url:
      
      videoPlayListUrl=(play_myfile(url))
      
      match=videoPlayListUrl.split("/")[-1]
      videoPlayListUrl=videoPlayListUrl.replace(match,urllib.quote_plus(match))
 
    logging.warning('Playing')
    logging.warning(videoPlayListUrl)
    logging.warning(original_name)
    listItem = xbmcgui.ListItem(original_name, path=videoPlayListUrl) # + '|' + 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    listItem.setInfo(type='Video', infoLabels={ "Title": original_name})
    listItem.setInfo( type="Music", infoLabels={ "Title": original_name } )
    listItem.setProperty('IsPlayable', 'true')
    
    #xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(videoPlayListUrl)
    xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
  
  
  
def play_link(url,name,iconimage):
    html=read_site_html(url)
    match=re.compile('<strong><a href="(.+?)">').findall(html)
    x=1
    
    for links in match:
      logging.warning(links)
      names=links.split('/')[2]
      logging.warning(links.split('/'))
      addLink(names,links,3,False,name,iconimage=iconimage)
      x=x+1
    match=re.compile('<iframe src="(.+?)"',re.DOTALL).findall(html)
    for links in match:
      if 'cbox' not in links:
        names=links.split('/')[2]
        addLink(names,links,3,False,name,iconimage=iconimage)
      x=x+1
def Crypt(value):
  import hashlib
  
  m = hashlib.md5()
  m.update(value)
  md5_1 = m.hexdigest()
  return((md5_1))
def read_site_html(url_link):
#solving https://cdn.rawgit.com/proginter/some/32788221/get.js
    import requests

    headers = {
        'Host': 'olamha-media.com',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Referer': 'https://search.yahoo.com/',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Cache-Control': 'max-age=0',
    }

   
    html=requests.get(url_link,headers=headers)


    cookies=(html.cookies)

    try:
 
        oc1=str(cookies['64ad6119b42679ad7984c39a301963a7'])
        oc2=str(cookies['4cec412845b1e1ea939bf911a4bcba6b'])
        
        co3=Crypt(oc1+oc2)+Crypt(oc2+oc1)



        cookies = {
        '8b3cbf26f49a1abbda8bc2a883f53d17': (co3),
        '64ad6119b42679ad7984c39a301963a7':oc1,
        '4cec412845b1e1ea939bf911a4bcba6b':oc2,
       }

        html=requests.get(url_link,headers=headers,cookies=cookies)
       
    
        return html.text.encode('utf8')
    except:
      return html.text.encode('utf8')


def main_menu(url):
    html=read_site_html('http://olamha-media.com/')
    regex='<h3 class="widget-title"><i class="fa fa-play"></i>(.+?)</h3>'
    match=re.compile(regex).findall(html)
    
    for names in match:

      addDir3(names,'http://olamha-media.com/',9,' ',' ',names,names)
      
    addDir3('סדרות חו"ל','http://olamha-media.com/series/',5,'','','')
    addDir3('סרטים','http://olamha-media.com/categories/%D7%A1%D7%A8%D7%98%D7%99%D7%9D/',5,'','','')
    addDir3('[COLOR khaki] חיפוש [/COLOR]','http://olamha-media.com/',4,'','','')
    regex='<a href="http://olamha-media.com/">(.+?)<.+?<ul class="dropdown-menu">(.+?)</ul>'
    match=re.compile(regex,re.DOTALL).findall(html)
    
    for names,data in match:
      addNolink( names, 'www',99,False)
      regex2='<li id=.+?<a href="(.+?)">(.+?)</a>'
      match2=re.compile(regex2).findall(data)
      for link,n in match2:
        n=h.unescape(n.decode('utf8')).encode('utf8')
        if 'ערוץ' in n and 'סדרות' not in n:
          html=read_site_html(link)
          regex="file: '(.+?)'"
          match=re.compile(regex).findall(html)
          logging.warning(n)
          addLink(n,match[0],8,False,n)
        elif 'רדיו' in n and 'חי' in n:
           if 'אקו' in n:
            link='http://99.livecdn.biz/99fm_aac?hash=1509956626707.m4a'
           if 'גלגלצ' in n:
            link='http://glzwizzlv.bynetcdn.com/glglz_mp3?awCollectionId=misc&awEpisodeId=glglz'
           if 'מזרחית' in n:
            link='http://212.150.158.43:7777/;?1509956680617'
           if '103' in n:
            link='http://103fm.live.streamgates.net/103fm_live/1multix/icecast.audio'
           if 'חם אש' in n:
             link='http://995.livecdn.biz:8000/995fm'
           if 'רשת ב' in n:
             link='http://radiocast-rr-d.vidnt.com:8000/ipbc_IPBCbetLAM?1509956758879'
           if 'גל"צ' in n:
             link='http://glzwizzlv.bynetcdn.com/glz_mp3?awCollectionId=misc&awEpisodeId=glz'
           addLink(n,link,8,False,n)
           
        else:
        
          addDir3(n,link,5,'','','')

def search(url):
    search_entered = ''
    isText = False
    keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
    keyboard.doModal()
    if keyboard.isConfirmed():
       search_entered = urllib.quote_plus(keyboard.getText())
    url='http://olamha-media.com/?s='+search_entered
    get_episodes(search_entered,url)
def get_links(name,url,image):
  logging.warning(url)
  
  html=read_site_html(url)
  regex='<h1 style="text-align: center;"><strong>(.+?)</strong></h1>'
  match=re.compile(regex).findall(html)
  for data in match:
    addNolink(data,'www',99,False)
  regex='<div class="player player-small embed-responsive embed-responsive-16by9">(.+?)					                   '
  match=re.compile(regex,re.DOTALL).findall(html)
  logging.warning(match)
  for data in match:
    regex2='<p>(.+?)</p>'
    match2=re.compile(regex2,re.DOTALL).findall(data)
    try:
      plot =match2[0]
      plot=h.unescape(plot.decode('utf8')).encode('utf8')
    except:
      plot=' '
    regex3='<a href="(.+?)"'
    match3=re.compile(regex3,re.DOTALL).findall(data)
    for link in match3:
      reg='//(.+?)/'
      match=re.compile(reg).findall(link)
      
      addLink(match[0],link,8,False,name,image,plot)
    regex4='iframe.+?src="(.+?)"'
    match4=re.compile(regex4,re.DOTALL).findall(data)
    for link in match4:
      reg='//(.+?)/'
      match=re.compile(reg).findall(link)
      logging.warning(link)
      addLink(match[0],link,8,False,name,image,plot)

      

def play_myfile(url):
    import requests
    r = requests.get(url)
    regex="window.location='(.+?)'"
    match4=re.compile(regex).findall(r.text.encode('utf8'))
    #path=re.compile("href=\\\(.*)onclick=").findall(r.text.encode('utf8'))[0].replace("'",'').replace('\\','').replace(' ','')
    path=match4[1]
    
   
    return (path)
def get_episodes(name,url):

    
  

  html=read_site_html(url)
  regex="file: '(.+?)'"
  match=re.compile(regex).findall(html)
  for link in match:
    
    addLink(name,link,8,False,name)
  regex='<div class="item-img">.+?src="(.+?)".+?<h3><a href="(.+?)">(.+?)</a></h3>'
  match=re.compile(regex,re.DOTALL).findall(html)
  
  for image,link,name in match:
    name=h.unescape(name.decode('utf8')).encode('utf8')
    logging.warning('image=')
    logging.warning(image)
    addDir3(name,link,7,image,image,'')
  
  regex_hol='<div class="img-box"><a href="(.+?)"><img src="(.+?)".+?<div class="heb">(.+?)</div>.+?"eng">(.+?)</div>'
  match=re.compile(regex_hol,re.DOTALL).findall(html)
  for link,image,name1,name2 in match:
    addDir3(name1+'\n'+name2,link,5,image,image,name1+'\n'+name2,name1+'\n'+name2)
  regex2="<a class='page-numbers' href='(.+?)'>(.+?)</a>"
  match=re.compile(regex2).findall(html)
  for link,name in match:
    
    addDir3('[COLOR aqua]'+' עמוד'+name+'[/COLOR]',link,5,'','','')
    

    
def get_latest(name,url,orignal_name):
  html=read_site_html(url)
  regex='<h3 class="widget-title"><i class="fa fa-play"></i>'+orignal_name+'</h3>(.+?)</li></ul>'
  match=re.compile(regex,re.DOTALL).findall(html)
  logging.warning(match)
  regex2='<div class="item-img">.+?title="(.+?)" href="(.+?)">.+?src="(.+?)"'
  match2=re.compile(regex2,re.DOTALL).findall(match[0])
  for name,link,image in match2:
    addDir3(name,link,7,image,image,orignal_name,orignal_name)
  regex2="<a class='page-numbers' href='(.+?)'>(.+?)</a>"
  match=re.compile(regex2).findall(match[0])
  for link,name in match:
    addDir3('[COLOR aqua]'+' עמוד'+name+'[/COLOR]',link,9,'','','',orignal_name)
params=get_params()

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
original_name=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:        
        original_name=urllib.unquote_plus(params["original_name"])
except:
        pass
   
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
logging.warning('mode=')
logging.warning(mode)
logging.warning(original_name)
if mode==None or url==None or len(url)<1:
        main_menu(url)
elif mode==1:
        main_menu(url)
elif mode==2:
        play_link(url,name,iconimage)
elif mode==8:
        play_direct_link(url,original_name)
elif mode==4:
        search(url)
elif mode==5:
       get_episodes(name,url)
elif mode==7:
       get_links(name,url,iconimage)
elif mode==9:
       get_latest(name,url,original_name)
  

xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
xbmc.executebuiltin("Container.SetViewMode(504)")
xbmcplugin.endOfDirectory(int(sys.argv[1]))

