# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys,logging
from HTMLParser import HTMLParser
__plugin__ = 'plugin.video.ahoradot'
__settings__ = xbmcaddon.Addon(id=__plugin__)
Addon = xbmcaddon.Addon(id=__plugin__)

h = HTMLParser()
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'

kingvid = Addon.getSetting("kingvid")
openload = Addon.getSetting("openload")
nowvideo = Addon.getSetting("nowvideo")
streamcloud = Addon.getSetting("streamcloud")
vidto = Addon.getSetting("vidto")
vidzi = Addon.getSetting("vidzi")
def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     

###############################################################################################################        
def addNolink( name, url,mode,isFolder, iconimage="DefaultFolder.png"):
 

          
          name='[COLOR aqua][I]'+name+'[/I][/COLOR]'
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name)   })

          liz.setProperty("IsPlayable","false")
          
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)
          
def addDir3(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        
        return ok


def addLink( name, url,mode,isFolder, iconimage="DefaultFolder.png",description='',original_name=''):
 

          
         
         
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&original_name="+urllib.quote_plus(original_name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name), "Plot": description   })
          liz.setProperty( "Fanart_Image", fanart )
          liz.setProperty("IsPlayable","true")
          
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)

def read_site_html(url):
    import requests


    cookies = {
    'PHPSESSID': 'bguj5gc72c1bbcrf7gjt46lpp7',
    '_ga': 'GA1.2.373839991.1510145847',
    '_gid': 'GA1.2.616056863.1510145847',
    '_gat': '1',
    }
    headers = {
        'Host': 'ahoradot.net',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Connection': 'keep-alive',
        'Referer':url,
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }

    x=requests.get(url, headers=headers,cookies=cookies)
    return x.text.encode('utf8')


def read_site_html2(url_link):

    req = urllib2.Request(url_link)
    req.add_header('User-agent',__USERAGENT__)# 'Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30')
    html = urllib2.urlopen(req).read()
    return html

def main_menu():
    html=read_site_html2('https://ahoradot.net/')
    regex='<li id="menu-item-.+?" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-.+?"><a href="(.+?)">(.+?)</a>(.+?)</ul>'
    match=re.compile(regex,re.DOTALL).findall(html)
    for link,name,data in match:
      addDir3('[COLOR aqua][I]'+name+'[/I][/COLOR]',link,2,'','',name)
      regex2='<li id="menu-item-.+?" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-.+?"><a href="(.+?)">(.+?)</a></li>'
      match2=re.compile(regex2,re.DOTALL).findall(data)
      for link,name in match2:
        addDir3(name,link,2,'','',name)
    

def get_links(name,url,image,plot):
  
  html=read_site_html2(url)
  regex='<div class="mb_link_hld"><p><a href="(.+?)"'
  match=re.compile(regex,re.DOTALL).findall(html)
  url_all=''
  for link in match:
   reg='//(.+?)/'
   match=re.compile(reg).findall(link)
   addLink(match[0],link,4,False,image,plot,name)
   url_all=url_all+'$$$'+link
  regex='<div class="wc-comment-text"><p>(.+?)</p>(.+?)<div class="wc-comment-footer">'
  match=re.compile(regex,re.DOTALL).findall(html)
  for name,data in match:
    name1=name.replace("\n", " ").replace('<br />','').replace("  ","")
    
    logging.warning(name1)
    addNolink( name1, 'www',99,False, '')
    regex2='<p><a href="(.+?)"'
    match2=re.compile(regex2,re.DOTALL).findall(data)
    for link in match2:
       reg='//(.+?)/'
       match=re.compile(reg).findall(link)
       addLink(match[0],link,4,False,image,plot,name)
  if len (url_all)>0:
    addLink('[COLOR aqua][I]'+'ניגון אוטומטי'+'[/I][/COLOR]',url_all,5,False,'','',name)
  
def scrape_site(url):
  html2=read_site_html2(url)
  logging.warning('url')
  logging.warning(url)
  regex="<h2 class='entry-title'(.+?)</article>"
  match=re.compile(regex,re.DOTALL).findall(html2)
  for html in match:
      regex='<a href="(.+?)" title="(.+?)".+?<div class="entry-summary">.+? src="(.+?)".+?div style=".+?">(.+?)</div>'
      match=re.compile(regex,re.DOTALL).findall(html)

      for link,name,image,plot in match:
        plot=h.unescape(plot.decode('utf8')).encode('utf8')
        name=h.unescape(name.decode('utf8')).encode('utf8').replace('קישור קבוע אל','')
        addDir3(name,link,3,image,image,plot.strip(' \n\r').replace('<br>',''))
  regex3="<a class=\"nextpage\" alt='.+?' href='(.+?)'>(.+?)</a>"
  match3=re.compile(regex3,re.DOTALL).findall(html2)
  for link2,name in match3:
   
    addDir3('[COLOR aqua]'+name+'[/COLOR]',link2,2,'','',name)
def play_myfile(url):
    import requests
    r = requests.get(url)
    regex="window.location='(.+?)'"
    match4=re.compile(regex).findall(r.text.encode('utf8'))
    #path=re.compile("href=\\\(.*)onclick=").findall(r.text.encode('utf8'))[0].replace("'",'').replace('\\','').replace(' ','')
    path=match4[1]
    
   
    return (path)
def play_link(original_name,url):
    import urlresolver,socket
    #try:
    videoPlayListUrl = urlresolver.HostedMediaFile(url=url).resolve()
    logging.warning(videoPlayListUrl)
    if not videoPlayListUrl:
      logging.warning( "URL " + url + " could not have been resolved to a movie.\n")
    
      videoPlayListUrl=url
    #except:
    #  videoPlayListUrl=url
    #  pass


    if 'myfile' in url:
      
      videoPlayListUrl=(play_myfile(url))
      
      match=videoPlayListUrl.split("/")[-1]
      videoPlayListUrl=videoPlayListUrl.replace(match,urllib.quote_plus(match))
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(50)

    logging.warning('Playing')
    logging.warning(videoPlayListUrl)
    logging.warning(original_name)
    listItem = xbmcgui.ListItem(original_name, path=videoPlayListUrl) # + '|' + 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    listItem.setInfo(type='Video', infoLabels={ "Title": original_name})
    listItem.setInfo( type="Music", infoLabels={ "Title": original_name } )
    listItem.setProperty('IsPlayable', 'true')
    
    #xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(videoPlayListUrl)
    xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
def auto_play(original_name,url):
	import urlresolver
	dp = xbmcgui . DialogProgress ( )
	dp.create('אנא המתן','מנסה לנגן', '')
	dp.update(0, 'מעדכן רשימה','מנסה לנגן', '' )
	try:
		links_array=url.split('$$$')
		x=-1
		url2=''
		for linka in links_array:
			try:
				if dp.iscanceled(): break
				x=x+1
				next_one=True
				if "kingvid" in linka and kingvid=='false':
				  next_one=False
				if "openload" in linka and openload=='false':
				  next_one=False
				if "nowvideo" in linka and nowvideo=='false':
				  next_one=False
				if "streamcloud" in linka and streamcloud=='false':
				  next_one=False
				  
				if "vidto" in linka and vidto=='false':
				  next_one=False
				if "vidzi" in linka and vidzi=='false':
				  next_one=False
				if next_one==True:
					dp.update(int(x/(len(links_array)*100.0)), 'מעדכן רשימה',str(x)+'/'+str(len(links_array)), linka )
					
					try:
					  url2 = urlresolver.resolve(linka)
					 
					except:
					  pass

					if 'myfile' in linka:
	
						 url2=(play_myfile(linka))
						 match=url2.split("/")[-1]
						 url2=url2.replace(match,urllib.quote_plus(match))

					if (url2):
						link = url2.split(';;')
						try:
						  final_link=link[0]
						except:
						  final_link=url2

						listitem = xbmcgui.ListItem(path=final_link)
						listitem.setInfo( type="Video", infoLabels={ "Title": original_name } )
						xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)

						if len(url2) > 10:

						  if dp.iscanceled(): break
						  while not xbmc.Player().isPlaying():
							xbmc.sleep(10) #wait until video is being played
						  break
			except:
				 pass
	except:
		pass
	dp.close()
params=get_params()

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
original_name=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:        
        original_name=urllib.unquote_plus(params["original_name"])
except:
        pass

logging.warning(url)
if mode==None or url==None or len(url)<1:
        main_menu()
elif mode==2:
     scrape_site(url)
elif mode==3:
     get_links(name,url,iconimage,description)
elif mode==4:
     play_link(original_name,url)
elif mode==5:
     auto_play(original_name,url)
xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
xbmc.executebuiltin("Container.SetViewMode(504)")

xbmcplugin.endOfDirectory(int(sys.argv[1]))

