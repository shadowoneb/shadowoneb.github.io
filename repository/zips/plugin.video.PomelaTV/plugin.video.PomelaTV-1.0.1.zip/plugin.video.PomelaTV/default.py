# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys,logging,json

__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'


def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     

###############################################################################################################        
def addNolink( name, url,mode,isFolder, iconimage="DefaultFolder.png"):
 

          
         
          mode=99
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name)   })

          liz.setProperty("IsPlayable","false")
          
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)

def addDir3(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)

        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        
        return ok


def addLink( name, url,mode,isFolder, iconimage="DefaultFolder.png"):
 

          
         
         
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name)   })
          liz.setProperty( "Fanart_Image", iconimage )
          liz.setProperty("IsPlayable","true")
          
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)


def read_site_html(url_link):

    req = urllib2.Request(url_link)
    req.add_header('User-agent',__USERAGENT__)# 'Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30')
    html = urllib2.urlopen(req).read()
    return html

def main_menu():
    #addNolink( '[COLOR aqua][I]טלויזיה[/I][/COLOR]', 'www',99,False)
   
    #addDir3('ערוץ 10','http://www.pomelatv.com/Channel10',2,'','','ערוץ 10')
    #addDir3('ערוץ 1','http://www.pomelatv.com/Channel11',2,'','','ערוץ 1')
    #addDir3('ערוץ 2','http://www.pomelatv.com/Channel22',2,'','','ערוץ 2')

  pre_result=get_play_link('239')
  result=json.loads(pre_result)

  result2=json.loads(result['d'])
  for items in result2['channels']:

    if items['movType']=='StreamFromUrl':

      addLink( '[COLOR lightblue]'+items['title']+'[/COLOR]', items['movId'],2,False, iconimage=items['thumbpic'])
    else:
      addLink( items['title'], items['movId'],2,False, iconimage=items['thumbpic'])
  
    
def get_play_link(value):
    import requests
    headers = {
        'Host': 'www.pomelatv.com',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.8',
        'Content-Type': 'application/json; charset=utf-8',
        'X-Requested-With': 'XMLHttpRequest',
        #'Referer': url,
        'async': 'true',
        'dataType': "json",
        'Connection': 'keep-alive',

    }


    params =   '{"url": "http://biz.pomelatv.com//getVideoJson.aspx?clid=0&genMovie=true&movId=&channelID=$$$$&movType=StreamFromUrl&playerType=htmlPc&SkinID=0&SkinType=1&PlayListID=0&LangID=5&ClientID=226&FirstTime=true&userTimeOffset=-120&genChannelEpg=true&movStartDate=&rand=0.962447541802171"}'
    params =params.replace('$$$$',str(value))
   


    x=requests.post('http://www.pomelatv.com/Default.aspx/GetJson', headers=headers,data=params)

    return x.text.encode('utf8')
def scrape_site(name,url,image):
  pre_result=get_play_link(url)
  result=json.loads(pre_result)
  
  result2=json.loads(result['d'])

  if  result2['movies'][0]['ratesData']!=None:
    token=result2['videoToken']['videoToken']
    playlink=result2['movies'][0]['ratesData']['mainRate']
    final_link=playlink+'?token='+token
    listitem = xbmcgui.ListItem(path=final_link)
    listitem.setInfo( type="Video", infoLabels={ "Title": name } )
    listitem.setInfo( type="Music", infoLabels={ "Title": name } )
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
  else:
    playlist =xbmc.PlayList (xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    
    
    

    x=0
    for items in result2['epgDay']['channelsList']:
      
      for items2 in result2['epgDay']['channelsList'][items]['programsList']:
        data=items2['programThumb']
        regex='https://i.ytimg.com/vi/(.+?)/default.jpg'
        match=re.compile(regex).findall(data)        
        link='plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid='+match[0]
        listitem =xbmcgui.ListItem (name, thumbnailImage=image)
        listitem.setInfo('video', {'Title': name+str(x)})
        playlist.add(url=link, listitem=listitem, index=x)
        
        x=x+1
    
    xbmc.Player().play(playlist,windowed=False)
    '''
    import urlresolver
    link='https://www.youtube.com/watch?v='+result2['movies'][0]['movId']
    final=urlresolver.HostedMediaFile(link)
    new_url=final.get_url()
    url2 = urlresolver.resolve(new_url)
    listitem = xbmcgui.ListItem(path=url2)
    listitem.setInfo( type="Video", infoLabels={ "Title": name } )
    listitem.setInfo( type="Music", infoLabels={ "Title": name } )
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
    '''

params=get_params()

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
   


if mode==None or url==None or len(url)<1:
        main_menu()
elif mode==2:
     scrape_site(name,url,iconimage)
xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_TITLE)
xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
xbmc.executebuiltin("Container.SetViewMode(504)")

xbmcplugin.endOfDirectory(int(sys.argv[1]))

