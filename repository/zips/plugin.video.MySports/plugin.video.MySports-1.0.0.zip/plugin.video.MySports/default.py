# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys,logging,urlparse
from xml.etree import ElementTree as xml
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
import requests


def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     

###############################################################################################################        
def addNolink( name, url,mode,isFolder, iconimage="DefaultFolder.png"):
 

          
          name='[COLOR aqua][I]'+name+'[/I][/COLOR]'
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name)   })

          liz.setProperty("IsPlayable","false")
          
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)
def addDir3(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
      
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        
        return ok


def addLink( name, url,mode,isFolder, iconimage="DefaultFolder.png"):
 

          
         
         
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name)   })

          liz.setProperty("IsPlayable","true")
          
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)


def read_site_html(url_link):

    req = urllib2.Request(url_link)
    req.add_header('User-agent',__USERAGENT__)# 'Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30')
    html = urllib2.urlopen(req).read()
    return html
def get_cbox(url):
        
        parsed = urlparse.urlparse(url)
        boxid=urlparse.parse_qs(parsed.query)['boxid']
        boxtag=urlparse.parse_qs(parsed.query)['boxtag']
        sec=urlparse.parse_qs(parsed.query)['sec']
        import requests

        cookies = {
            '__cfduid': 'd4d60158a0d87e6a3b32e575ba798123c1511170804',
        }

        headers = {
            'Host': 'www5.cbox.ws',
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
            'Referer': url,
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        }

        params = (
            ('boxid', boxid),
            ('boxtag', boxtag),
            ('sec', sec),
        )

        x=requests.get('http://www5.cbox.ws/box/', headers=headers, params=params)

        x.encoding='utf8'
        return x.text.encode('utf-8')


def check_link(url):

  headers = {
            
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
            'Referer': url,
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        }
  html=requests.get(url, headers=headers)
  html.encoding='utf8'
  html=html.text.encode('utf-8')

  if 'הזה אינו קיים' in html:
   return 'red'
  else:
   return 'lightblue'
def main_menu():
    dp = xbmcgui.DialogProgress()
    dp.create("טוען ערוצים", "אנא המתן", '')
    dp.update(0)
    html=read_site_html('http://index.nivdal.win/2014/02/hd.html')
    regex='</b></span></b><b>(.+?)<!-- END CBOX -->'
    match=re.compile(regex).findall(html)
    
    links=match[0].split('<br />')
    x=0
    for val in links:
      
      regex='(purple;"|b)>(.+?):'
      match2=re.compile(regex).findall(val)
      for name in match2:
        if '<' not in name[1]:
         addNolink( name[1], 'www',99,False)
      regex='<a href="(.+?)">(.+?)<'
      match3=re.compile(regex).findall(val)
      for link,name in match3:
       if '<' not in name:
        ret=check_link(link)
        dp.update(int((x)/(len(match3)) * 100.0), "אנא המתן", name)
        x=x+1
        addLink('[COLOR %s]'%(ret)+ name+'[/COLOR]', link,2,False)
      
        
    regex='scrolling="auto" src="(.+?)"'
    match_p=re.compile(regex).findall(html)
    html=get_cbox(match_p[0])
    regex='</(?:a|b)>(.+?)<a class="autoLink" href="(.+?)"'
    match=re.compile(regex).findall(html)

    x=0
    for name,link in match:
      ret=check_link(link)
      dp.update(int((x)/(len(match)) * 100.0), "אנא המתן", name)
      x=x+1
      addLink( '[COLOR %s]'%(ret)+ name+'[/COLOR]', link,2,False)
    dp.close()
    
    
     
      
def open_play_link(url):
    import requests

    cookies = {
        'JSESSIONID': '1v31g3t16kd691cbk3wxfu6pvw',
        '_ga': 'GA1.2.322818384.1511171040',
        '_gid': 'GA1.2.1995285643.1511171040',
        '__utma': '24538302.322818384.1511171040.1511171041.1511175287.2',
        '__utmc': '24538302',
        '__utmz': '24538302.1511175287.2.2.utmcsr=live2.nivdal.win|utmccn=(referral)|utmcmd=referral|utmcct=/2014/04/s7.html',
        'adcashufpv3': 'undefined',
        '__utmb': '24538302.6.10.1511175287',
        '__utmt': '1',
    }

    headers = {
        'Host': 'www.ucaster.me',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Referer': url,
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }

 
    y=requests.get(url).text
    regex="file: '(.+?)'"
    match=re.compile(regex).findall(y)
    if len(match)>0:
      return match[0]
    regex="width=(.+?), height=(.+?), channel='(.+?)', g='(.+?)'"
    match=re.compile(regex).findall(y)
    headers = {
        'Host': 'www.ucaster.me',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Referer': 'http://www.ucaster.me/hembedplayer/%s/%s/%s/%s'%(match[0][2],match[0][3],match[0][0],match[0][1]),
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }
    x=requests.get('http://www.ucaster.me/hembedplayer/%s/%s/%s/%s'%(match[0][2],match[0][3],match[0][0],match[0][1]), headers=headers).text
    
    regex='url: "(.+?)" .+? (.+?),'
    match=re.compile(regex,re.DOTALL).findall(x)

    z=read_site_html(match[0][0]+match[0][1])
   
    regex='var hlsUrl = "(.+?)" .+? ea .+? "(.+?)".+?enableVide.+?"(.+?)"'
    match=re.compile(regex,re.DOTALL).findall(x)

    play_link=match[0][0]+z.split('=')[1]+match[0][1]+match[0][2]
    
    return play_link
    
    
def play_link(name,url):
  
  url=open_play_link(url)
  listItem = xbmcgui.ListItem(name, path=url) 
  listItem.setInfo(type='Video', infoLabels={"Title": name})
  listItem.setInfo( type="Music", infoLabels={"Title": name} )
  listItem.setProperty('IsPlayable', 'true')

  xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)


params=get_params()

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
   


if mode==None or url==None or len(url)<1:
        main_menu()
elif mode==2:
     play_link(name,url)
xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
xbmc.executebuiltin("Container.SetViewMode(504)")

xbmcplugin.endOfDirectory(int(sys.argv[1]))

