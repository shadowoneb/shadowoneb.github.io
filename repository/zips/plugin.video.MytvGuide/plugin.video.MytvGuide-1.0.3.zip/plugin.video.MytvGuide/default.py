# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys,logging,time
ADDON=xbmcaddon.Addon(id='plugin.video.MytvGuide')
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'


def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     

###############################################################################################################        

def addDir3(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        logging.warning(u)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        
        return ok


def addLink( name, url,mode,isFolder, iconimage="DefaultFolder.png"):
 

          
         
         
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name)   })
          liz.setProperty( "Fanart_Image", iconimage )
          liz.setProperty("IsPlayable","false")
          
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)

ACTION_PREVIOUS_MENU 			=  10	## ESC action
ACTION_NAV_BACK 				=  92	## Backspace action
ACTION_MOVE_LEFT				=   1	## Left arrow key
ACTION_MOVE_RIGHT 				=   2	## Right arrow key
ACTION_MOVE_UP 					=   3	## Up arrow key
ACTION_MOVE_DOWN 				=   4	## Down arrow key
ACTION_MOUSE_WHEEL_UP 			= 104	## Mouse wheel up
ACTION_MOUSE_WHEEL_DOWN			= 105	## Mouse wheel down
ACTION_MOVE_MOUSE 				= 107	## Down arrow key
ACTION_SELECT_ITEM				=   7	## Number Pad Enter
ACTION_BACKSPACE				= 110	## ?
ACTION_MOUSE_LEFT_CLICK 		= 100
ACTION_MOUSE_LONG_CLICK 		= 108
def TextBox(title, msg):
	class TextBoxes(xbmcgui.WindowXMLDialog):
		def onInit(self):
			self.title      = 101
			self.msg        = 102
			self.scrollbar  = 103
			self.okbutton   = 201
			self.y=0
			self.showdialog()

		def showdialog(self):
			self.getControl(self.title).setLabel(title)
			self.getControl(self.msg).setText(msg)
			self.setFocusId(self.scrollbar)
			
		def onClick(self, controlId):
			if (controlId == self.okbutton):
				self.close()
		
		def onAction(self, action):
			if   action == ACTION_PREVIOUS_MENU: self.close()
			elif action == ACTION_NAV_BACK: self.close()
	
			
	tb = TextBoxes( "Textbox.xml" , ADDON.getAddonInfo('path'), 'DefaultSkin', title=title, msg=msg)
	tb.doModal()
	del tb
def showText(heading, text):
    #window = POPUPTEXT(heading,text)
    #window.doModal()
    TextBox('לוח שידורים'+ ' '+heading, text)
    '''
    id = 10147
    xbmc.executebuiltin('ActivateWindow(%d)' % id)
    xbmc.sleep(100)
    win = xbmcgui.Window(id)
    retry = 50
    while (retry > 0):
        try:
            xbmc.sleep(10)
            retry -= 1
            win.getControl(1).setLabel(heading)
            win.getControl(5).setText(text, alignment=0)
            return
        except:
            pass
    '''
def read_site_html(url_link):

    req = urllib2.Request(url_link)
    req.add_header('User-agent',__USERAGENT__)# 'Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30')
    html = urllib2.urlopen(req).read()
    return html

def main_menu():
    import requests
    response = requests.get('http://super-iptv.tv/files/israel.xml').content
    regex_pre='<channel id=(.+?)</channel>'
    match_pre=re.compile(regex_pre,re.DOTALL).findall(response)
    for data in match_pre:
        regex='"(.+?)">.+?<icon src="(.+?)"'
        match=re.compile(regex,re.DOTALL).findall(data)
   
     
        for name,image in match:
            addLink( name, 'www',2,False, iconimage=image)

def get_epg_plot(num):
    import requests,datetime
    filedata = requests.get('http://super-iptv.tv/files/israel.xml').content
    

    regex_pre='<programme start=(.+?)</programme>'
    match_pre=re.compile(regex_pre,re.DOTALL).findall(filedata)


    today=(datetime.datetime.now().strftime("%Y%m%d%H%M%S"))
    last_week=((datetime.datetime.now()-datetime.timedelta(minutes=10080)).strftime("%Y%m%d%H%M%S"))

    today_date=(datetime.datetime.now().strftime("%Y%m%d"))
    last_week_date=((datetime.datetime.now()-datetime.timedelta(minutes=10080)).strftime("%Y%m%d"))
    prev=''
    plot=''
    disc=''
    for all in match_pre:

      regex='"(.+?)" stop="(.+?)" channel="%s">.+?<title lang="he">(.+?)</title>.+?<desc lang="he">(.+?)</desc>'%num
      match=re.compile(regex,re.DOTALL).findall(all)

      for start,end,names,disc in match:
       start_date=start.split(" ")[0]
       if today_date in start:
         check_date=today
       else:
         check_date=last_week
       if int(check_date)<=int(start_date):

          if prev!='':

            try:
                first=datetime.datetime.strptime(prev, "%Y%m%d%H%M%S")
            except TypeError:
                first=datetime.datetime(*(time.strptime(prev, "%Y%m%d%H%M%S")[0:6]))
    
 
            try:
                second=datetime.datetime.strftime(first,"%H:%M")
            except TypeError:
                second=datetime.datetime(*(time.strftime(first,"%H:%M")[0:6]))

            #second=first.strftime("%H:%M")
            plot=plot+second+':---|'+''+names+'|----|'+''+disc +'\n\n'
            prev=''
          else:
            try:
                first=datetime.datetime.strptime(start_date, "%Y%m%d%H%M%S")
            except TypeError:
                first=datetime.datetime(*(time.strptime(start_date, "%Y%m%d%H%M%S")[0:6]))
    
 
            try:
                second=datetime.datetime.strftime(first,"%H:%M")
            except TypeError:
                second=datetime.datetime(*(time.strftime(first,"%H:%M")[0:6]))
               
            plot=plot+ second+':---|'+''+names+''+'|----|'+disc+'\n\n'
         
       else:
         prev=start_date
    
    return plot
def scrape_site(name):
    dp = xbmcgui.DialogProgress()
    dp.create("טוען תוכניות","אנא המתן...")
    
    plot=get_epg_plot(name)
    dp.close()
    showText(name,plot)

params=get_params()

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
   


if mode==None or url==None or len(url)<1:
        main_menu()
elif mode==2:
     scrape_site(name)
xbmcplugin.setContent(int(sys.argv[1]), 'movies')


xbmcplugin.endOfDirectory(int(sys.argv[1]))

