# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys,logging
from xml.etree import ElementTree as xml
import urlparse
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'

all_names={'1162':'התמודדות',
           '17':'כאן מציינים',
           '10':'עוד מכאן',
           '1073':'מלאכי השביל',
           '1113':'אפרו',
           '32':'הטרמפיסטים',
           '1112':"It's Complicated",
           '4':'דוקותיים',
           '1099':'כאן סקרנים',
           '35':'כאן אקסטרים',
           '1176':'כאן עברית',
           '19':'כאן מדע',
           '27':'דעה',
           '3':'כאן שיר',
           '31':'כאן עונים',
           '1102':'כאן מכירים',
           '28':'מקצועות במספרים',
           '57':'ערכים מוויקיפדיה',
           '1081':'עדשות המלחמה',
           '33':'ימיני או שמאלי',
           '1':'ירושלמים',
           '11':'למה זה עדיין קיים?',
           '15':'מכירים את אלה',
           '16':'המשמר האזרחי',
           '18':'כאן מחקרים'
           }

all_names2={'47':'היהודים באים',
            '1125':'טיול אחרי צבא',
            '42':'המרדף',
            '1165':'הנשר הגדול',
            '1173':'מדינת הגמדים',
            '41':'עד כאן',
            '1170':'על המשמר',
            '1138':'שטח הפקר',
            '1066':'זמן אמת',
            '43':'המכולה',
            '1129':'בואו לאכול איתי',
            '39':'מועדון תרבות',
            '1065':'קארפול קריוקי',
            '1163':'קרדינל',
            '1167':'צייד המרגלים',
            '1146':'מאסטר פוטוגרפי',
            '1174':'בן השמשות',
            '1144':'כלבים עלולים לעוף',
            '1117':'סודות גן החיות',
            '1111':'Spy in the Wild',
            '1153':'היהודים האמריקאים',
            '1076':'דוקומנטרי',
            '1114':'כאן ספיישלים',
            '1169':'The Moning of life',
            '1080':'דרמה',
            '1155':'Antiques Roadshow',
            '1158':'Stephen Fry',
            '1168':'הרפתקאות האמנים המודרנים',
            '1171':'הטוב שבני העולמות',
            '1160':'Amazing Hotel',
            '68':'איפה אתה חי',
            '1090':'התסריטאי',
            '1161':'תפוחים מן המדבר',
            '1159':'Unreported World',
            '1109':'חנוך לוין',
            '1127':'הדוקומנטריסטים',
            '64':'והארץ הייתה תוהו ובוהו',
            '1115':'סדנת חינוך',
            '46':'פרשת דרכים',
            '1157':'לא תשקוט הארץ',
            '1091':'שומרי הסף',
            '65':'הרמטכ"לים',
            '1147':'קפיטליזם'
            }

def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     

###############################################################################################################        

def addDir3(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)

        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        
        return ok


def addLink( name, url,mode,isFolder, iconimage="DefaultFolder.png",description=''):
 

          
         
         
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+urllib.quote_plus(description)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name), "Plot": description   })
          liz.setProperty( "Fanart_Image", iconimage )
          liz.setProperty("IsPlayable","true")
          
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)

def addNolink( name, url,mode,isFolder, iconimage="DefaultFolder.png"):
 

          
         
         
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name)   })

          liz.setProperty("IsPlayable","false")
          
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)


USER_AGENT = "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:52.0) Gecko/20100101 Firefox/52.0"

def fetch_url(url, headers={}, direct=False, size=None):
    hdr={
        'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        'Accept-Language': "en-US,en;q=0.5",
        'Referer': url,
        'User-Agent': USER_AGENT
    }
    hdr.update(headers)

    try:
        
        req = urllib2.Request(url, headers=hdr)
        return urllib2.urlopen(req).read(size)

    except urllib2.URLError, e:
        
        return False


def get_url_info(url):
    if 'medias[0]' in url:
      video_id = urlparse.parse_qs(urlparse.urlparse(url).query)['medias[0]'][0]
      xml_url = "http://player.kan.org.il/vod/vod/%s/hls/metadata.xml?smil_profile=default" % video_id
    else:
      video_id = urlparse.parse_qs(urlparse.urlparse(url).query)['stream'][0]
     
      xml_url = "http://player.kan.org.il/live/ipbc/%s/hls/metadata.xml?smil_profile=default&" % video_id
                

    xml_data = xml.XML(fetch_url(xml_url))
    
    title = xml_data.find('Title').text
   

    #duration = int(xml_data.find('Duration').text)
   
    '''
    for poster in xml_data.find('PosterLinks').findall('PosterIMG'):
        poster_width = int(poster.attrib['width'])
        poster_height = int(poster.attrib['height'])
        poster_url = poster.text
        print("Poster: %sx%s: %s" % (poster_width, poster_height, poster_url))

    '''
    server = xml_data.find('CDNInfo/Servers')[0].text

    playback_url = xml_data.find('PlaybackLinks/SmilURL').text
    url_p = urlparse.urlparse(playback_url)
    url_p = url_p._replace(netloc=server)
    playback_url = urlparse.urlunparse(url_p)
    return( playback_url)

def read_site_html(url_link):

    req = urllib2.Request(url_link)
    req.add_header('User-agent',__USERAGENT__)# 'Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30')
    html = urllib2.urlopen(req).read()
    return html

def main_menu():
    '''
    html=read_site_html('http://www.kan.org.il')
    regex='<div>(.+?)</div>(.+?)</div>'
    match=re.compile(regex,re.DOTALL).findall(html)
    for names,all in match:
    
      if '<' not in(names) and( 'וידאו' in names ) :
        addNolink('[COLOR aqua][I]'+names+'[/I][/COLOR]','http://www.kan.org.il',2,False,'')
        regex="href='(.+?)' target=.+?>(.+?)</a>"
        match=re.compile(regex,re.DOTALL).findall(all)
        for link,name in match:
          addDir3(name,'http://www.kan.org.il'+link,2,'','',name)
    '''
    addDir3('תוכניות טלויזיה','http://www.kan.org.il/video/programs.aspx',2,'','','')
    addDir3('תוכניות רשת','http://www.kan.org.il/video/digital.aspx',2,'','','')
    addDir3('קטעים חדשים','http://www.kan.org.il/page.aspx?landingPageId=1013',5,'','','')
    
    html=read_site_html('http://www.kan.org.il')
    regex='<div>(.+?)</div>(.+?)</div>'
    match=re.compile(regex,re.DOTALL).findall(html)
    for names,all in match:
      if 'רדיו' in names:
        addNolink('[COLOR aqua][I]'+names+'[/I][/COLOR]','http://www.kan.org.il',2,False,'')
        regex="href='(.+?)' target=_self>(.+?)</a>"
        match=re.compile(regex,re.DOTALL).findall(all)
        for link,name in match:
          if 'רדיו' in name:
            addNolink('[COLOR aqua][I]'+name+'[/I][/COLOR]','http://www.kan.org.il',2,False,'')
          else:
            
            addLink(name,'http://www.kan.org.il'+link,6,False,'',name)
    
    html=read_site_html('http://www.kan.org.il/Radio/')
    regex='<a class="live_radio_link w-inline-block" href="(.+?)">.+?<img src=".+?<img src="(.+?)">'
    match=re.compile(regex,re.DOTALL).findall(html)
    for link,image in match:
       
       if 'pictures' not in image:
    
         addLink(image.split('/')[2].replace('logo_','').replace('.png',''),'http://www.kan.org.il'+link,6,False,'http://www.kan.org.il'+image,name)
       
def scrape_site(url):
  html=read_site_html(url)
  if '<div id="moreProgram">' in html:

   regex='<div class="it_small">.+?url\(\'(.+?)\'\).+?href="(.+?)"'
   match=re.compile(regex,re.DOTALL).findall(html)
   links=[]
   for image,link in match:

     link2=(link.split('=')[1])
     name=''
     try:
       name=all_names[link2]
     except:
       pass
     
     try:
      name=all_names2[link2]
     except:
       pass
     addDir3(name,'http://www.kan.org.il'+link,3,'http://www.kan.org.il'+image,'http://www.kan.org.il'+image,'')

def shows(url):
  html=read_site_html(url)
  regex='li class="program_list_item w-clearfix">.+?url\(\'(.+?)\'\).+?" src="(.+?)".+?<h2 class="content_title">(.+?)</h2>.+?<p>(.+?)</p>'
  match=re.compile(regex,re.DOTALL).findall(html)
  for image,link,name,plot in match:

    addLink(name.strip('\n'),link,4,False,'http://www.kan.org.il'+image,plot)
params=get_params()

def play(url,name):
  import urlresolver
  if 'yout' in url:
    final=urlresolver.HostedMediaFile(url)
    new_url=final.get_url()
    url2 = urlresolver.resolve(new_url)
  else:
    
    url2=get_url_info(url)

  listitem = xbmcgui.ListItem(path=url2)
  listitem.setInfo( type="Video", infoLabels={ "Title": name } )
  xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
def new_bits(url,name):
   html=read_site_html(url)
   addNolink( '[COLOR aqua][I]בחירת העורכות[/I][/COLOR]', url,5,False)
   regex1='<h2 class="center_title">בחירת העורכות</h2>(.+?)<h2'
   
   
   match=re.compile(regex1,re.DOTALL).findall(html)
   
   for m in match:

     regex='style="background-image: url\(\'(.+?)\'\).+?<h.+?>(.+?)</h.+?<p .+?>(.+?)</p>.+?src=.+?"(.+?)"'
     match=re.compile(regex,re.DOTALL).findall(m)

     for image,name,plot,link, in match:
       addLink(name.strip('\n'),link,4,False,'http://www.kan.org.il'+image,plot)
   
   addNolink( '[COLOR aqua][I]קצרים כשממהרים[/I][/COLOR]', url,5,False)
   regex1='<h2 class="center_title">קצרים כשממהרים</h2>(.+?)<h2'
   
   
   match=re.compile(regex1,re.DOTALL).findall(html)
   
   for m in match:

     regex='image: url\(\'(.+?)\'\).+?src="(.+?)".+?<h.+?>(.+?)</h3>.+?<p.+?>(.+?)</p>'
     
     match=re.compile(regex,re.DOTALL).findall(m)

     for image,link,name,plot in match:
       addLink(name.strip('\n'),link,4,False,'http://www.kan.org.il'+image,plot)
     regex2='url\(\'(.+?)\'\).+?src="(.+?)".+?<h3 .+?>(.+?)</h3>.+?<p .+?>(.+?)</p>'
     match=re.compile(regex2,re.DOTALL).findall(m)

     for image,link,name,plot, in match:
       addLink(name.strip('\n'),link,4,False,'http://www.kan.org.il'+image,plot)
       
   addNolink( '[COLOR aqua][I]תכניות מומלצות[/I][/COLOR]', url,5,False)
   regex1='<h2 class="center_title">תכניות מומלצות</h2>(.+?)<div class="footer_section_1 w-clearfix">'
   
   
   match=re.compile(regex1,re.DOTALL).findall(html)
 
   for m in match:

     regex='href="(.+?)".+?url\(\'(.+?)\'\).+?<h.+?>(.+?)</h'
     
     match=re.compile(regex,re.DOTALL).findall(m)

     for link,image,name in match:
       
       addDir3(name.strip('\n'),link,3,'http://www.kan.org.il'+image,'http://www.kan.org.il'+image,'')
     
def get_radio(url,name):
  html=read_site_html(url)
 
  regex='var iframeLink =.+?"(.+?)"'
  match=re.compile(regex,re.DOTALL).findall(html)
  play(match[0],name)

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
   


if mode==None or url==None or len(url)<1:
        main_menu()
elif mode==2:
     scrape_site(url)
elif mode==3:
     shows(url)
elif mode==4:
     play(url,name)
elif mode==5:
     new_bits(url,name)
elif mode==6:
     get_radio(url,name)
xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
xbmc.executebuiltin("Container.SetViewMode(504)")

xbmcplugin.endOfDirectory(int(sys.argv[1]))

