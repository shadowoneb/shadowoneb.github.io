# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys,logging,json
import js2py,random
from Cookie import SimpleCookie
__plugin__ = 'plugin.video.firstonetv'
Addon = xbmcaddon.Addon(id=__plugin__)
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
kingvid = Addon.getSetting("kingvid")
openload = Addon.getSetting("openload")
nowvideo = Addon.getSetting("nowvideo")
streamcloud = Addon.getSetting("streamcloud")
vidto = Addon.getSetting("vidto")
vidzi = Addon.getSetting("vidzi")
__BASE_URL__='https://www.firstonetv.net/'

def get_params():
        param=[]
        
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          logging.warning(paramstring)
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     


###############################################################################################################        

def addDir3(name,url,mode,iconimage,fanart,description,orginal_name=''):
        name=name.replace('|'," ")
        orginal_name=orginal_name.replace('|'," ")
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&orginal_name="+(orginal_name)

        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )

        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        
        return ok


def addLink( name, url,mode,isFolder,iconimage="DefaultFolder.png",orginal_name=''):
 

          
         
         
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&orginal_name="+urllib.quote_plus(orginal_name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name)  , "Plot": orginal_name })
          liz.setProperty( "Fanart_Image", iconimage )
          liz.setProperty("IsPlayable","true")
          
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)
def addNolink( name, url,mode,isFolder, iconimage="DefaultFolder.png"):
 

          
         
         
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name)   })

          liz.setProperty("IsPlayable","false")
          
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)

def read_site_html(url_link):

    req = urllib2.Request(url_link)
    req.add_header('User-agent',__USERAGENT__)# 'Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30')
    html = urllib2.urlopen(req).read()
    return html
def get_c(code):

        jscode=\
        '''
        var n,p;
        p=186;
        $$$$$$
        '''
        jscode=jscode.replace('$$$$$$',code)


        result=js2py.eval_js(jscode)
        

        return result

def main_menu():
    html=read_site_html('https://www.firstonetv.net/Live')
    
    regex='<div class="item large-3 medium-6 columns group-item-grid-default end">.+?<img src="(.+?)".+?<a href="(.+?)".+?<i class="fa fa-television">.+?<span>(.+?)</span>.+?title="(.+?)"'
    match2=re.compile(regex,re.DOTALL).findall(html)
    for image,link,plot,name in match2:
      addDir3(name,__BASE_URL__+link,2,__BASE_URL__+image,__BASE_URL__+image,plot)
def scrape_page(name,url):
    html=read_site_html(url)
    
    regex='<div class="item large-3 medium-4 columns group-item-grid-default end">.+?<img src="(.+?)".+?<a href="(.+?)".+?<i class="fa fa-eye"></i>.+?<span>(.+?)</span>.+?title="(.+?)"'
    match2=re.compile(regex,re.DOTALL).findall(html)
    for image,link,plot,name in match2:
      logging.warning(image)
      addLink(name, __BASE_URL__[:-1]+link,3,False, __BASE_URL__[:-1]+image,plot)
def get_direct_link(url):
    html=read_site_html(url)
    regex="country.+?= '(.+?)';.+?channelID.+?= '(.+?)';.+?cToken.+?= (.+?);"
    match=re.compile(regex,re.DOTALL).findall(html)
    for c,i,t in match:
      country=c
      id=i
      token=t.replace("'",'')

    
    if len(token)<2:
        rand_number=random.uniform(0, 1)
        import requests

        headers = {
            'Host': 'www.firstonetv.net',
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0',
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.5',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'X-Requested-With': 'XMLHttpRequest',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Cache-Control': 'max-age=0',
        }

        params = (
            ('cacheFucker', str(rand_number)),
        )

        data = [
          ('action', 'hiro'),
          ('result', 'get'),
    
        ]

        x=requests.post('https://www.firstonetv.net/api/', headers=headers, params=params, data=data).text
        x=json.loads((x))
        logging.warning(x)
        hiro=x['hiro']
        hash=x['hash']
        time=x['time']
        resolved_hiro=str(get_c(hiro))
        
        data = [
          ('action', 'hiro'),
          ('hash', hash),
          ('result', resolved_hiro),
          ('time', time),
        ]
        x=requests.post('https://www.firstonetv.net/api/', headers=headers, params=params, data=data).text
        x=json.loads((x))
        token=str(x['ctoken'])
        
    data = [
      ('action', 'channel'),
      ('ctoken', token),
      ('c', country),
      ('id', id),
    ]
    x=requests.post('https://www.firstonetv.net/api/', headers=headers, params=params, data=data).text
    x=json.loads((x))
    play_link=[]
    names=[]
    logging.warning(x)
    try:
     error=x['errorCode']
     errors=x['msg']
     
     title='Error'
    except:
      errors=''
      title=x['title']
      
    
    try:
      new=json.loads(x['surl'])
      for key in new:
        logging.warning(key)
        play_link.append(new[key]+'?time='+str(time))
        names.append(key)
    except:
      logging.warning(errors)
      if (len(errors))==0:
        play_link.append(x['surl']+'?time='+str(time))
      pass
    logging.warning(x)
    return play_link,title,names,errors
def play_link(name,url):
  link,title,names,errors=get_direct_link(url)
  if len(errors)>0:
    xbmcgui.Dialog().ok("Error",errors)
  else:
   import urlresolver
   if len(names)>0:
     dialog = xbmcgui.Dialog()
     ret = dialog.select("Choose quality to play", names)
     if ret != -1:
       link1=link[ret]
       listitem = xbmcgui.ListItem(path=link1)
       listitem.setInfo( type="Video", infoLabels={ "Title": title } )
       listitem.setInfo( type="Music", infoLabels={ "Title": title } )
       xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
   else:
       link1=link[0]
       listitem = xbmcgui.ListItem(path=link1)
       listitem.setInfo( type="Video", infoLabels={ "Title": title } )
       listitem.setInfo( type="Music", infoLabels={ "Title": title } )
       xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
params=get_params()
logging.warning(params)
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
orginal_name=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:        
        orginal_name=urllib.unquote_plus(params["orginal_name"])
except:
        pass
try:
  html=read_site_html('https://www.firstonetv.net/Live')
except:
  xbmcgui.Dialog().ok("Error","Site migth be Down")
  mode=99
if mode==None or url==None or len(url)<1:
        main_menu()
elif mode==2:
       scrape_page(name,url)
elif mode==3:
      play_link(name,url)
xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_TITLE)
#xbmc.executebuiltin("Container.SetViewMode(504)")
xbmcplugin.setContent(int(sys.argv[1]), "episodes")
xbmcplugin.endOfDirectory(int(sys.argv[1]))

