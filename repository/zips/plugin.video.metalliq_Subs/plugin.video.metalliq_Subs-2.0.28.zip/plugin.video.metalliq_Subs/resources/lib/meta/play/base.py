# -*- coding: utf-8 -*-
import sys, os,zlib
import json,urllib2,urllib
from traceback import print_exc
from xbmcswift2 import xbmc, xbmcgui, xbmcplugin
from meta import plugin

from meta.gui import dialogs
from meta.utils.executor import execute
from meta.utils.properties import set_property
from meta.utils.text import to_unicode, urlencode_path, apply_parameters, to_utf8
from meta.library.tools import get_movie_from_library, get_episode_from_library
from meta.navigation.base import get_icon_path, get_background_path
from meta.play.players import get_players, patch
from meta.play.channelers import get_channelers
from meta.play.lister import Lister
from settings import *
from language import get_string as _
from xbmcswift2.logger import log
from OSUtilities import OSDBServer
import xbmcaddon 
BASE_URL = "http://www.cinemast.org/he/cinemast/api/"
try:
    import StorageServer
except ImportError:
    import storageserverdummy as StorageServer
addon = xbmcaddon.Addon()
__scriptname__ = addon.getAddonInfo('name')
addonID = addon.getAddonInfo('id')
Addon = xbmcaddon.Addon(id=addonID)
user_dataDir = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
store = StorageServer.StorageServer(__scriptname__, int(24 * 364 / 2))  # 6 months
if not os.path.exists(user_dataDir):
     os.makedirs(user_dataDir)
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
@plugin.cached(TTL=60, cache="trakt")
def get_trakt_ids(*args, **kwargs):
    try:
        from trakt import trakt
        return trakt.find_trakt_ids(*args, **kwargs)
    except: return None

def active_players(media, filters={}):
    if media == "movies": setting = SETTING_MOVIES_ENABLED_PLAYERS
    elif media == "tvshows": setting = SETTING_TV_ENABLED_PLAYERS
    elif media == "musicvideos": setting = SETTING_MUSICVIDEOS_ENABLED_PLAYERS
    elif media == "music": setting = SETTING_MUSIC_ENABLED_PLAYERS
    elif media == "live": setting = SETTING_LIVE_ENABLED_PLAYERS
    else: raise Exception("invalid parameter %s" % media)
    try: enabled = plugin.get_setting(setting, unicode)
    except: enabled = []
    return [p for p in get_players(media, filters) if p.id in enabled]

def active_channelers(media, filters={}):
    if media == "movies": setting = SETTING_MOVIES_ENABLED_CHANNELERS
    elif media == "tvshows": setting = SETTING_TV_ENABLED_CHANNELERS
    elif media == "musicvideos": setting = SETTING_MUSICVIDEOS_ENABLED_CHANNELERS
    elif media == "music": setting = SETTING_MUSIC_ENABLED_CHANNELERS
    elif media == "live": setting = SETTING_LIVE_ENABLED_CHANNELERS
    else: raise Exception("invalid parameter %s" % media)
    try: enabled = plugin.get_setting(setting, unicode)
    except: enabled = []
    return [p for p in get_channelers(media, filters) if p.id in enabled]

def action_cancel(clear_playlist=True):
    if clear_playlist: xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
    plugin.set_resolved_url()
    xbmc.executebuiltin('Dialog.Close(okdialog, true)')

def action_activate(link):
    xbmc.executebuiltin('Container.Update("%s")' % link)
    #action_cancel()

def action_run(link):
    if link.startswith("plugin://"): xbmc.executebuiltin('RunPlugin(%s)' % link)
    else: xbmc.executebuiltin('RunScript(%s)' % link)

def action_prerun(link):
#    xbmc.executebuiltin('ActivateWindow(10025,addons://user/xbmc.addon.video/plugin.video.zen/,return)')
    if link.startswith("plugin://"):
        id = link.split("/")
        xbmc.executebuiltin('RunAddon(%s)' % id[2])
        while xbmc.getInfoLabel('Container.PluginName') != id[2] or xbmc.getCondVisibility('Window.IsActive(busydialog)'): xbmc.sleep(250)
        xbmc.sleep(250)
        xbmc.executebuiltin('Container.Update("%s")' % link)


def action_play(item):
    #action_cancel()
    plugin.play_video(item)

def action_playmedia(item):
    xbmc.executebuiltin('PlayMedia("%s")'%item)

def action_resolve(item):
    #plugin.set_resolved_url(item)
    action_play(item)

def get_video_link(players, params, mode, use_simple=False):
    lister = Lister()
    # Extend parameters
    for lang, lang_params in params.items():
        for key, value in lang_params.items():
            if isinstance(value, basestring):
                params[lang][key + "_+"] = value.replace(" ", "+")
                params[lang][key + "_-"] = value.replace(" ", "-")
                params[lang][key + "_escaped"] = value.replace(" ", "%2520")
                params[lang][key + "_escaped+"] = value.replace(" ", "%252B")
    pDialog = None
    selection = None
    try:
        if len(players) > 1 and use_simple:
            index = dialogs.select(_("Play using..."), [player.title for player in players])
            if index == -1: return None
            players = [players[index]]
        resolve_f = lambda p : resolve_player(p, lister, params)
        if len(players) > 1:
            pool_size = plugin.get_setting(SETTING_POOL_SIZE, int)
            populator = lambda : execute(resolve_f, players, lister.stop_flag, pool_size)
            selection = dialogs.select_ext(_("Play using..."), populator, len(players))
        else:
            result = resolve_f(players[0])
            if result:
                title, links = result
                if len(links) == 1: selection = links[0]
                else:
                    index = dialogs.select(_("Play using..."), [x['label'] for x in links])
                    if index > -1: selection = links[index]
            else: dialogs.ok(_("Error"), _("%s not found") % _("Video"))
    finally: lister.stop()
    return selection
def check_opensubtitle(title,imdb_id,tmdb,year,tvshow,season,episode):
      import urllib2
      if 'tt' in imdb_id:
 
        search_data = OSDBServer().searchsubtitles(title,imdb_id,year,tvshow,season,episode)
        return search_data
      else:
        if len(tmdb)>0:

          url='https://api.themoviedb.org/3/movie/'+tmdb+'?api_key=34142515d9d23817496eeb4ff1d223d0'
          req = urllib2.Request(url)
          req.add_header('User-Agent', __USERAGENT__)
          response = urllib2.urlopen(req).read()
  
          json_data=(json.loads(response))

          imdb_id=(json_data['imdb_id'])
          search_data = OSDBServer().searchsubtitles(title,imdb_id,year,tvshow,season,episode)


          return search_data
def metaliq_fix():
  import urllib2,time,zipfile
  name='נגנים'
  link='https://github.com/kodianonymous1/Anonymous/raw/master/players.zip'
  iiI1iIiI = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
  iiiI11 = xbmcgui . DialogProgress ( )
  iiiI11 . create ( "XBMC ISRAEL" , "Downloading " +name, '' , 'Please Wait' )
  OOooO = os . path . join ( iiI1iIiI , 'isr.zip' )
  req = urllib2.Request(link)
  remote_file = urllib2.urlopen(req)
  #the_page = response.read()
  dp = xbmcgui.DialogProgress()
  dp.create("Downloading", "Downloading " +name)
  dp.update(0)

  f = open(OOooO, 'wb')

  try:
    total_size = remote_file.info().getheader('Content-Length').strip()
    header = True
  except AttributeError:
        header = False # a response doesn't always include the "Content-Length" header

  if header:
        total_size = int(total_size)

  bytes_so_far = 0
  start_time=time.time()
  while True:
        buffer = remote_file.read(8192)
        if not buffer:
            sys.stdout.write('\n')
            break

        bytes_so_far += len(buffer)
        f.write(buffer)

        if not header:
            total_size = bytes_so_far # unknown size
        if dp.iscanceled(): 
           dp.close()
           try:
            os.remove(OOooO)
           except:
            pass
           break
        percent = float(bytes_so_far) / total_size
        percent = round(percent*100, 2)
        currently_downloaded=bytes_so_far/ (1024 * 1024) 
        total=total_size/ (1024 * 1024) 
        mbs = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % ('teal', 'skyblue', currently_downloaded, 'teal', total) 
        if (time.time() - start_time) >0:
          kbps_speed = bytes_so_far / (time.time() - start_time) 
          kbps_speed = kbps_speed / 1024 
        else:
         kbps_speed=0
        type_speed = 'KB'
        if kbps_speed >= 1024:
           kbps_speed = kbps_speed / 1024 
           type_speed = 'MB'
        if kbps_speed > 0 and not percent == 100: 
            eta = (total_size - bytes_so_far) / kbps_speed 
        else: 
            eta = 0
        e   = '[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s ' % ('teal', 'skyblue', kbps_speed, type_speed)

        dp.update(int(percent), "Downloading " +name,mbs,e )
        #sys.stdout.write("Downloaded %d of %d bytes (%0.2f%%)\r" % (bytes_so_far, total_size, percent))
  
  II111iiii = xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.metalliq_Subs/players' ) )

     
  f.close()
  zin = zipfile.ZipFile(OOooO, 'r')
  zin.extractall(II111iiii)
  #extract  ( OOooO , II111iiii,dp )


  try:
    os.remove(OOooO)
  except:
    pass
  if os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.metalliq_Subs'):
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.metalliq_Subs/settings/players/all)")

  dp.close()
class URLHandler():
    def __init__(self):
        self.opener = urllib2.build_opener()
        self.opener.addheaders = [('Accept-Encoding', 'gzip'),
                                  ('Accept-Language', 'en-us,en;q=0.5'),
                                  ('Pragma', 'no-cache'),
                                  ('Cache-Control', 'no-cache'),
                                  ('User-Agent',
                                   'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 Kodi/17.2 (KHTML, like Gecko) Chrome/49.0.2526.111 Safari/537.36')]

    def request(self, url, data=None, query_string=None, ajax=False, referrer=None, cookie=None):
        if data is not None:
            data = urllib.urlencode(data)
        if query_string is not None:
            url += '?' + urllib.urlencode(query_string)
        if ajax:
            self.opener.addheaders += [('X-Requested-With', 'XMLHttpRequest')]
        if referrer is not None:
            self.opener.addheaders += [('Referrer', referrer)]
        if cookie is not None:
            self.opener.addheaders += [('Cookie', cookie)]

        content = None
        log.info("Getting url: %s" % (url))
        if data is not None and 'password' not in data:
            log.info("Post Data: %s" % (data))
        try:
            response = self.opener.open(url, data)
            content = None if response.code != 200 else response.read()

            if response.headers.get('content-encoding', '') == 'gzip':
                try:
                    content = zlib.decompress(content, 16 + zlib.MAX_WBITS)
                except zlib.error:
                    pass

            if response.headers.get('content-type', '') == 'application/json':
                content = json.loads(content, encoding="utf-8")

            response.close()
        except Exception as e:
            log.info("Failed to get url: %s\n%s" % (url, e))
            # Second parameter is the filename
        return content
urlHandler = URLHandler()
def check_wanted_players():
  log.info('players222222222')
  players=Addon.getSetting("players")

  found=0
  if players=="0":
    log.info(os.path.join(user_dataDir,'players'))
    if os.path.exists(os.path.join(user_dataDir,'players')):
      for filename in os.listdir(os.path.join(user_dataDir,'players',".")):
       if 'torrenter' in filename:
         found=1
       if 'torrenter' not in filename and 'datefile' not in filename:
         os.remove(os.path.join(user_dataDir,'players',filename))
    if found==0:
      metaliq_fix()
      for filename in os.listdir(os.path.join(user_dataDir,'players',".")):
       if 'torrenter' not in filename and 'datefile' not in filename:
         os.remove(os.path.join(user_dataDir,'players',filename))
  elif players=="1":
    if os.path.exists(os.path.join(user_dataDir,'players')):
      for filename in os.listdir(os.path.join(user_dataDir,'players',".")):
       if 'quasar' in filename:
         found=1
       if 'quasar' not in filename and 'datefile' not in filename:
         os.remove(os.path.join(user_dataDir,'players',filename))
    if found==0:
      metaliq_fix()
      for filename in os.listdir(os.path.join(user_dataDir,'players',".")):
       if 'quasar' not in filename and 'datefile' not in filename:
         os.remove(os.path.join(user_dataDir,'players',filename))
  elif players=="2":
      if os.path.exists(os.path.join(user_dataDir,'players')):
        list = os.listdir(os.path.join(user_dataDir,'players')) # dir is your directory path
        number_files = len(list)
        if number_files<3:
          metaliq_fix()
  elif players=="3":
    if os.path.exists(os.path.join(user_dataDir,'players')):
      for filename in os.listdir(os.path.join(user_dataDir,'players',".")):
       if 'magnetic' in filename:
         found=1
       if 'magnetic' not in filename and 'datefile' not in filename:
         os.remove(os.path.join(user_dataDir,'players',filename))
    if found==0:
      metaliq_fix()
      for filename in os.listdir(os.path.join(user_dataDir,'players',".")):
       if 'magnetic' not in filename and 'datefile' not in filename:
         os.remove(os.path.join(user_dataDir,'players',filename))
      #os.rename(os.join(user_dataDir,'players'),os.join(user_dataDir,'old_players'))
def notify(msg_id):
    xbmc.executebuiltin((u'Notification(%s,%s)' % (__scriptname__, __language__(msg_id))).encode('utf-8'))
def subcenter_search(item,mode_subtitle):
        import re
        results = []
        
        id_collection=[]
        search_string = re.split(r'\s\(\w+\)$', item["tvshow"])[0] if item["tvshow"] else item["title"]
        user_token =  get_user_token()

        if user_token:
            query = {"q": search_string.encode("utf-8"), "user": user_token["user"], "token": user_token["token"]}
            if item["tvshow"]:
                query["type"] = "series"
                query["season"] = item["season"]
                query["episode"] = item["episode"]
            else:
                query["type"] = "movies"
                if item["year"]:
                    query["year_start"] = int(item["year"]) 
                    query["year_end"] = int(item["year"])

            search_result =  urlHandler.request( BASE_URL + "search/", query)
   
            if search_result is not None and search_result["result"] == "failed":
                # Update cached token
                user_token =  get_user_token(True)
                query["token"] = user_token["token"]
                search_result =  urlHandler.request( BASE_URL + "search/", query)

            if search_result is not None and search_result["result"] == "failed":
                notify(32009)
                if mode_subtitle>1:
                   return results," "," "
                else:
                   return len(results)," "," "



            if search_result is None or search_result["result"] != "success" or search_result["count"] < 1:
                if mode_subtitle>1:
                   return results," "," "
                else:
                    return len(results)," "," "

            results = search_result# _filter_results(search_result["data"], search_string, item)
            
           # log.info("Filtered: %s" % results)

        else:
            notify(32009)
        ret = []
        ok=True
        lang=[]
        lang.append('he')

        for result in results['data']:
            total_downloads = 0
            counter = 0
            
            subs_list = result
     
            if subs_list is not None:
               

                for language in subs_list['subtitles']:
                        
                        
                       if language in lang:
                    #if xbmc.convertLanguage(language, xbmc.ISO_639_2) in item["3let_language"]:
                        for current in subs_list['subtitles'][language]:
                            

                            counter += 1
                            title = current["version"]
                            subtitle_rate = 0
                            total_downloads += int(current["downloads"])
                            ret.append(
                                {   'lang_index':'0',# item["3let_language"].index('heb'),
                                    'filename': title,
                                    'link': current["key"],
                                    'language_name': xbmc.convertLanguage(language, xbmc.ENGLISH_NAME),
                                    'language_flag': language,
                                    'id': current["id"],
                                    'rating': current["downloads"],
                                    'sync': subtitle_rate >= 3.8,
                                    'hearing_imp': False,
                                    'is_preferred':
                                        xbmc.convertLanguage(language, xbmc.ISO_639_2) == item[
                                            'preferredlanguage']
                                })
            # Fix the rating
            if total_downloads:
                for it in ret[-1 * counter:]:
                    it["rating"] = str(min(int(round(float(it["rating"]) / float(total_downloads), 1) * 8), 5))

        number_of_subs=0
        x=1
        saved_data=[]
        results2= sorted(ret, key=lambda x: (x['is_preferred'], x['lang_index'], x['sync'], x['rating']), reverse=True)
        
        return results2
        '''
        subtitle=" "
        json_data=[]
        db=[]
        
        if results2:
         for it in results2:

            number_of_subs=number_of_subs+1
            listitem = ListItem(label=it["language_name"],
                                        label2='[COLOR lightskyblue]'+str(x)+'. '+' [SC]' +it["filename"]+'[/COLOR]',
                                        iconImage=it["rating"],
                                        thumbnailImage=it["language_flag"]
                                        )
            if it["sync"]:
                listitem.setProperty("sync", "true")
                sync='true'
            else:
                listitem.setProperty("sync", "false")
                sync='false'

            if it.get("hearing_imp", False):
                listitem.setProperty("hearing_imp", "true")
                hearing_imp='true'
            else:
                listitem.setProperty("hearing_imp", "false")
                hearing_imp="false"

            url = "plugin://%s/?action=download&link=%s&id=%s&filename=%s&language=%s" % (
                __scriptid__, it["link"], it["id"], it["filename"], it["language_flag"])
            if it["id"] not in id_collection:
              id_collection.append(it["id"])
              if mode_subtitle>1:
                json_data={'url':url,
                             'label':it["language_name"],
                             'label2':'[COLOR lightskyblue]'+str(x)+'. '+' [SC]' +it["filename"]+'[/COLOR]',
                             'iconImage':it["rating"],
                             'thumbnailImage':it["language_flag"],
                             'hearing_imp':hearing_imp,
                             'sync':sync}
                db.append(json_data)
                #addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=listitem, isFolder=False)
                x=x+1
              else:
                json_data={'url':url,
                             'label':it["language_name"],
                             'label2':'[COLOR lightskyblue]'+str(x)+'. '+' [SC]' +it["filename"]+'[/COLOR]',
                             'iconImage':it["rating"],
                             'thumbnailImage':it["language_flag"],
                             'hearing_imp':hearing_imp,
                             'sync':sync}
                db.append(json_data)
                ok,subtitle=download(it["id"],it["language_flag"],it["link"],it["filename"],mode_subtitle)
                if ok==True:
                 return len(results2),subtitle,db
                else:
                 return 0

        if mode_subtitle>1:
          return results2,subtitle,db
        else:
          return len(results2),subtitle,db
        '''
def login( notify_success=True):
 
  
        email = Addon.getSetting("Email")
        password = Addon.getSetting("Password")
        if email=='' or password=='':
          __settings__.openSettings()
          email = Addon.getSetting("Email")
          password = Addon.getSetting("Password")
        post_data = {'username': email, 'password': password}
        content = urlHandler.request(BASE_URL + "login/", post_data)
        #log.info(content)
        if content['result'] == 'success':
            if notify_success:
                notify(32010)

            del content["result"]
            return content
        else:
            notify(32009)
            return None
def get_user_token( force_update=False):
        if force_update:
            store.delete('credentials')

        results = store.get('credentials')
        if results:
            results = json.loads(results)
        else:
            results = login(False)
            if results:
                store.set('credentials', json.dumps(results))
        
        return results
def search_for_subs(params):
   import requests
   title=''
   year=0
   tmdb=''
   imdb_id=''
   season=0
   episode=0
   tvshow=''
   if 'originaltitle' in params['en']:
     title=(params['en']['originaltitle'])
   elif 'originaltitle' in params['en']['info']:
     title=(params['en']['info']['originaltitle'])
   if 'tmdb' in params['en']:
     tmdb=str(params['en']['tmdb'])
   if 'imdb' in params['en']:
     imdb_id=str(params['en']['imdb'])
   if 'season' in params['en']:
     season=(params['en']['season'])
   if 'episode' in params['en']:
     episode=(params['en']['episode'])
   if 'tvshowtitle' in params['en']['info']:
     log.info('tvshowtitlessssssssssssssssssssssssssssss')
     tvshow=params['en']['showname']
     
   item2 = {}
   item2['file_original_path'] = ""
   if 'year' in item2: 
     item2['year']=int(year)
   
   
   year=(params['en']['year'])
   item2['season']=season
   item2['episode']=episode
   item2['title']=title
   if len(tvshow)>0:
     item2['tvshow']=tvshow
   else:
     item2['tvshow']=''
   item2['year']=year
   item2['title']=title
   item2['preferredlanguage']='he'
   all_subs=[]
   all_links=[]
   try:
   
   
     search_subscenter=subcenter_search(item2,3)
     for it in search_subscenter:
         if it['filename'] not in all_links:
            all_subs.append('[COLOR khaki][SC] '+it['filename']+'[/COLOR]')

            all_links.append(it['filename'])
   except: 
     pass
   url = "http://api.wizdom.xyz/search.id.php?imdb=%s&season=%s&episode=%s&version=%s"%(imdb_id,season,episode,title)
   log.info(url)
   try:
     html=requests.get(url).json()
     for items in html:
             if items['versioname'] not in all_links:
              all_subs.append('[COLOR lightblue][WIZ] '+items['versioname']+'[/COLOR]')

              all_links.append(items['versioname'])
   except: 
     pass
   search_data=check_opensubtitle(title,imdb_id,tmdb,year,tvshow,str(season),str(episode))
   #search_data = OSDBServer().searchsubtitles(name,imdbid)

   if search_data:
       for items in search_data:
        if items['SubFileName'].replace('.srt','').replace('.sub','') not in all_links:
         all_subs.append('[COLOR aqua][OPS] '+items["SubFileName"].replace('.srt','').replace('.sub','')+'[/COLOR]')
         all_links.append(items["SubFileName"].replace('.srt',''))

     

   if len(all_subs)==0:
     xbmcgui.Dialog().ok('Error occurred',"לא נמצאו כתוביות")
   else:
    ret = xbmcgui.Dialog().select("בחר מקור", all_subs)
    if ret!=-1:
      return all_links[ret]
     
     
def on_play_video(mode, players, params, trakt_ids=None):
    if plugin.get_setting(SETTING_AUTOPATCH, bool) == True: patch("auto")
    assert players
    # Cancel resolve
    action_cancel()
    # Get video link
    use_simple_selector = plugin.get_setting(SETTING_USE_SIMPLE_SELECTOR, bool)
    is_extended = not (use_simple_selector or len(players) == 1)
    log.info("HERE FINALY")
    log.info(Addon.getSetting("directplay"))
    if Addon.getSetting("directplay")=="1":
      params['en']['title']=search_for_subs(params)
      params['en']['name']=params['en']['title']
    log.info('check players')
    check_wanted_players()
    log.info(params['en']['title'])
    if not is_extended: xbmc.executebuiltin("ActivateWindow(busydialog)")
    try: selection = get_video_link(players, params, mode, use_simple_selector)
    finally:
        if not is_extended: xbmc.executebuiltin("Dialog.Close(busydialog)")
    if not selection: return
    # Get selection details
    link = selection['path']
    action = selection.get('action', '')
    plugin.log.info('Playing url: %s' % to_utf8(link))
    # Activate link
    if action == "ACTIVATE": action_activate(link)
    elif action == "RUN": action_run(link)
    elif action == "PRERUN": action_prerun(link)
    elif action == "PLAYMEDIA": action_playmedia(link)
    elif action == "PRERUNRETURN": metaplayer().action_prerun(link)
    else:
        if trakt_ids: set_property('script.trakt.ids', json.dumps(trakt_ids))
        return link
    return None

def resolve_player(player, lister, params):
    results = []
    for command_group in player.commands:  
        if xbmc.abortRequested or not lister.is_active(): return
        command_group_results = []
        for command in command_group:
            if xbmc.abortRequested or not lister.is_active(): return
            lang = command.get("language", "en")
            if not lang in params: continue
            parameters = params[lang]
            try:
                link = apply_parameters(to_unicode(command["link"]), parameters)
            except:
                print_exc()
                continue
            if link == "movies" and player.media == "movies":
                video = get_movie_from_library(parameters['imdb'])
                if video:
                    command_group_results.append(video)
            elif link == "tvshows" and player.media == "tvshows":
                video = get_episode_from_library(parameters['id'], parameters['season'], parameters['episode'])
                if not video:
                    video = get_episode_from_library(parameters['tmdb'], parameters['season'], parameters['episode'])
                if video:
                    command_group_results.append(video)
            elif not command.get("steps"):
                command_group_results.append(
                    {
                        'label': player.title,
                        'path': urlencode_path(link),
                        'action': command.get("action", "PLAY")
                    }
                )
            else:
                steps = [to_unicode(step) for step in command["steps"]]
                files, dirs = lister.get(link, steps, parameters)
                if command.get("action", "PLAY") == "ACTIVATE":
                    files += dirs
                if files:
                    command_group_results += [
                        {
                            'label': f['label'],
                            'path': player.postprocess(f['path']),
                            'action': command.get("action", "PLAY")
                        } for f in files]
            if command_group_results:
                break
        results += command_group_results
    if results:
        return player.title, results


class metaplayer(xbmc.Player):
    def __init__(self):
        xbmc.Player.__init__(self)
        self.returnlink = xbmc.getInfoLabel('Container.FolderPath')
        xbmc.log("returnlink: " + repr(self.returnlink), xbmc.LOGNOTICE)

    def action_prerun(self, link):
        #    xbmc.executebuiltin('ActivateWindow(10025,addons://user/xbmc.addon.video/plugin.video.zen/,return)')
        if link.startswith("plugin://"):
            id = link.split("/")
            xbmc.executebuiltin('RunAddon(%s)' % id[2])
            while xbmc.getInfoLabel('Container.PluginName') != id[2] or xbmc.getCondVisibility('Window.IsActive(busydialog)'): xbmc.sleep(250)
            xbmc.sleep(250)
            self.play(link)
        while xbmc.getInfoLabel('Container.PluginName') == id[2] and xbmc.getInfoLabel('Container.FolderPath') != "plugin://%s/" % id[2] and id[2] in xbmc.getInfoLabel('Container.FolderPath'):
            xbmc.sleep(250)
            if xbmc.getInfoLabel('Container.FolderPath') == "plugin://%s/" % id[2] or id[2] not in xbmc.getInfoLabel('Container.FolderPath'):
                break
        xbmc.executebuiltin('Container.Update("%s", replace)' % self.returnlink)

    def onPlayBackEnded(self):
        xbmc.executebuiltin('Container.Update("%s", replace)' % self.returnlink)

    def onPlayBackStopped(self):
        xbmc.executebuiltin('Container.Update("%s", replace)' % self.returnlink)