# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys
import traceback
import logging,shutil
import HTMLParser,time
from shutil import copyfile

_plugin_name_='plugin.program.Settingz'
__debuging__="DEBUG_MODE"
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
__settings__ = xbmcaddon.Addon(id=_plugin_name_)
addonName = __settings__.getAddonInfo("name")
addonIcon = __settings__.getAddonInfo('icon')
__language__ = __settings__.getLocalizedString
#__cachePeriod__ = __settings__.getSetting("cache")
__PLUGIN_PATH__ = __settings__.getAddonInfo('path')
__DEBUG__ = __settings__.getSetting("DEBUG") == "true"
__addon__ = xbmcaddon.Addon()
ADDON=xbmcaddon.Addon(id=_plugin_name_)
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')
sys.modules["__main__"].dbg = True
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
#cacheServer = StorageServer.StorageServer("plugin.video.Ebs_RSS", __cachePeriod__)  # (Your plugin name, Cache time in hours)
AddonID = _plugin_name_
Addon = xbmcaddon.Addon(AddonID)
localizedString = Addon.getLocalizedString 
user_dataDir = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")

     
LIB_PATH = xbmc.translatePath( os.path.join( __PLUGIN_PATH__, 'resources', 'mail' ) )
sys.path.append (LIB_PATH)
COLOR1         = 'teal'
COLOR2         = 'red'


def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     
def addDir(contentType, name, url, mode, iconimage='DefaultFolder.png', elementId='', summary='', fanart='',isRealFolder=True):
        try:
           
            u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + name + "&module=" + urllib.quote_plus(elementId)
            liz = xbmcgui.ListItem(clean(contentType, name), iconImage=iconimage, thumbnailImage=iconimage)
            liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote(clean(contentType, name)), "Plot": urllib.unquote(summary)})
            if not fanart == '':
                liz.setProperty("Fanart_Image", fanart)
               
            ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isRealFolder)
            if __DEBUG__:
                 
                print "added directory success:" + clean(contentType, name) + " url=" + clean('utf-8',u)
            return ok
        except Exception as e:
            print "WALLA exception in addDir"
            print e
            raise
     
def addDir2_2(name,url,mode,iconimage,fanart,description):

        uinstall_package=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        

        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        
       # xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL)
        
   
        return ok
###############################################################################################################        

def addDir3(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        
        return ok

def addDir2(name,url,mode,iconimage,fanart,description):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Audio", infoLabels={ "Title": name } )
    if not fanart == '':
                liz.setProperty("Fanart_Image", fanart)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok

def main_menu():
     
     addDir3("[COLOR powederblue]טורנטר[/COLOR]",'plugin.',2,__PLUGIN_PATH__ + "/resources/torrenter.png",__PLUGIN_PATH__ + "/resources/torrenter.png","התקן את טורנטר")
     addDir3("[COLOR powederblue]Kmedia Torrent[/COLOR]",'plugin.',7,__PLUGIN_PATH__ + "/resources/kmedia.png",__PLUGIN_PATH__ + "/resources/kmedia.png","התקן את KMEDIA")
     addDir3("[COLOR powederblue]קודי פופקורן[/COLOR]",'plugin.',3,__PLUGIN_PATH__ + "/resources/popcorn.jpg",__PLUGIN_PATH__ + "/resources/popcorn.jpg","התקן את קודי פופקורן")
     addDir3("[COLOR khaki]Gdrive[/COLOR]",'plugin.',4,__PLUGIN_PATH__ + "/resources/gdrive.jpg",__PLUGIN_PATH__ + "/resources/gdrive.jpg","התקן אל גוגל דרייב")
     if os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.metalliq_Subs') or os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.metalliq'):
       addDir2("[COLOR purple]התקנת נגנים למטליק[/COLOR]",'plugin.',8,__PLUGIN_PATH__ + "/resources/metaliq.png",__PLUGIN_PATH__ + "/resources/metaliq.png","מתקינה את כל נגני מטליק")

def dis_or_enable_addon(addon_id,mode, enable="true"):
    import json
    addon = '"%s"' % addon_id
    if xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id) and enable == "true":
        logging.warning('already Enabled')
        return xbmc.log("### Skipped %s, reason = allready enabled" % addon_id)
    elif not xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id) and enable == "false":
        return xbmc.log("### Skipped %s, reason = not installed" % addon_id)
    else:
        do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}' % (addon, enable)
        query = xbmc.executeJSONRPC(do_json)
        response = json.loads(query)
        if enable == "true":
            xbmc.log("### Enabled %s, response = %s" % (addon_id, response))
        else:
            xbmc.log("### Disabled %s, response = %s" % (addon_id, response))
    if mode=='auto':
     return True
    return xbmc.executebuiltin('Container.Update(%s)' % xbmc.getInfoLabel('Container.FolderPath'))
def _iter_python26(node):
  return [node] + node.findall('.//*')
def install_package(url,with_massage,mode='manual'):
   extension=url.split("$$$")
   logging.warning(url)
   if 'http' in url:
    if not os.path.exists(xbmc.translatePath("special://home/addons/") + extension[2].rstrip('\r\n').replace('%24','$')) or mode=='auto':


      logging.warning(extension)
      #downloader_is(extension[0],extension[1],with_massage)
      download(extension[0],extension[1])


      dis_or_enable_addon(extension[2].rstrip('\r\n'),mode)
     
    elif with_massage=='yes':
      dialog = xbmcgui.Dialog()
      choice=dialog.yesno("Kodi Maintenance", '','[B][COLOR red]Already Installed[/COLOR][/B]', "Install again Any way?")
      if    choice :
        #downloader_is(extension[0],extension[1],'false')
        download(extension[0],extension[1])
        dis_or_enable_addon(extension[2].rstrip('\r\n'),mode)
        
   else:
     from xml.etree import ElementTree as et
    
     src=extension[0]
     dst=extension[1]+'/settings.xml'
     logging.warning(src)
     logging.warning(dst)
     if 'torrenter' in url:
       src2=__PLUGIN_PATH__ + "/resources/magnetic/setting.xml"
       dst2=xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/script.module.magnetic' ) )+'/settings.xml'

       copyfile(src2,dst2)
       string_to_change='storage'
     if 'kmedia' in url:
        string_to_change='dlpath'
     elif 'popcorn' in url:
       string_to_change='movies_download_path'
       # Read in the file
       file_o=xbmc.translatePath("special://home/addons/") + 'plugin.video.kodipopcorntime/resources/lib/kodipopcorntime/gui/player.py'

       with open(file_o, 'r') as file :
          filedata = file.read()

        # Replace the target string
       filedata = filedata.replace(": int(xbmc.getInfoLabel('ListItem.VideoResolution')),", ": 1920,#int(xbmc.getInfoLabel('ListItem.VideoResolution')),")

        # Write the file out again
       with open(file_o, 'w') as file:
          file.write(filedata)
     elif 'gdrive' in url:
       string_to_change='NONE'
     if string_to_change!='NONE':
         #dialog = xbmcgui.Dialog()
         #stoarge=dialog.browse( 3, "Temp File Location", "files" )
         stoarge=xbmc.translatePath("special://temp")
         logging.warning(stoarge)
         if len(stoarge)>2:
             tree = et.parse(src)
             root = tree.getroot()
             
             for rank in root.getiterator('setting'):
                if (rank.get('id',string_to_change))==string_to_change:
                   rank.set('value',stoarge)
                   
                   
       
             tree.write(src)


   
     copyfile(src,dst)
     if with_massage=='yes':
       dialog = xbmcgui.Dialog()
       dialog.ok("Kodi Setting", 'שינוי הגדרות הצליח')
		
def metaliq_fix():
  link='https://github.com/kodianonymous1/Anonymous/raw/master/players.zip'
  iiI1iIiI = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
  iiiI11 = xbmcgui . DialogProgress ( )
  iiiI11 . create ( "XBMC ISRAEL" , "Downloading " +name, '' , 'Please Wait' )
  OOooO = os . path . join ( iiI1iIiI , 'isr.zip' )
  req = urllib2.Request(link)
  remote_file = urllib2.urlopen(req)
  #the_page = response.read()
  dp = xbmcgui.DialogProgress()
  dp.create("Downloading", "Downloading " +name)
  dp.update(0)

  f = open(OOooO, 'wb')

  try:
    total_size = remote_file.info().getheader('Content-Length').strip()
    header = True
  except AttributeError:
        header = False # a response doesn't always include the "Content-Length" header

  if header:
        total_size = int(total_size)

  bytes_so_far = 0
  start_time=time.time()
  while True:
        buffer = remote_file.read(8192)
        if not buffer:
            sys.stdout.write('\n')
            break

        bytes_so_far += len(buffer)
        f.write(buffer)

        if not header:
            total_size = bytes_so_far # unknown size
        if dp.iscanceled(): 
           dp.close()
           try:
            os.remove(OOooO)
           except:
            pass
           break
        percent = float(bytes_so_far) / total_size
        percent = round(percent*100, 2)
        currently_downloaded=bytes_so_far/ (1024 * 1024) 
        total=total_size/ (1024 * 1024) 
        mbs = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % ('teal', 'skyblue', currently_downloaded, 'teal', total) 
        if (time.time() - start_time) >0:
          kbps_speed = bytes_so_far / (time.time() - start_time) 
          kbps_speed = kbps_speed / 1024 
        else:
         kbps_speed=0
        type_speed = 'KB'
        if kbps_speed >= 1024:
           kbps_speed = kbps_speed / 1024 
           type_speed = 'MB'
        if kbps_speed > 0 and not percent == 100: 
            eta = (total_size - bytes_so_far) / kbps_speed 
        else: 
            eta = 0
        e   = '[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s ' % ('teal', 'skyblue', kbps_speed, type_speed)

        dp.update(int(percent), "Downloading " +name,mbs,e )
        #sys.stdout.write("Downloaded %d of %d bytes (%0.2f%%)\r" % (bytes_so_far, total_size, percent))
  
  II111iiii = xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.metalliq_Subs/players' ) )
  II111iiii2 = xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.metalliq/players' ) )
     
  f.close()
  extract  ( OOooO , II111iiii,dp )
  extract  ( OOooO , II111iiii2,dp )

  try:
    os.remove(OOooO)
  except:
    pass
  if os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.metalliq_Subs'):
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.metalliq_Subs/settings/players/all)")
  if os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.metalliq'):
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.metalliq/settings/players/all)")
  dp.close()
def downloader_is (url,name,with_massage ) :
 import downloader,extract   
 i1iIIII = xbmc . getInfoLabel ( "System.ProfileName" )
 I1 = xbmc . translatePath ( os . path . join ( 'special://home' , '' ) )
 O0OoOoo00o = xbmcgui . Dialog ( )
 if name.find('repo')< 0 and with_massage=='yes':
     choice = O0OoOoo00o . yesno ( "XBMC ISRAEL" , "Yes to install" ,name)
 else:
     choice=True
 if    choice :
  iiI1iIiI = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
  iiiI11 = xbmcgui . DialogProgress ( )
  iiiI11 . create ( "XBMC ISRAEL" , "Downloading " +name, '' , 'Please Wait' )
  OOooO = os . path . join ( iiI1iIiI , 'isr.zip' )
  try :
     os . remove ( OOooO )
  except :
      pass
  downloader . download ( url , OOooO ,name, iiiI11 )
  II111iiii = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
  iiiI11 . update ( 0 , name , "Extracting Zip Please Wait" )

  extract . all ( OOooO , II111iiii , iiiI11 )
  iiiI11 . update ( 0 , name , "Downloading" )
  iiiI11 . update ( 0 , name , "Extracting Zip Please Wait" )
  xbmc . executebuiltin ( 'UpdateLocalAddons ' )
  xbmc . executebuiltin ( "UpdateAddonRepos" )

def torent_menu():
  dialog = xbmcgui.Dialog()
  system=['Windows','Android']
  ret = dialog.select("בחר מערכת להתקנה", system)
  if ret==0:
   type='windows'
  elif ret==1:
   type='android'
  else:
   sys.exit()
  addDir2("[COLOR blue]התקנה אוטומטית[/COLOR]",'auto$$$torrenter$$$'+type,5,__PLUGIN_PATH__ + "/resources/torrenter.png",__PLUGIN_PATH__ + "/resources/torrenter.png","התקן את טורנטר")
  addDir3("[COLOR blue]התקנה ידנית[/COLOR]",'manual$$$torrenter$$$'+type,5,__PLUGIN_PATH__ + "/resources/torrenter.png",__PLUGIN_PATH__ + "/resources/torrenter.png","התקן את טורנטר")
def extract(src,dst,dp):
    import zipfile
    logging.warning(src)
    zin = zipfile.ZipFile(src,  'r')

    nFiles = float(len(zin.infolist()))
    count  = 0

    
    for item in zin.infolist():
            count += 1
            update = count / nFiles * 100
            dp.update(int(update),'Extracting')
            zin.extract(item, dst)
    

    return True
def download(link,dest):
  iiI1iIiI = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
  iiiI11 = xbmcgui . DialogProgress ( )
  iiiI11 . create ( "XBMC ISRAEL" , "Downloading " +name, '' , 'Please Wait' )
  OOooO = os . path . join ( iiI1iIiI , 'isr.zip' )
  req = urllib2.Request(link)
  remote_file = urllib2.urlopen(req)
  #the_page = response.read()
  dp = xbmcgui.DialogProgress()
  dp.create("Downloading", "Downloading " +name)
  dp.update(0)
  images_file=dest
  f = open(OOooO, 'wb')

  try:
    total_size = remote_file.info().getheader('Content-Length').strip()
    header = True
  except AttributeError:
        header = False # a response doesn't always include the "Content-Length" header

  if header:
        total_size = int(total_size)

  bytes_so_far = 0
  start_time=time.time()
  while True:
        buffer = remote_file.read(8192)
        if not buffer:
            sys.stdout.write('\n')
            break

        bytes_so_far += len(buffer)
        f.write(buffer)

        if not header:
            total_size = bytes_so_far # unknown size
        if dp.iscanceled(): 
           dp.close()
           try:
            os.remove(OOooO)
           except:
            pass
           break
        percent = float(bytes_so_far) / total_size
        percent = round(percent*100, 2)
        currently_downloaded=bytes_so_far/ (1024 * 1024) 
        total=total_size/ (1024 * 1024) 
        mbs = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % ('teal', 'skyblue', currently_downloaded, 'teal', total) 
        if (time.time() - start_time) >0:
          kbps_speed = bytes_so_far / (time.time() - start_time) 
          kbps_speed = kbps_speed / 1024 
        else:
         kbps_speed=0
        type_speed = 'KB'
        if kbps_speed >= 1024:
           kbps_speed = kbps_speed / 1024 
           type_speed = 'MB'
        if kbps_speed > 0 and not percent == 100: 
            eta = (total_size - bytes_so_far) / kbps_speed 
        else: 
            eta = 0
        e   = '[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s ' % ('teal', 'skyblue', kbps_speed, type_speed)

        dp.update(int(percent), "Downloading " +name,mbs,e )
        #sys.stdout.write("Downloaded %d of %d bytes (%0.2f%%)\r" % (bytes_so_far, total_size, percent))
  
  II111iiii = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
     
  f.close()
  extract  ( OOooO , II111iiii,dp )
  xbmc . executebuiltin ( 'UpdateLocalAddons ' )
  xbmc . executebuiltin ( "UpdateAddonRepos" )
  try:
    os.remove(OOooO)
  except:
    pass
  dp.close()
def popcorn_menu():
  dialog = xbmcgui.Dialog()
  system=['Windows','Android']
  ret = dialog.select("בחר מערכת להתקנה", system)
  if ret==0:
   type='windows'
  elif ret==1:
   type='android'
  else:
   sys.exit()
  addDir2("[COLOR blue]התקנה אוטומטית[/COLOR]",'auto$$$popcorn$$$'+type,5,__PLUGIN_PATH__ + "/resources/popcorn.jpg",__PLUGIN_PATH__ + "/resources/popcorn.jpg","התקן את קודי פופקורן")
  addDir3("[COLOR blue]התקנה ידנית[/COLOR]",'manual$$$popcorn$$$'+type,5,__PLUGIN_PATH__ + "/resources/popcorn.jpg",__PLUGIN_PATH__ + "/resources/popcorn.jpg","התקן את קודי פופקורן")

def gdrive_menu():
  addDir2("[COLOR blue]התקנה אוטומטית[/COLOR]",'auto$$$gdrive$$$'+'windows',5,__PLUGIN_PATH__ + "/resources/gdrive.jpg",__PLUGIN_PATH__ + "/resources/gdrive.jpg","התקן אל גוגל דרייב")
  addDir3("[COLOR blue]התקנה ידנית[/COLOR]",'manual$$$gdrive$$$'+'windows',5,__PLUGIN_PATH__ + "/resources/gdrive.jpg",__PLUGIN_PATH__ + "/resources/gdrive.jpg","התקן אל גוגל דרייב")
def kmedia_menu():
  addDir2("[COLOR blue]התקנה אוטומטית[/COLOR]",'auto$$$kmedia$$$'+'windows',5,__PLUGIN_PATH__ + "/resources/kmedia.png",__PLUGIN_PATH__ + "/resources/kmedia.png","התקן את KMEDIA")
  addDir3("[COLOR blue]התקנה ידנית[/COLOR]",'manual$$$kmedia$$$'+'windows',5,__PLUGIN_PATH__ + "/resources/kmedia.png",__PLUGIN_PATH__ + "/resources/kmedia.png","התקן את KMEDIA")

def install_pack(url):
  logging.warning(url)
  target=url.split('$$$')[1]
  modes=url.split('$$$')[0]
  type=url.split('$$$')[2]
 
  user_dataDir=xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.torrenter' ) )
  if not os.path.exists(user_dataDir): # check if folder doesnt exist 
     os.makedirs(user_dataDir) # create if it doesnt
  user_dataDir=xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.kodipopcorntime' ) )
  if not os.path.exists(user_dataDir): # check if folder doesnt exist 
     os.makedirs(user_dataDir) # create if it doesnt
  user_dataDir=xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.gdrive' ) )
  if not os.path.exists(user_dataDir): # check if folder doesnt exist 
     os.makedirs(user_dataDir) # create if it doesnt
  user_dataDir=xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/script.module.magnetic' ) )
  if not os.path.exists(user_dataDir): # check if folder doesnt exist 
     os.makedirs(user_dataDir) # create if it doesnt
  
  user_dataDir=xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.kmediatorrent' ) )
  if not os.path.exists(user_dataDir): # check if folder doesnt exist 
     os.makedirs(user_dataDir) # create if it doesnt
  logging.warning(modes)
  torrent_list=('https://bitbucket.org/DiMartino/myshows.me-kodi-repo/downloads/repository.myshows.me.zip$$$Myshows Me$$$repository.myshows.me',

                'https://github.com/Pivosgroup/script.module.chardet/archive/master.zip$$$Chardet$$$script.module.chardet',
                'https://github.com/inpos/script.module.pyrrent2http/archive/master.zip$$$pyrrent2http$$$script.module.pyrrent2http',
                'https://github.com/XvBMC/repository.xvbmc/raw/master/Dependencies/zips/script.module.torrent2http/script.module.torrent2http-0.2.7.zip$$$torrent2http$$$script.module.torrent2http',
                'https://github.com/DiMartinoXBMC/script.module.libtorrent/archive/master.zip$$$libtorrent$$$script.module.libtorrent',
                'https://github.com/seppius-xbmc-repo/ru/raw/master/script.module.torrent.ts/script.module.torrent.ts-0.6.0.28.zip$$$.torrent.ts$$$script.module.torrent.ts',
                'https://github.com/DiMartinoXBMC/plugin.video.torrenter/archive/master.zip$$$torrenter$$$plugin.video.torrenter',
                'https://bitbucket.org/DiMartino/myshows.me-kodi-repo/raw/1ffef6199bae31cb3d026a6ff2268a5f0b12ca08/repo/torrenter.searcher.EZTV/torrenter.searcher.EZTV-1.0.3.zip$$$searcher.EZTV$$$torrenter.searcher.EZTV',
                'https://bitbucket.org/DiMartino/myshows.me-kodi-repo/raw/1ffef6199bae31cb3d026a6ff2268a5f0b12ca08/repo/torrenter.searcher.ThePirateBay/torrenter.searcher.ThePirateBay-1.0.4.zip$$$searcher.ThePirateBay$$$torrenter.searcher.ThePirateBay',
                'https://bitbucket.org/DiMartino/myshows.me-kodi-repo/raw/1ffef6199bae31cb3d026a6ff2268a5f0b12ca08/repo/torrenter.searcher.uTorrentCoIL/torrenter.searcher.uTorrentCoIL-1.0.0.zip$$$searcher.uTorrentCoIL$$$torrenter.searcher.uTorrentCoIL',
                'https://bitbucket.org/DiMartino/myshows.me-kodi-repo/raw/1ffef6199bae31cb3d026a6ff2268a5f0b12ca08/repo/torrenter.searcher.KickAssSo/torrenter.searcher.KickAssSo-1.0.4.zip$$$searcher.KickAssSo$$$torrenter.searcher.KickAssSo',
                'https://archive.org/download/script.module.magnetic/torrenter.searcher.Magnetic.zip$$$searcher.Magnetic$$$torrenter.searcher.Magnetic',
                'https://ftp.acc.umu.se/mirror/addons.superrepo.org/v7/addons/script.magnetic.1337x-mc/script.magnetic.1337x-mc-1.0.0.zip$$$magnetic.1337x$$$script.magnetic.1337x-mc',
                'https://ftp.acc.umu.se/mirror/addons.superrepo.org/v7/addons/script.magnetic.yts-mc/script.magnetic.yts-mc-1.0.0.zip$$$magnetic.yts$$$script.magnetic.yts-mc',
                #'https://ftp.acc.umu.se/mirror/addons.superrepo.org/v7/addons/script.magnetic.magnetdl-mc/script.magnetic.magnetdl-mc-1.0.0.zip$$$magnetic.magnetdl$$$script.magnetic.magnetdl-mc',
                'https://ftp.acc.umu.se/mirror/addons.superrepo.org/v7/addons/script.magnetic.rarbg-mc/script.magnetic.rarbg-mc-1.0.1.zip$$$magnetic.rarbg$$$script.magnetic.rarbg-mc',
                'https://ftp.acc.umu.se/mirror/addons.superrepo.org/v7/addons/script.magnetic.idope-mc/script.magnetic.idope-mc-1.0.0.zip$$$magnetic.idope$$$script.magnetic.idope-mc',
                'https://archive.org/download/script.module.magnetic/script.module.magnetic.zip$$$Magnetic$$$script.module.magnetic'
                #'https://ftp.acc.umu.se/mirror/addons.superrepo.org/v7/addons/context.magnetic.dialog/context.magnetic.dialog-1.0.6.zip$$$Magnetic.dialog$$$context.magnetic.dialog'
                
                
                
                
                
                )
  
  if modes=='manual':
    if target=='torrenter':
       for item in torrent_list:
         link=item.split('$$$')[0]
         name1=item.split('$$$')[1]
         name_ext=item.split('$$$')[2]
         name_ext_master=name_ext+'-master'
         
         if os.path.exists(xbmc.translatePath("special://home/addons/") + name_ext) or os.path.exists(xbmc.translatePath("special://home/addons/") + name_ext_master):
           name='[COLOR skyblue]'+name1+'[/COLOR]'
         else:
           name =name1
         addDir2(name,link+'$$$'+name+'$$$'+name_ext,6,__PLUGIN_PATH__ + "/resources/torrenter.png",__PLUGIN_PATH__ + "/resources/torrenter.png","התקן את טורנטר")
  
    
      
      
     
      ###########settings#####################
       addDir2("תיקון הגדרות ההרחבה",__PLUGIN_PATH__ + "/resources/torrenter/"+type+'_setting.xml$$$'+xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.torrenter' ) ),6,__PLUGIN_PATH__ + "/resources/torrenter.png",__PLUGIN_PATH__ + "/resources/torrenter.png","התקן את טורנטר")
       
    elif target=='kmedia':
      if os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.kmediatorrent'):
           name='[COLOR skyblue]Kmediatorrent[/COLOR]'
      else:
          name='Kmediatorrent'
      addDir2(name,'https://github.com/jmarth/plugin.video.kmediatorrent/archive/master.zip$$$'+name+'$$$plugin.video.kmediatorrent',6,__PLUGIN_PATH__ + "/resources/kmedia.png",__PLUGIN_PATH__ + "/resources/kmedia.png","התקן את KMEDIA")
      

      addDir2("תיקון הגדרות ההרחבה",__PLUGIN_PATH__ + "/resources/kmedia/"+type+'_setting.xml$$$'+xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.kmediatorrent' ) ),6,__PLUGIN_PATH__ + "/resources/kmedia.png",__PLUGIN_PATH__ + "/resources/kmedia.png","התקן את KMEDIA")
      
    elif target=='popcorn':
      if os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.kodipopcorntime.repository'):
           name='[COLOR skyblue]kodipopcorntime.repository[/COLOR]'
      else:
          name='kodipopcorntime.repository'
      addDir2(name,'https://github.com/markop159/Markop159-repository/raw/master/Releases/plugin.video.kodipopcorntime.repository/plugin.video.kodipopcorntime.repository-1.1.0.zip$$$'+name+'$$$plugin.video.kodipopcorntime.repository',6,__PLUGIN_PATH__ + "/resources/popcorn.jpg",__PLUGIN_PATH__ + "/resources/popcorn.jpg","התקן את קודי פופקורן")
      
      if os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.kodipopcorntime'):
           name='[COLOR skyblue]Kodi Popcorntime[/COLOR]'
      else:
          name ='Kodi Popcorntime'
      addDir2(name,'https://github.com/markop159/Markop159-repository/raw/master/Releases/plugin.video.kodipopcorntime/plugin.video.kodipopcorntime-1.7.2.zip$$$'+name+'$$$plugin.video.kodipopcorntime',6,__PLUGIN_PATH__ + "/resources/popcorn.jpg",__PLUGIN_PATH__ + "/resources/popcorn.jpg","התקן את קודי פופקורן")

   
      addDir2("תיקון הגדרות ההרחבה",__PLUGIN_PATH__ + "/resources/popcorn/"+type+'_setting.xml$$$'+xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.kodipopcorntime' ) ),6,__PLUGIN_PATH__ + "/resources/popcorn.jpg",__PLUGIN_PATH__ + "/resources/popcorn.jpg","התקן את קודי פופקורן")
      
    elif target=='gdrive':
      if os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.gdrive'):
           name='[COLOR skyblue]Gdrive[/COLOR]'
      else:
          name='Gdrive'
      addDir2(name,'https://github.com/ddurdle/ddurdle.github.io/raw/master/repository.ddurdle/plugin.video.gdrive/plugin.video.gdrive-0.8.52.zip$$$'+name+'$$$plugin.video.gdrive',6,__PLUGIN_PATH__ + "/resources/gdrive.jpg",__PLUGIN_PATH__ + "/resources/gdrive.jpgg","התקן את גוגל דרייב")
      

      addDir2("תיקון הגדרות ההרחבה",__PLUGIN_PATH__ + "/resources/gdrive/"+type+'_setting.xml$$$'+xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.gdrive' ) ),6,__PLUGIN_PATH__ + "/resources/gdrive.jpg",__PLUGIN_PATH__ + "/resources/gdrive.jpg","התקן את גוגל דרייב")
      
  elif modes=='auto':
       
       if target=='torrenter':
         for item in torrent_list:
           install_package(item,'NO','auto')

         install_package(__PLUGIN_PATH__ + "/resources/torrenter/"+type+'_setting.xml$$$'+xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.torrenter' ) ),'NO','auto')
         dialog = xbmcgui.Dialog()
         dialog.ok("Kodi Setting", 'סיימנו')
       elif target=='kmedia':
         
         install_package('https://github.com/jmarth/plugin.video.kmediatorrent/archive/master.zip$$$'+'kmediatorrent'+'$$$plugin.video.kmediatorrent','NO','auto')
         install_package(__PLUGIN_PATH__ + "/resources/kmedia/"+type+'_setting.xml$$$'+xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.kmediatorrent' ) ),'NO','auto')
         dialog = xbmcgui.Dialog()
         dialog.ok("Kodi Setting", 'סיימנו')
       elif target=='popcorn':
         install_package('https://github.com/markop159/Markop159-repository/raw/master/Releases/plugin.video.kodipopcorntime.repository/plugin.video.kodipopcorntime.repository-1.1.0.zip$$$'+'kodipopcorntime.repository'+'$$$plugin.video.kodipopcorntime.repository','NO','auto')
         install_package('https://github.com/markop159/Markop159-repository/raw/master/Releases/plugin.video.kodipopcorntime/plugin.video.kodipopcorntime-1.7.2.zip$$$'+'Kodi Popcorntime'+'$$$plugin.video.kodipopcorntime','NO','auto')
         install_package(__PLUGIN_PATH__ + "/resources/popcorn/"+type+'_setting.xml$$$'+xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.kodipopcorntime' ) ),'NO','auto')
         dialog = xbmcgui.Dialog()
         dialog.ok("Kodi Setting", 'סיימנו')
         
       elif target=='gdrive':
         
         install_package('https://github.com/ddurdle/ddurdle.github.io/raw/master/repository.ddurdle/plugin.video.gdrive/plugin.video.gdrive-0.8.52.zip$$$'+'Gdrive'+'$$$plugin.video.gdrive','NO','auto')
         install_package(__PLUGIN_PATH__ + "/resources/gdrive/"+type+'_setting.xml$$$'+xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.gdrive' ) ),'NO','auto')
         dialog = xbmcgui.Dialog()
         dialog.ok("Kodi Setting", 'סיימנו')
params=get_params()

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
   
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        main_menu()
elif mode==2:
        torent_menu()
elif mode==3:
        popcorn_menu()
elif mode==4:
        gdrive_menu()
elif mode==5:
        install_pack(url)
elif mode==6:
      install_package(url,'yes')
elif mode==7:
        kmedia_menu()
elif mode==8:
        metaliq_fix()
if len(sys.argv)>0:

 xbmcplugin.endOfDirectory(int(sys.argv[1]))
