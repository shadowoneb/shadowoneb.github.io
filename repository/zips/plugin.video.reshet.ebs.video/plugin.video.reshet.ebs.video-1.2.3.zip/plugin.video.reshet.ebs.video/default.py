# -*- coding: utf-8 -*-

import requests,xbmcgui,xbmcplugin,json,re,urllib
import time,logging
from xbmcaddon import Addon
from datetime import datetime
MyAddon = Addon()

__debug_mode__='NOT_DEBUG'

#xbmcgui.Dialog().ok("Start","start")
line1 = "This is a simple example of OK dialog"
line2 = "Showing this message using"
line3 = "XBMC python modules" 

def get_all_site_data(url,extra=3):

     dp = xbmcgui.DialogProgress()
     dp.create("רשת", "[COLOR orange][B]טוען[/B][/COLOR]")
     dp.update(0, 'מתחבר לאתר','רשת')
     Links=[]
     Pages=[]
     Seasons=[]
     r = requests.get(url)
     dp.update(0, 'מחובר','רשת')
     all_shows=[]
     #new_shows=dict(0)
     all_titles=[]
     number_episodes=0
     number_extra=0
     prejson='{'+re.compile('query = {(.+?)};').findall(r.content)[0]+'}'

     json_data=json.loads(prejson)
     all_shows=(json_data['ItemStore'])
     
     
     Content_Data=(json_data['Content'])
     Page_data=(Content_Data['PageGrid'])
     dp.update(0, 'אוסף מידע','רשת')
     x=0
     for show in all_shows.iteritems():
       name=show[1]['title']
      
       dp.update(int((x)/float(len(all_shows)) * 100), 'טוען', name.encode('utf-8'))
       if dp.iscanceled(): 
          dp.close()
          break
       all_titles.append(name)
       link=show[1]['link']
       if 'subtitle' in show[1]:
         text=show[1]['subtitle']
       else:
         text=''
      
       direct_link=''
      # if show[1]['video']!=None:
      #   direct_link=show[1]['video']['src']
   
       if show[1]['video']!=None:
            direct_link=(show[1]['video']['videoID'])

       image=show[1]['images']['app_16x9']
       date=show[1]['publishDate'].split(" ")[0].replace(".","-")
       type=show[1]['gridView']['videoItem']

       if name!=None and link!=None and image!=None and date!=None and link!=url:
          #if len (name)>0 and len (link)>0 and len (image)>0 and len (date)>0:
             if 'פרק' not in name.encode('utf-8'):
                 number_extra=number_extra+1
             else:
                 number_episodes=number_episodes+1
             Links.append((name.encode('utf-8'),text.encode('utf-8'),link,direct_link,image,date,'',type))#################Links##############
			 
     for data in Page_data:
         
       
         if 'WpQuery'in data:

          if data['WpQuery']!=None :
            
            more_data_link=data['WpQuery']['tax_query']['0'][0]['terms']
           
            payload='{"action":"load_more","the_query":{"post_type":["item"],"orderby":"date","posts_per_page":250,"post__not_in":[],"paged":1,"tax_query":{"0":[{"taxonomy":"c_cat","field":"term_id","terms":'+str(more_data_link)+'}],"relation":"AND"}}}'
            r = requests.get('http://reshet.tv/Services/load_more.php?res=1', data=payload)
            temp=json.loads(r.content)

            new_shows=(temp['posts'])
           
            if data['GridTitle']['title']!='' and extra!=0:
              if (data['GridTitle']['title'].encode('utf-8')) not in Links:
                date=new_shows[0]['publishDate'].split(" ")[0].replace(".","-")
                date_new=date.split('-')
                date_new[2]=int(date_new[2])+1
                date_new2=str(date_new[0])+'-'+str(date_new[1])+'-'+str(date_new[2])

                Links.append((data['GridTitle']['title'].encode('utf-8'),'','a','','',date_new2,data['GridTitle']['title'].encode('utf-8'),'postItem'))#################New Links##############
              
            
            
            for show in new_shows:
			   if __debug_mode__=='DEBUG':
				 logging.warning('new Shows:')
				 logging.warning(show)

			   name=show['title']
			   if name not in all_titles:
			    
				 dp.update(int((x)/float(len(new_shows)) * 100), 'טוען', name.encode('utf-8'))
				 if dp.iscanceled(): 
					dp.close()
					break
				 all_titles.append(name)
				 if __debug_mode__=='DEBUG':
				   logging.warning("New Names")
				   logging.warning(name)
				 link=show['link']
				 if 'subtitle' in show:
				   text=show['subtitle']
				 else:
				   text=''
				 
				 direct_link=''
				 #if show['video']!=None:
				 #  direct_link=show['video']['src']

				 if show['video']!=None:
					direct_link=(show['video']['videoID'])

				 image=show['images']['app_16x9']
				 date=show['publishDate'].split(" ")[0].replace(".","-")

				 type=show['gridView']['videoItem']

				 if name!=None and link!=None and image!=None and date!=None and link!=url:
				  #if len (name)>0 and len (link)>0 and len (image)>0 and len (date)>0:
					 if 'פרק' not in name.encode('utf-8'):
						 number_extra=number_extra+1
					 else:
						 number_episodes=number_episodes+1
					 Links.append((name.encode('utf-8'),text.encode('utf-8'),link,direct_link,image,date,'',type))#################New Links##############

            
            x=x+1
            if __debug_mode__=='DEBUG':
              logging.warning("Size:")
              logging.warning(str(len(new_shows)))
              logging.warning(more_data_link)
     dp.update(0, 'אוסף עמודים','רשת')
     if __debug_mode__=='DEBUG':
       logging.warning('#########Pages##################')
     x=0
     for season_data in Page_data:
      x=x+1
      if 'max_page' in str(Page_data):
        number_last=season_data['Pagination']
        season_links=re.compile("<a class='page-numbers' href='(.+?)'>(.+?)<\/a>").findall(number_last)
        for link_items,name_items in season_links:
          if link_items!=None and name_items!=None:
         #   if len (link_items)>0 and len (name_items)>0:
              dp.update(int((x)/float(len(Page_data)) * 100), 'טוען עמודים', name_items.encode('utf-8'))
              if dp.iscanceled(): 
                 dp.close()
                 break
              Pages.append((link_items,name_items.encode('utf-8')))#########Pages##################
      if 'GridTitle' in season_data:
       if season_data['GridTitle']!=None and 'title' in season_data['GridTitle'] :
        
        season_name=season_data['GridTitle']['title']
        season_link=season_data['GridTitle']['link']
       else:
        season_name=None
        season_link=None
      else:
        season_name=None
        season_link=None
      if season_name!=None and season_link!=None:
       # if len (season_name)>0 and len (season_link)>0:
          if __debug_mode__=='DEBUG':
            logging.warning(season_name)
            logging.warning(season_link)
          Seasons.append((season_name.encode('utf-8'),season_link))########Seasons##############
     if __debug_mode__=='DEBUG':
       logging.warning('#########Links##################')
     
     
     if __debug_mode__=='DEBUG':
        logging.warning('#########New Links##################')

     
     
     dp.close()
     
     if extra==0:
       Links.sort(key=lambda x: x[0],reverse=False)
     else:
       Links.sort(key=lambda x: x[5],reverse=True)
     return Links,Pages,Seasons,number_episodes,number_extra

def popilate_list(links,pages,seasons,extra=0):
  dp = xbmcgui.DialogProgress()
  page_numbers=[]
  dp.create("רשת", "[COLOR orange][B]בונה תפריטים[/B][/COLOR]",'')
  if extra>2:
   if __debug_mode__=='DEBUG':
     logging.warning("################# Add Seasons   ##################")
   for season in seasons:################# Add Seasons   ##################
      
      season_name=season[0]
      season_url=season[1]  
      if len(season_name)>0 and len(season_url)>0:
        dp.update(0, 'מוסיף עונות','רשת',season_name)
        if dp.iscanceled(): 
             dp.close()
             break
        addDir3(season_name,season_url,3,'','',season_name)
   if __debug_mode__=='DEBUG':
     logging.warning("################# Add Pages   ##################")
   for page in pages:################# Add Pages   ##################
     page_name=page[1]
     page_url=page[0]
     if __debug_mode__=='DEBUG':
       logging.warning('page_name:' + page_name)
       logging.warning('page_url:' + page_url)
      
     if len(page_url)>0 and len(page_name)>0:
      if page_name.isdigit():
        dp.update(0, 'מוסיף עמודים','רשת',season_name)
        if dp.iscanceled(): 
           dp.close()
           break
        page_numbers.append(page_name)
        #addDir3('[COLOR blue]'+' עמוד ' + page_name +'[/COLOR]',page_url,3,'','',page_name)
   if len(page_numbers)>1:
     if (int(page_numbers[1])>(int(page_numbers[0])+1)):
       i=0
       while i<=int(page_numbers[1]):
           if i>0:
             
             addDir3('[COLOR blue]'+' עמוד ' + str(i) +'[/COLOR]',page_url.replace('/'+page_numbers[1]+'/','/'+str(i)+'/'),3,'','',page_name)
           i=i+1
           if i>30:
            break
   if __debug_mode__=='DEBUG':
     logging.warning("################# Add Links   ##################")
  for link in links:################# Add Links   ##################
     
     name=link[0] 
     text=link[1]
     link_url=link[2]
     direct_link=link[3]
     image=link[4]
     date=link[5]
     grid=link[6]
     type=link[7]
     if direct_link==None:
       direct_link=''
     if __debug_mode__=='DEBUG':
       logging.warning("Before")
       logging.warning(name)
       logging.warning(link_url)
       logging.warning(direct_link)
     if (extra==1 and 'פרק' not in name) or (extra==2 and 'פרק' in name) or extra==0 or extra==4 :
       #if ('episode' in link_url or extra==1) and 'http' not in direct_link:
       #  direct_link=get_link2(direct_link,link_url)
         
       if direct_link==None:
        direct_link=''
       if __debug_mode__=='DEBUG':
         logging.warning(name)
         logging.warning(link_url)
         logging.warning(direct_link)
       dp.update(0, 'מוסיף קישורים','רשת',name)
       if dp.iscanceled(): 
           dp.close()
           break

       if (type=='videoItem') and extra!=0:
         if len(direct_link)>1:
           addLink('[COLOR yellow]'+ name+'[/COLOR]', text,direct_link, image,date,link_url)
         else:
           addLink('[COLOR red]'+ name+'[/COLOR]', text,direct_link, image,date,link_url)
       elif (type!='videoItem'):
         if grid=='':
          addDir3('[COLOR skyblue]'+name+'[/COLOR]',link_url,3,image,image,text,date)
         else:
          addDir3('[COLOR green]'+name+'[/COLOR]',link_url,3,image,image,text,date)
     
       
    

  dp.close()
  return 1
def get_link2(videoid):
  from operator import itemgetter
  dp = xbmcgui.DialogProgress()
  dp.create("רשת", "[COLOR orange][B]מפעיל [/B][/COLOR]")
  dp.update(0, 'בודק אפשריות ניגון','רשת')
  
  result = requests.get('https://edge.api.brightcove.com/playback/v1/accounts/1551111274001/videos/' + videoid, headers={"Accept": "application/json;pk=BCpkADawqM30eqkItS5d08jYUtMkbTKu99oEBllbfUaFKeknXu4iYsh75cRm2huJ_b1-pXEPuvItI-733TqJN1zENi-DcHlt7b4Dv6gCT8T3BS-ampD0XMnORQLoLvjvxD14AseHxvk0esW3"})

  sources = json.loads(result.content)['sources']
  url = ''
  avg_bitrate = 0
  x=0
  urls=[]
  for source in sources:
    if 'src' in source:
       
       
      
       
       if 'avg_bitrate' in source:
          video_info = {"source": source['src'],"quality": source['avg_bitrate']}
          urls.append(video_info)
       else:
          video_info = {"source": source['src'],"quality":50000000}
          urls.append(video_info)
       x=x+1
  
  
  sorted_obj = sorted(urls, key=lambda k: k['quality'], reverse=False)
  
  
  logging.warning(sorted_obj)
  max_quality =int( MyAddon.getSetting("quality"))
  if max_quality==4:
    max_quality=100
  logging.warning(max_quality)
  quality_number=len(sorted_obj)-1
  logging.warning(quality_number)
  if max_quality<=quality_number:
    url=sorted_obj[max_quality]["source"]
    dp.update(0, 'איכות:' + str(sorted_obj[max_quality]['quality']) ,'רשת')
  else:
    url=sorted_obj[quality_number]["source"]
    dp.update(0, 'איכות:' + str(sorted_obj[quality_number]['quality']) ,'רשת')
  logging.warning(url)
  dp.close()
  return url
def CATEGORIES():

 
   
   links,pages,seasons,number_episodes,number_extra=get_all_site_data('http://reshet.tv/general/programs/',0)
   popilate_list(links,pages,seasons)
   
  
   
 
 
def CHANNEL5MORE(url,name):
    if __debug_mode__=='DEBUG':
      logging.warning(url)
      logging.warning(name)
    links,pages,seasons,number_episodes,number_extra=get_all_site_data(url)
    
    if len (links)>0:
     if name!='פרקים מלאים' :
      addDir3(str(number_extra)+'[COLOR blue]'+'תוספות-'+'[/COLOR]' ,url,5,'','','תוספות')
      addDir3(str(number_episodes)+'[COLOR teal]'+'פרקים-'+'[/COLOR]' ,url,7,'','','פרקים')
      popilate_list(links,pages,seasons,3)
     else:
      popilate_list(links,pages,seasons,4)

    

def get_directlink(url):
     import YDStreamExtractor
     vid = YDStreamExtractor.getVideoInfo(url,quality=2) #quality is 0=SD, 1=720p, 2=1080p and is a maximum
     if vid==None:
      return 'NONE'
     stream_url = vid.streamURL() #This is what Kodi (XBMC) will play
     return stream_url
def mylist(url,name):

   links,pages,seasons,number_episodes,number_extra=get_all_site_data(url)
   if __debug_mode__=='DEBUG':
     logging.warning(name)

   if len (links)>0:
    if name!='פרקים מלאים':
      addDir3(str(number_extra)+'[COLOR blue]'+'תוספות-'+'[/COLOR]' ,url,5,'','','תוספות')
      addDir3(str(number_episodes)+'[COLOR teal]'+'פרקים-'+'[/COLOR]' ,url,7,'','','פרקים')
      popilate_list(links,pages,seasons,3)
    else:
      popilate_list(links,pages,seasons,4)
	
    
   

def OPEN_URL(url,name):
	 
     time.sleep(1)
     vid = YDStreamExtractor.getVideoInfo(url,quality=2) #quality is 0=SD, 1=720p, 2=1080p and is a maximum
     stream_url = vid.streamURL() #This is what Kodi (XBMC) will play
     x = 1
     
     listItem = xbmcgui.ListItem(name, path=stream_url)
     xbmc.Player().play(item=stream_url, listitem=listItem)
     sys.exit()
     return x

def add_extra(url):
     links,pages,seasons,number_episodes,number_extra=get_all_site_data(url)
     popilate_list(links,pages,seasons,1)
def add_episode(url):
     links,pages,seasons,number_episodes,number_extra=get_all_site_data(url)
     popilate_list(links,pages,seasons,2)
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param       
#################################################################################################################

#                               NEED BELOW CHANGED


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
     
def addLink2(name,url,iconimage,date):
        #u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        datetime_object = datetime.strptime(date, '%Y-%m-%d').date()
        datetime_object = datetime.strptime(date, '%Y-%m-%d').strftime('%d-%m-%Y')
        #logging.warning(datetime_object)
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name  , "Plot": name + ' ' + str(datetime_object) ,"Date": str(datetime_object),"Aired": str(datetime_object) } )
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
        return ok
###############################################################################################################        

def addDir3(name,url,mode,iconimage,fanart,description,date="1978-01-01"):
     
      
        datetime_object=datetime(*(time.strptime(date, '%Y-%m-%d')[0:6])).date()
     
        #datetime_object = datetime.strptime(date, '%Y-%m-%d').date()
        datetime_object=datetime(*(time.strptime(date, '%Y-%m-%d')[0:6])).strftime('%d-%m-%Y')
        #datetime_object = datetime.strptime(date, '%Y-%m-%d').strftime('%d-%m-%Y')
       
        if date=="1978-01-01":
              datetime_object=""
        #logging.warning(datetime_object)
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        if datetime_object=="":
          liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot":  description  } )
        else:
          liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description  ,'Date': str(datetime_object),'Aired': str(datetime_object)} )
        liz.setProperty( "Fanart_Image", fanart )
        if url=='a':
         isFolder_value=False
        else:
         isFolder_value=True
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isFolder_value)
        #if 'episode' in url:
        #       xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_TITLE,reverse=True)
       # xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL)
        return ok

def addLink( name,plot, url, iconimage,date,link_url):
 

          mode=6
          datetime_object=datetime(*(time.strptime(date, '%Y-%m-%d')[0:6])).date()
         
        #datetime_object = datetime.strptime(date, '%Y-%m-%d').date()
          datetime_object=datetime(*(time.strptime(date, '%Y-%m-%d')[0:6])).strftime('%d-%m-%Y')
        #datetime_object = datetime.strptime(date, '%Y-%m-%d').strftime('%d-%m-%Y')
         
		 
          #datetime_object = datetime.strptime(date, '%Y-%m-%d').date()
          #datetime_object = datetime.strptime(date, '%Y-%m-%d').strftime('%d-%m-%Y')
          if date=="1978-01-01":
              datetime_object=""
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&link_url="+str(link_url)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)
          
          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name)  , "Plot":  plot  ,'Date': str(datetime_object),'Aired': str(datetime_object)})
          liz.setProperty( "Fanart_Image", iconimage )
          liz.setProperty("IsPlayable","true")

          ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=False)
          
          #xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_TITLE,reverse=True)
          return ok
def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % viewType )
 
def GetJson(url):
	html = OpenURL(url)
	if html is None:
		return None
	resultJSON = json.loads(html)
	if resultJSON is None or len(resultJSON) < 1:
		return None
	if resultJSON.has_key("root"):
		return resultJSON["root"]
	else:
		return resultJSON

def OpenURL(url, headers={}, user_data={}, retries=3):
	if user_data:
		user_data = urllib.urlencode(user_data)
		req = urllib2.Request(url, user_data)
	else:
		req = urllib2.Request(url)
	
	req.add_header('User-Agent', UA)
	for k, v in headers.items():
		req.add_header(k, v)
	
	if forwarded != '':
		req.add_header('X-Forwarded-For', forwarded)

	link = None
	for i in range(retries):
		try:
			response = urllib2.urlopen(req, timeout=100)
			link = response.read()
			response.close()
			break
		except Exception as ex:
			print ex

	return link

def play_item(url,link_url):
    
    if url=='':

      url=get_directlink(link_url)
    else:
      url=get_link2(url)
    
	
    listItem = xbmcgui.ListItem(path=url)
    listItem.setInfo(type="Video", infoLabels={"title": name})
    #listItem.setProperty("IsPlayable","true")
    #xbmc.Player().play(item=url, listitem=listItem)

    xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
#r = requests.get("http://reshet.tv/entertainment/the-voice/")

#match = re.compile(('"postType":"item","post_name":"(.+?)","ID":(.+?),"title":"(.+?)","link":"(.+?)","target":(.+?),"images":{"app_feed":"(.+?)"')).findall(r.content)
#biggest="0"
#big=["0","0"]
#j=0
#listing = []
#for name,id,title,link,target,image in match:
       
#       if len(title)<500 and len(link)<500:

         
#          category = title.decode('unicode_escape').encode('utf-8')
          
#          link_new=link.split("\\/")
         
#          j=0
#          for item in link_new:
#            if item.find("season") != -1:
             
#             big=item.split("-")
#            if int(biggest)<int(big[1]):
            
#             biggest=big[1]

#            j=j+1
#                    # Create a list item with a text label and a thumbnail image.

#            listing.append((category,link.replace('\\/', '/'),1,image.replace('\\/', '/'),"",""))
#    # Add our listing to Kodi.
#    # Large lists and/or slower systems benefit from adding all items at once via addDirectoryItems
#    # instead of adding one by ove via addDirectoryItem.

          
#          #addDir3(category,link.replace('\\/', '/'),1,image.replace('\\/', '/'),"","",)


       
#addDir3("תוספות",link,5,image,"","",)
 		               
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
link_url=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:        
        link_url=urllib.unquote_plus(params["link_url"])
except:
        pass


print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
if url=='a':
   sys.exit()
if mode==None or url==None :
        print ""
        CATEGORIES()
       
elif mode==1:
        OPEN_URL(url,name)
elif mode==3:
        CHANNEL5MORE(url,name)
elif mode==4:
        mylist(url,name)
elif mode==5:
        add_extra(url)        
elif mode==6:
        play_item(url,link_url)   
elif mode==7:
        add_episode(url)  
xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
xbmc.executebuiltin("Container.SetViewMode(504)")
xbmcplugin.endOfDirectory(int(sys.argv[1]))
